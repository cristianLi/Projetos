//Nome do Arquivo:CongeDetalhamentoTermosAditivos
//10 – Conge - DetalhamentoTermosAditivos
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CongeDetalhamentoTermosAditivos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dataAssinaturaConvOriginalConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaConvOriginalConge;
    @SicomColumn(description = "nroSeqTermo", length = 2, type = Type.INTEIRO, required = true)
    int nroSeqTermoAditivoConge;
    @SicomColumn(description = "dscAlteracaoConge", length = 500, type = Type.TEXTO, required = true)
    String dscAlteracaoConge;
    @SicomColumn(description = "dataAssinaturaTermoAditivoConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaTermoAditivoConge;
    @SicomColumn(description = "dataFinalVigenciaConge", length = 8, type = Type.DATA, required = true)
    date dataFinalVigenciaConge;
    @SicomColumn(description = "valorAtualizadoConvenioConge", length = 14, type = Type.DOUBLE, required = true)
    double valorAtualizadoConvenioConge;
    @SicomColumn(description = "valorAtualizado", length = 14, type = Type.DOUBLE, required = true)
    double valorAtualizadoContrapartidaConge;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConvOriginalConge() {
        return dataAssinaturaConvOriginalConge;
    }

    public void setDataAssinaturaConvOriginalConge(date dataAssinaturaConvOriginalConge) {
        this.dataAssinaturaConvOriginalConge = dataAssinaturaConvOriginalConge;
    }

    public int getNroSeqTermoAditivoConge() {
        return nroSeqTermoAditivoConge;
    }

    public void setNroSeqTermoAditivoConge(int nroSeqTermoAditivoConge) {
        this.nroSeqTermoAditivoConge = nroSeqTermoAditivoConge;
    }

    public String getDscAlteracaoConge() {
        return dscAlteracaoConge;
    }

    public void setDscAlteracaoConge(String dscAlteracaoConge) {
        this.dscAlteracaoConge = dscAlteracaoConge;
    }

    public date getDataAssinaturaTermoAditivoConge() {
        return dataAssinaturaTermoAditivoConge;
    }

    public void setDataAssinaturaTermoAditivoConge(date dataAssinaturaTermoAditivoConge) {
        this.dataAssinaturaTermoAditivoConge = dataAssinaturaTermoAditivoConge;
    }

    public date getDataFinalVigenciaConge() {
        return dataFinalVigenciaConge;
    }

    public void setDataFinalVigenciaConge(date dataFinalVigenciaConge) {
        this.dataFinalVigenciaConge = dataFinalVigenciaConge;
    }

    public double getValorAtualizadoConvenioConge() {
        return valorAtualizadoConvenioConge;
    }

    public void setValorAtualizadoConvenioConge(double valorAtualizadoConvenioConge) {
        this.valorAtualizadoConvenioConge = valorAtualizadoConvenioConge;
    }

    public double getValorAtualizadoContrapartidaConge() {
        return valorAtualizadoContrapartidaConge;
    }

    public void setValorAtualizadoContrapartidaConge(double valorAtualizadoContrapartidaConge) {
        this.valorAtualizadoContrapartidaConge = valorAtualizadoContrapartidaConge;
    }
}