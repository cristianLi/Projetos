//Nome do Arquivo: AOCAlteracoesOrcamentariasReducao
//10 – AOC - AlteracoesOrcamentariasReducao

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AOCAlteracoesOrcamentariasReducao{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzidoDecreto", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoDecreto;
    @SicomColumn(description = "OrigemRecAlteracao", length = 2, type = Type.TEXTO, required = true)
    String origemRecAlteracao;
    @SicomColumn(description = "CodOrigem", length = 15, type = Type.INTEIRO, required = true)
    int codOrigem;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "CodFuncao", length = 2, type = Type.TEXTO, required = true)
    String codFuncao;
    @SicomColumn(description = "CodSubFuncao", length = 3, type = Type.TEXTO, required = true)
    String codSubFuncao;
    @SicomColumn(description = "CodPrograma", length = 4, type = Type.TEXTO, required = true)
    String codPrograma;
    @SicomColumn(description = "IdAcao", length = 4, type = Type.TEXTO, required = true)
    String idAcao;
    @SicomColumn(description = "IdSubAcao", length = 4, type = Type.TEXTO, required = false)
    String idSubAcao;
    @SicomColumn(description = "NaturezaDespesa", length = 6, type = Type.INTEIRO, required = true)
    int naturezaDespesa;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlReducao", length = 14, type = Type.DOUBLE, required = true)
    double vlReducao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoDecreto() {
        return codReduzidoDecreto;
    }

    public void setCodReduzidoDecreto(int codReduzidoDecreto) {
        this.codReduzidoDecreto = codReduzidoDecreto;
    }

    public String getOrigemRecAlteracao() {
        return origemRecAlteracao;
    }

    public void setOrigemRecAlteracao(String origemRecAlteracao) {
        this.origemRecAlteracao = origemRecAlteracao;
    }

    public int getCodOrigem() {
        return codOrigem;
    }

    public void setCodOrigem(int codOrigem) {
        this.codOrigem = codOrigem;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodFuncao() {
        return codFuncao;
    }

    public void setCodFuncao(String codFuncao) {
        this.codFuncao = codFuncao;
    }

    public String getCodSubFuncao() {
        return codSubFuncao;
    }

    public void setCodSubFuncao(String codSubFuncao) {
        this.codSubFuncao = codSubFuncao;
    }

    public String getCodPrograma() {
        return codPrograma;
    }

    public void setCodPrograma(String codPrograma) {
        this.codPrograma = codPrograma;
    }

    public String getIdAcao() {
        return idAcao;
    }

    public void setIdAcao(String idAcao) {
        this.idAcao = idAcao;
    }

    public String getIdSubAcao() {
        return idSubAcao;
    }

    public void setIdSubAcao(String idSubAcao) {
        this.idSubAcao = idSubAcao;
    }

    public int getNaturezaDespesa() {
        return naturezaDespesa;
    }

    public void setNaturezaDespesa(int naturezaDespesa) {
        this.naturezaDespesa = naturezaDespesa;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlReducao() {
        return vlReducao;
    }

    public void setVlReducao(double vlReducao) {
        this.vlReducao = vlReducao;
    }
}