//Nome do Arquivo: Parec
//10 – Parec

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Parec {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "EDeducaoDeReceita", length = 1, type = Type.INTEIRO, required = true)
    int eDeducaoDeReceita;
    @SicomColumn(description = "IdentificadorDeducao", length = 2, type = Type.INTEIRO, required = false)
    int identificadorDeducao;
    @SicomColumn(description = "NaturezaReceita", length = 8, type = Type.INTEIRO, required = true)
    int naturezaReceita;
    @SicomColumn(description = "tipoAtualizacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoAtualizacao;
    @SicomColumn(description = "vlAcrescidoReduzido", length = 14, type = Type.DOUBLE, required = true)
    double vlAcrescidoReduzido;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int geteDeducaoDeReceita() {
        return eDeducaoDeReceita;
    }

    public void seteDeducaoDeReceita(int eDeducaoDeReceita) {
        this.eDeducaoDeReceita = eDeducaoDeReceita;
    }

    public int getIdentificadorDeducao() {
        return identificadorDeducao;
    }

    public void setIdentificadorDeducao(int identificadorDeducao) {
        this.identificadorDeducao = identificadorDeducao;
    }

    public int getNaturezaReceita() {
        return naturezaReceita;
    }

    public void setNaturezaReceita(int naturezaReceita) {
        this.naturezaReceita = naturezaReceita;
    }

    public int getTipoAtualizacao() {
        return tipoAtualizacao;
    }

    public void setTipoAtualizacao(int tipoAtualizacao) {
        this.tipoAtualizacao = tipoAtualizacao;
    }

    public double getVlAcrescidoReduzido() {
        return vlAcrescidoReduzido;
    }

    public void setVlAcrescidoReduzido(double vlAcrescidoReduzido) {
        this.vlAcrescidoReduzido = vlAcrescidoReduzido;
    }

}