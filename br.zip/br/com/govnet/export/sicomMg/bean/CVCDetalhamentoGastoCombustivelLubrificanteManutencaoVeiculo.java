//Nome do Arquivo:CVCDetalhamentoGastoCombustivelLubrificanteManutencaoVeiculo
//20 – CVC - DetalhamentoGastoCombustivelLubrificanteManutencaoVeiculo
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CVCDetalhamentoGastoCombustivelLubrificanteManutencaoVeiculo{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codVeiculo", length = 10, type = Type.TEXTO, required = true)
    String codVeiculo;
    @SicomColumn(description = "origemGasto", length = 1, type = Type.INTEIRO, required = true)
    int origemGasto;
    @SicomColumn(description = "codUnidadeSubEmpenho", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubEmpenho;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = false)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = false)
    date dtEmpenho;
    @SicomColumn(description = "MarcacaoInicial", length = 6, type = Type.INTEIRO, required = true)
    int MarcacaoInicial;
    @SicomColumn(description = "MarcacaoFinal", length = 6, type = Type.INTEIRO, required = true)
    int MarcacaoFinal;
    @SicomColumn(description = "tipoGasto", length = 2, type = Type.TEXTO, required = true)
    String tipoGasto;
    @SicomColumn(description = "qtdeUtilizada", length = 14, type = Type.DOUBLE, required = true)
    double qtdeUtilizada;
    @SicomColumn(description = "vlGasto", length = 14, type = Type.DOUBLE, required = true)
    double vlGasto;
    @SicomColumn(description = "dscPecasServicos", length = 50, type = Type.TEXTO, required = false)
    String dscPecasServicos;
    @SicomColumn(description = "atestadoControle", length = 1, type = Type.TEXTO, required = true)
    String atestadoControle;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodVeiculo() {
        return codVeiculo;
    }

    public void setCodVeiculo(String codVeiculo) {
        this.codVeiculo = codVeiculo;
    }

    public int getOrigemGasto() {
        return origemGasto;
    }

    public void setOrigemGasto(int origemGasto) {
        this.origemGasto = origemGasto;
    }

    public String getCodUnidadeSubEmpenho() {
        return codUnidadeSubEmpenho;
    }

    public void setCodUnidadeSubEmpenho(String codUnidadeSubEmpenho) {
        this.codUnidadeSubEmpenho = codUnidadeSubEmpenho;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getMarcacaoInicial() {
        return MarcacaoInicial;
    }

    public void setMarcacaoInicial(int marcacaoInicial) {
        MarcacaoInicial = marcacaoInicial;
    }

    public int getMarcacaoFinal() {
        return MarcacaoFinal;
    }

    public void setMarcacaoFinal(int marcacaoFinal) {
        MarcacaoFinal = marcacaoFinal;
    }

    public String getTipoGasto() {
        return tipoGasto;
    }

    public void setTipoGasto(String tipoGasto) {
        this.tipoGasto = tipoGasto;
    }

    public double getQtdeUtilizada() {
        return qtdeUtilizada;
    }

    public void setQtdeUtilizada(double qtdeUtilizada) {
        this.qtdeUtilizada = qtdeUtilizada;
    }

    public double getVlGasto() {
        return vlGasto;
    }

    public void setVlGasto(double vlGasto) {
        this.vlGasto = vlGasto;
    }

    public String getDscPecasServicos() {
        return dscPecasServicos;
    }

    public void setDscPecasServicos(String dscPecasServicos) {
        this.dscPecasServicos = dscPecasServicos;
    }

    public String getAtestadoControle() {
        return atestadoControle;
    }

    public void setAtestadoControle(String atestadoControle) {
        this.atestadoControle = atestadoControle;
    }
}


