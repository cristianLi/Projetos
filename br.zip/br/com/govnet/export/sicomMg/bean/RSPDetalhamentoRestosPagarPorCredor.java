//Nome do Arquivo:RSPDetalhamentoRestosPagarPorCredor
//12 – RSP - DetalhamentoRestosPagarPorCredor

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSPDetalhamentoRestosPagarPorCredor{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoRSP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoRSP;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoRSP() {
        return codReduzidoRSP;
    }

    public void setCodReduzidoRSP(int codReduzidoRSP) {
        this.codReduzidoRSP = codReduzidoRSP;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }
}