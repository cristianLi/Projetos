//Nome do Arquivo:DDCCadastroContratoDivida
//20 – DDC - CadastroContratoDivida
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DDCCadastroContratoDivida{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "nroContratoDivida", length = 30, type = Type.TEXTO, required = true)
    String nroContratoDivida;
    @SicomColumn(description = "dtAssinatura", length = 8, type = Type.DATA, required = true)
    date dtAssinatura;
    @SicomColumn(description = "contratoDecLei", length = 1, type = Type.INTEIRO, required = true)
    int contratoDecLei;
    @SicomColumn(description = "nroLeiAutorizacao", length = 6, type = Type.TEXTO, required = false)
    String nroLeiAutorizacao;
    @SicomColumn(description = "dtLeiAutorizacao", length = 8, type = Type.DATA, required = false)
    date dtLeiAutorizacao;
    @SicomColumn(description = "objetoContratoDivida", length = 1000, type = Type.TEXTO, required = true)
    String objetoContratoDivida;
    @SicomColumn(description = "especificacaoContratoDivida", length = 500, type = Type.TEXTO, required = true)
    String especificacaoContratoDivida;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroContratoDivida() {
        return nroContratoDivida;
    }

    public void setNroContratoDivida(String nroContratoDivida) {
        this.nroContratoDivida = nroContratoDivida;
    }

    public date getDtAssinatura() {
        return dtAssinatura;
    }

    public void setDtAssinatura(date dtAssinatura) {
        this.dtAssinatura = dtAssinatura;
    }

    public int getContratoDecLei() {
        return contratoDecLei;
    }

    public void setContratoDecLei(int contratoDecLei) {
        this.contratoDecLei = contratoDecLei;
    }

    public String getNroLeiAutorizacao() {
        return nroLeiAutorizacao;
    }

    public void setNroLeiAutorizacao(String nroLeiAutorizacao) {
        this.nroLeiAutorizacao = nroLeiAutorizacao;
    }

    public date getDtLeiAutorizacao() {
        return dtLeiAutorizacao;
    }

    public void setDtLeiAutorizacao(date dtLeiAutorizacao) {
        this.dtLeiAutorizacao = dtLeiAutorizacao;
    }

    public String getObjetoContratoDivida() {
        return objetoContratoDivida;
    }

    public void setObjetoContratoDivida(String objetoContratoDivida) {
        this.objetoContratoDivida = objetoContratoDivida;
    }

    public String getEspecificacaoContratoDivida() {
        return especificacaoContratoDivida;
    }

    public void setEspecificacaoContratoDivida(String especificacaoContratoDivida) {
        this.especificacaoContratoDivida = especificacaoContratoDivida;
    }
}



