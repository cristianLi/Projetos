//Nome do Arquivo:DCLRFMedidasAdotadasMetasBimestraisArrecadacao
//11 – DCLRF - MedidasAdotadasMetasBimestraisArrecadacao
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DCLRFMedidasAdotadasMetasBimestraisArrecadacao{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "medidasAdotadas", length = 2, type = Type.INTEIRO, required = true)
    int medidasAdotadas;
    @SicomColumn(description = "dscMedidasAdotadas", length = 4000, type = Type.TEXTO, required = false)
    String dscMedidasAdotadas;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getMedidasAdotadas() {
        return medidasAdotadas;
    }

    public void setMedidasAdotadas(int medidasAdotadas) {
        this.medidasAdotadas = medidasAdotadas;
    }

    public String getDscMedidasAdotadas() {
        return dscMedidasAdotadas;
    }

    public void setDscMedidasAdotadas(String dscMedidasAdotadas) {
        this.dscMedidasAdotadas = dscMedidasAdotadas;
    }
}


