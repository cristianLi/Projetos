//Nome do Arquivo: Dispensa
//10 – Dispensa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DispensaCadastroItensProcessoDispensaInexigibilidade{


    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = true)
    String codOrgaoResp;
    @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSubResp;
    @SicomColumn(description = "ExercicioProcesso", length = 4, type = Type.INTEIRO, required = true)
    int exercicioProcesso;
    @SicomColumn(description = "NroProcesso", length = 12, type = Type.TEXTO, required = true)
    String nroProcesso;
    @SicomColumn(description = "TipoProcesso", length = 1, type = Type.INTEIRO, required = true)
    int tipoProcesso;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "NroItem", length = 5, type = Type.INTEIRO, required = true)
    int nroItem;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgaoResp() {
        return codOrgaoResp;
    }

    public void setCodOrgaoResp(String codOrgaoResp) {
        this.codOrgaoResp = codOrgaoResp;
    }

    public String getCodUnidadeSubResp() {
        return codUnidadeSubResp;
    }

    public void setCodUnidadeSubResp(String codUnidadeSubResp) {
        this.codUnidadeSubResp = codUnidadeSubResp;
    }

    public int getExercicioProcesso() {
        return exercicioProcesso;
    }

    public void setExercicioProcesso(int exercicioProcesso) {
        this.exercicioProcesso = exercicioProcesso;
    }

    public String getNroProcesso() {
        return nroProcesso;
    }

    public void setNroProcesso(String nroProcesso) {
        this.nroProcesso = nroProcesso;
    }

    public int getTipoProcesso() {
        return tipoProcesso;
    }

    public void setTipoProcesso(int tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public int getNroItem() {
        return nroItem;
    }

    public void setNroItem(int nroItem) {
        this.nroItem = nroItem;
    }
}
