//Nome do Arquivo:
//10 –
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Consid{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codArquivo", length = 20, type = Type.TEXTO, required = true)
    String codArquivo;
    @SicomColumn(description = "exercicioReferenciaConsid", length = 4, type = Type.INTEIRO, required = true)
    int exercicioReferenciaConsid;
    @SicomColumn(description = "mesReferenciaConsid", length = 2, type = Type.TEXTO, required = false)
    String mesReferenciaConsid;
    @SicomColumn(description = "consideracoes", length = 3000, type = Type.TEXTO, required = true)
    String consideracoes;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodArquivo() {
        return codArquivo;
    }

    public void setCodArquivo(String codArquivo) {
        this.codArquivo = codArquivo;
    }

    public int getExercicioReferenciaConsid() {
        return exercicioReferenciaConsid;
    }

    public void setExercicioReferenciaConsid(int exercicioReferenciaConsid) {
        this.exercicioReferenciaConsid = exercicioReferenciaConsid;
    }

    public String getMesReferenciaConsid() {
        return mesReferenciaConsid;
    }

    public void setMesReferenciaConsid(String mesReferenciaConsid) {
        this.mesReferenciaConsid = mesReferenciaConsid;
    }

    public String getConsideracoes() {
        return consideracoes;
    }

    public void setConsideracoes(String consideracoes) {
        this.consideracoes = consideracoes;
    }
}