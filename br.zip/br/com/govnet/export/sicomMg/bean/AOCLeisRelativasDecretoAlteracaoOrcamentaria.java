//Nome do Arquivo: CONSOR
//10 – Consor

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AOCLeisRelativasDecretoAlteracaoOrcamentaria{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzidoDecreto", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoDecreto;
    @SicomColumn(description = "NroLeiAlteracao", length = 6, type = Type.TEXTO, required = true)
    String nroLeiAlteracao;
    @SicomColumn(description = "DataLeiAlteracao", length = 8, type = Type.DATA, required = true)
    Date dataLeiAlteracao;
    @SicomColumn(description = "TpLeiOrigDecreto", length = 4, type = Type.TEXTO, required = true)
    String tpLeiOrigDecreto;
    @SicomColumn(description = "TipoLeiAlteracao", length = 1, type = Type.INTEIRO, required = false)
    int tipoLeiAlteracao;
    @SicomColumn(description = "ValorAbertoLei", length = 14, type = Type.DOUBLE, required = true)
    double valorAbertoLei;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoDecreto() {
        return codReduzidoDecreto;
    }

    public void setCodReduzidoDecreto(int codReduzidoDecreto) {
        this.codReduzidoDecreto = codReduzidoDecreto;
    }

    public String getNroLeiAlteracao() {
        return nroLeiAlteracao;
    }

    public void setNroLeiAlteracao(String nroLeiAlteracao) {
        this.nroLeiAlteracao = nroLeiAlteracao;
    }

    public Date getDataLeiAlteracao() {
        return dataLeiAlteracao;
    }

    public void setDataLeiAlteracao(Date dataLeiAlteracao) {
        this.dataLeiAlteracao = dataLeiAlteracao;
    }

    public String getTpLeiOrigDecreto() {
        return tpLeiOrigDecreto;
    }

    public void setTpLeiOrigDecreto(String tpLeiOrigDecreto) {
        this.tpLeiOrigDecreto = tpLeiOrigDecreto;
    }

    public int getTipoLeiAlteracao() {
        return tipoLeiAlteracao;
    }

    public void setTipoLeiAlteracao(int tipoLeiAlteracao) {
        this.tipoLeiAlteracao = tipoLeiAlteracao;
    }

    public double getValorAbertoLei() {
        return valorAbertoLei;
    }

    public void setValorAbertoLei(double valorAbertoLei) {
        this.valorAbertoLei = valorAbertoLei;
    }
}