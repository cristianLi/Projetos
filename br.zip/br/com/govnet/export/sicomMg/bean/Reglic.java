//Nome do Arquivo: Reglic
//10 – Reglic

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Reglic{


    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "TipoDecreto", length = 1, type = Type.INTEIRO, required = true)
    int tipoDecreto;
    @SicomColumn(description = "NroDecretoMunicipal", length = 8, type = Type.INTEIRO, required = true)
    int nroDecretoMunicipal;
    @SicomColumn(description = "DataDecretoMunicipal", length = 8, type = Type.DATA, required = true)
    Date dataDecretoMunicipal;
    @SicomColumn(description = "DataPublicacaoDecretoMunicipal", length = 8, type = Type.DATA, required = true)
    Date dataPublicacaoDecretoMunicipal;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getTipoDecreto() {
        return tipoDecreto;
    }

    public void setTipoDecreto(int tipoDecreto) {
        this.tipoDecreto = tipoDecreto;
    }

    public int getNroDecretoMunicipal() {
        return nroDecretoMunicipal;
    }

    public void setNroDecretoMunicipal(int nroDecretoMunicipal) {
        this.nroDecretoMunicipal = nroDecretoMunicipal;
    }

    public Date getDataDecretoMunicipal() {
        return dataDecretoMunicipal;
    }

    public void setDataDecretoMunicipal(Date dataDecretoMunicipal) {
        this.dataDecretoMunicipal = dataDecretoMunicipal;
    }

    public Date getDataPublicacaoDecretoMunicipal() {
        return dataPublicacaoDecretoMunicipal;
    }

    public void setDataPublicacaoDecretoMunicipal(Date dataPublicacaoDecretoMunicipal) {
        this.dataPublicacaoDecretoMunicipal = dataPublicacaoDecretoMunicipal;
    }
}