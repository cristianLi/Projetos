//Nome do Arquivo:TCEDetalhamentoResponsaveisPeloDanoErario
//11 – TCE - DetalhamentoResponsaveisPeloDanoErario
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class TCEDetalhamentoResponsaveisPeloDanoErario{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "numProcessoTCE", length = 12, type = Type.TEXTO, required = true)
    String numProcessoTCE;
    @SicomColumn(description = "dataInstauracaoTCE", length = 8, type = Type.DATA, required = true)
    date dataInstauracaoTCE;
    @SicomColumn(description = "tipoDocumentoRespDano", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoRespDano;
    @SicomColumn(description = "nroDocumentoRespDano", length = 14, type = Type.TEXTO, required = true)
    String nroDocumentoRespDano;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getNumProcessoTCE() {
        return numProcessoTCE;
    }

    public void setNumProcessoTCE(String numProcessoTCE) {
        this.numProcessoTCE = numProcessoTCE;
    }

    public date getDataInstauracaoTCE() {
        return dataInstauracaoTCE;
    }

    public void setDataInstauracaoTCE(date dataInstauracaoTCE) {
        this.dataInstauracaoTCE = dataInstauracaoTCE;
    }

    public int getTipoDocumentoRespDano() {
        return tipoDocumentoRespDano;
    }

    public void setTipoDocumentoRespDano(int tipoDocumentoRespDano) {
        this.tipoDocumentoRespDano = tipoDocumentoRespDano;
    }

    public String getNroDocumentoRespDano() {
        return nroDocumentoRespDano;
    }

    public void setNroDocumentoRespDano(String nroDocumentoRespDano) {
        this.nroDocumentoRespDano = nroDocumentoRespDano;
    }
}
