//Nome do Arquivo:CuteEncerramentoReativacaoContaUnica
//30 – Cute - EncerramentoReativacaoContaUnica

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CuteEncerramentoReativacaoContaUnica {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;

    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;

    @SicomColumn(description = "codCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;

    @SicomColumn(description = "situacaoConta", length = 1, type = Type.TEXTO, required = true)
    String situacaoConta;

    @SicomColumn(description = "dataSituacao", length = 8, type = Type.DATA, required = true)
    date dataSituacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public String getSituacaoConta() {
        return situacaoConta;
    }

    public void setSituacaoConta(String situacaoConta) {
        this.situacaoConta = situacaoConta;
    }

    public date getDataSituacao() {
        return dataSituacao;
    }

    public void setDataSituacao(date dataSituacao) {
        this.dataSituacao = dataSituacao;
    }
}