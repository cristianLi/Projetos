//Nome do Arquivo:Iderp
//10 – Iderp
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Iderp{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codIDERP", length = 15, type = Type.INTEIRO, required = true)
    int codIDERP;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "tipoRestosPagar", length = 1, type = Type.INTEIRO, required = true)
    int tipoRestosPagar;
    @SicomColumn(description = "disponibilidadeCaixa", length = 1, type = Type.INTEIRO, required = true)
    int disponibilidadeCaixa;
    @SicomColumn(description = "vlInscricao", length = 14, type = Type.DOUBLE, required = true)
    double vlInscricao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodIDERP() {
        return codIDERP;
    }

    public void setCodIDERP(int codIDERP) {
        this.codIDERP = codIDERP;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public int getTipoRestosPagar() {
        return tipoRestosPagar;
    }

    public void setTipoRestosPagar(int tipoRestosPagar) {
        this.tipoRestosPagar = tipoRestosPagar;
    }

    public int getDisponibilidadeCaixa() {
        return disponibilidadeCaixa;
    }

    public void setDisponibilidadeCaixa(int disponibilidadeCaixa) {
        this.disponibilidadeCaixa = disponibilidadeCaixa;
    }

    public double getVlInscricao() {
        return vlInscricao;
    }

    public void setVlInscricao(double vlInscricao) {
        this.vlInscricao = vlInscricao;
    }
}