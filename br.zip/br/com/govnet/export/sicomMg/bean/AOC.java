//Nome do Arquivo: AOC
//10 – AOC

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AOC {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NroDecreto", length = 8, type = Type.INTEIRO, required = true)
    int nroDecreto;
    @SicomColumn(description = "DataDecreto", length = 8, type = Type.DATA, required = true)
    DateDetalhamento dos Decretos de Alteração Orçamentária

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getNroDecreto() {
        return nroDecreto;
    }

    public void setNroDecreto(int nroDecreto) {
        this.nroDecreto = nroDecreto;
    }

    public DateDetalhamento getDos() {
        return dos;
    }

    public void setDos(DateDetalhamento dos) {
        this.dos = dos;
    }

    public Decretos getDe() {
        return de;
    }

    public void setDe(Decretos de) {
        this.de = de;
    }

    public Alteração getOrçamentária() {
        return Orçamentária;
    }

    public void setOrçamentária(Alteração orçamentária) {
        Orçamentária = orçamentária;
    }

    dataDecreto;

}