//Nome do Arquivo:RSPDetalhamentoMovimentacaoRestosPagarPorCredor
//22 – RSP - DetalhamentoMovimentacaoRestosPagarPorCredor

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSPDetalhamentoMovimentacaoRestosPagarPorCredor{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoMov", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoMov;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoMov() {
        return codReduzidoMov;
    }

    public void setCodReduzidoMov(int codReduzidoMov) {
        this.codReduzidoMov = codReduzidoMov;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }
}