//Nome do Arquivo: Dispensa
//10 – Dispensa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

    public class Dispensa {

        @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
        int tipoRegistro;
        @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = true)
        String codOrgaoResp;
        @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = true)
        String codUnidadeSubResp;
        @SicomColumn(description = "ExercicioProcesso", length = 4, type = Type.INTEIRO, required = true)
        int exercicioProcesso;
        @SicomColumn(description = "NroProcesso", length = 12, type = Type.TEXTO, required = true)
        String nroProcesso;
        @SicomColumn(description = "TipoProcesso", length = 1, type = Type.INTEIRO, required = true)
        int tipoProcesso;
        @SicomColumn(description = "DtAbertura", length = 8, type = Type.DATA, required = true)
        Date dtAbertura;
        @SicomColumn(description = "NaturezaObjeto", length = 1, type = Type.INTEIRO, required = true)
        int naturezaObjeto;
        @SicomColumn(description = "Objeto", length = 500, type = Type.TEXTO, required = true)
        String objeto;
        @SicomColumn(description = "Justificativa", length = 250, type = Type.TEXTO, required = true)
        String justificativa;
        @SicomColumn(description = "Razao", length = 250, type = Type.TEXTO, required = true)
        String razao;
        @SicomColumn(description = "DtPublicacaoTermoRatificacao", length = 8, type = Type.DATA, required = true)
        Date dtPublicacaoTermoRatificacao;
        @SicomColumn(description = "VeiculoPublicacao", length = 50, type = Type.TEXTO, required = true)
        String veiculoPublicacao;
        @SicomColumn(description = "ProcessoPorLote", length = 1, type = Type.INTEIRO, required = true)
        int processoPorLote;

        public int getTipoRegistro() {
            return tipoRegistro;
        }

        public void setTipoRegistro(int tipoRegistro) {
            this.tipoRegistro = tipoRegistro;
        }

        public String getCodOrgaoResp() {
            return codOrgaoResp;
        }

        public void setCodOrgaoResp(String codOrgaoResp) {
            this.codOrgaoResp = codOrgaoResp;
        }

        public String getCodUnidadeSubResp() {
            return codUnidadeSubResp;
        }

        public void setCodUnidadeSubResp(String codUnidadeSubResp) {
            this.codUnidadeSubResp = codUnidadeSubResp;
        }

        public int getExercicioProcesso() {
            return exercicioProcesso;
        }

        public void setExercicioProcesso(int exercicioProcesso) {
            this.exercicioProcesso = exercicioProcesso;
        }

        public String getNroProcesso() {
            return nroProcesso;
        }

        public void setNroProcesso(String nroProcesso) {
            this.nroProcesso = nroProcesso;
        }

        public int getTipoProcesso() {
            return tipoProcesso;
        }

        public void setTipoProcesso(int tipoProcesso) {
            this.tipoProcesso = tipoProcesso;
        }

        public Date getDtAbertura() {
            return dtAbertura;
        }

        public void setDtAbertura(Date dtAbertura) {
            this.dtAbertura = dtAbertura;
        }

        public int getNaturezaObjeto() {
            return naturezaObjeto;
        }

        public void setNaturezaObjeto(int naturezaObjeto) {
            this.naturezaObjeto = naturezaObjeto;
        }

        public String getObjeto() {
            return objeto;
        }

        public void setObjeto(String objeto) {
            this.objeto = objeto;
        }

        public String getJustificativa() {
            return justificativa;
        }

        public void setJustificativa(String justificativa) {
            this.justificativa = justificativa;
        }

        public String getRazao() {
            return razao;
        }

        public void setRazao(String razao) {
            this.razao = razao;
        }

        public Date getDtPublicacaoTermoRatificacao() {
            return dtPublicacaoTermoRatificacao;
        }

        public void setDtPublicacaoTermoRatificacao(Date dtPublicacaoTermoRatificacao) {
            this.dtPublicacaoTermoRatificacao = dtPublicacaoTermoRatificacao;
        }

        public String getVeiculoPublicacao() {
            return veiculoPublicacao;
        }

        public void setVeiculoPublicacao(String veiculoPublicacao) {
            this.veiculoPublicacao = veiculoPublicacao;
        }

        public int getProcessoPorLote() {
            return processoPorLote;
        }

        public void setProcessoPorLote(int processoPorLote) {
            this.processoPorLote = processoPorLote;
        }
    }