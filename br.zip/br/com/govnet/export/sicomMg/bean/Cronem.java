//Nome do Arquivo:Cronem
//10 – Cronem
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Cronem{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "grupoDespesa", length = 1, type = Type.INTEIRO, required = true)
    int grupoDespesa;
    @SicomColumn(description = "vlDotMensal", length = 14, type = Type.DOUBLE, required = true)
    double vlDotMensal;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getGrupoDespesa() {
        return grupoDespesa;
    }

    public void setGrupoDespesa(int grupoDespesa) {
        this.grupoDespesa = grupoDespesa;
    }

    public double getVlDotMensal() {
        return vlDotMensal;
    }

    public void setVlDotMensal(double vlDotMensal) {
        this.vlDotMensal = vlDotMensal;
    }
}