//Nome do Arquivo:RSP
//10 – RSP

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSP{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoRSP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoRSP;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codUnidadeSubOrig", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSubOrig;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "exercicioEmpenho", length = 4, type = Type.INTEIRO, required = true)
    int exercicioEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "dotOrig", length = 17, type = Type.TEXTO, required = false)
    String dotOrig;
    @SicomColumn(description = "vlOriginal", length = 14, type = Type.DOUBLE, required = true)
    double vlOriginal;
    @SicomColumn(description = "vlSaldoAntProce", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAntProce;
    @SicomColumn(description = "vlSaldoAntNaoProc", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAntNaoProc;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoRSP() {
        return codReduzidoRSP;
    }

    public void setCodReduzidoRSP(int codReduzidoRSP) {
        this.codReduzidoRSP = codReduzidoRSP;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodUnidadeSubOrig() {
        return codUnidadeSubOrig;
    }

    public void setCodUnidadeSubOrig(String codUnidadeSubOrig) {
        this.codUnidadeSubOrig = codUnidadeSubOrig;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public int getExercicioEmpenho() {
        return exercicioEmpenho;
    }

    public void setExercicioEmpenho(int exercicioEmpenho) {
        this.exercicioEmpenho = exercicioEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public String getDotOrig() {
        return dotOrig;
    }

    public void setDotOrig(String dotOrig) {
        this.dotOrig = dotOrig;
    }

    public double getVlOriginal() {
        return vlOriginal;
    }

    public void setVlOriginal(double vlOriginal) {
        this.vlOriginal = vlOriginal;
    }

    public double getVlSaldoAntProce() {
        return vlSaldoAntProce;
    }

    public void setVlSaldoAntProce(double vlSaldoAntProce) {
        this.vlSaldoAntProce = vlSaldoAntProce;
    }

    public double getVlSaldoAntNaoProc() {
        return vlSaldoAntNaoProc;
    }

    public void setVlSaldoAntNaoProc(double vlSaldoAntNaoProc) {
        this.vlSaldoAntNaoProc = vlSaldoAntNaoProc;
    }
}