//Nome do Arquivo:EMP
//10 – EMP

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EMP{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;

    @SicomColumn(description = "", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;

    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;

    @SicomColumn(description = "codFuncao", length = 2, type = Type.TEXTO, required = true)
    String codFuncao;

    @SicomColumn(description = "codSubFuncao", length = 3, type = Type.TEXTO, required = true)
    String codSubFuncao;

    @SicomColumn(description = "codPrograma", length = 4, type = Type.TEXTO, required = true)
    String codPrograma;

    @SicomColumn(description = "idAcao", length = 4, type = Type.TEXTO, required = true)
    String idAcao;

    @SicomColumn(description = "idSubAcao", length = 4, type = Type.TEXTO, required = false)
    String idSubAcao;

    @SicomColumn(description = "naturezaDespesa", length = 6, type = Type.INTEIRO, required = true)
    int naturezaDespesa;

    @SicomColumn(description = "subElemento", length = 2, type = Type.TEXTO, required = true)
    String subElemento;

    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;

    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;

    @SicomColumn(description = "modalidadeEmpenho", length = 1, type = Type.INTEIRO, required = true)
    int modalidadeEmpenho;

    @SicomColumn(description = "tpEmpenho", length = 2, type = Type.TEXTO, required = true)
    String tpEmpenho;

    @SicomColumn(description = "vlBruto", length = 14, type = Type.DOUBLE, required = true)
    double vlBruto;

    @SicomColumn(description = "especificacaoEmpenho", length = 500, type = Type.TEXTO, required = true)
    String especificacaoEmpenho;

    @SicomColumn(description = "despDecContrato", length = 1, type = Type.INTEIRO, required = true)
    int despDecContrato;

    @SicomColumn(description = "codOrgaoRespContrato", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoRespContrato;

    @SicomColumn(description = "codUnidadeSubRespContrato", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubRespContrato;

    @SicomColumn(description = "nroContrato", length = 14, type = Type.INTEIRO, required = false)
    int nroContrato;

    @SicomColumn(description = "dataAssinaturaContrato", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaContrato;

    @SicomColumn(description = "nroSequencialTermoAditivo", length = 2, type = Type.INTEIRO, required = false)
    int nroSequencialTermoAditivo;

    @SicomColumn(description = "despDecConvenio", length = 1, type = Type.INTEIRO, required = true)
    int despDecConvenio;

    @SicomColumn(description = "nroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;

    @SicomColumn(description = "dataAssinaturaConvenio", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConvenio;

    @SicomColumn(description = "despDecConvenioConge", length = 1, type = Type.INTEIRO, required = true)
    int despDecConvenioConge;

    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = false)
    String nroConvenioConge;

    @SicomColumn(description = "dataAssinaturaConge", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConge;

    @SicomColumn(description = "despDecLicitacao", length = 1, type = Type.INTEIRO, required = true)
    int despDecLicitacao;

    @SicomColumn(description = "CodOrgaoRespLicit", length = 2, type = Type.TEXTO, required = false)
    String CodOrgaoRespLicit;

    @SicomColumn(description = "codUnidadeSubRespLicit", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubRespLicit;

    @SicomColumn(description = "nroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = false)
    String nroProcessoLicitatorio;

    @SicomColumn(description = "exercicioProcessoLicitatorio", length = 4, type = Type.INTEIRO, required = false)
    int exercicioProcessoLicitatorio;

    @SicomColumn(description = "tipoProcesso", length = 1, type = Type.INTEIRO, required = false)
    int tipoProcesso;

    @SicomColumn(description = "cpfOrdenador", length = 11, type = Type.TEXTO, required = true)
    String cpfOrdenador;

    @SicomColumn(description = "tipoDespesaEmpRPPS", length = 1, type = Type.INTEIRO, required = false)
    int tipoDespesaEmpRPPS;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodFuncao() {
        return codFuncao;
    }

    public void setCodFuncao(String codFuncao) {
        this.codFuncao = codFuncao;
    }

    public String getCodSubFuncao() {
        return codSubFuncao;
    }

    public void setCodSubFuncao(String codSubFuncao) {
        this.codSubFuncao = codSubFuncao;
    }

    public String getCodPrograma() {
        return codPrograma;
    }

    public void setCodPrograma(String codPrograma) {
        this.codPrograma = codPrograma;
    }

    public String getIdAcao() {
        return idAcao;
    }

    public void setIdAcao(String idAcao) {
        this.idAcao = idAcao;
    }

    public String getIdSubAcao() {
        return idSubAcao;
    }

    public void setIdSubAcao(String idSubAcao) {
        this.idSubAcao = idSubAcao;
    }

    public int getNaturezaDespesa() {
        return naturezaDespesa;
    }

    public void setNaturezaDespesa(int naturezaDespesa) {
        this.naturezaDespesa = naturezaDespesa;
    }

    public String getSubElemento() {
        return subElemento;
    }

    public void setSubElemento(String subElemento) {
        this.subElemento = subElemento;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getModalidadeEmpenho() {
        return modalidadeEmpenho;
    }

    public void setModalidadeEmpenho(int modalidadeEmpenho) {
        this.modalidadeEmpenho = modalidadeEmpenho;
    }

    public String getTpEmpenho() {
        return tpEmpenho;
    }

    public void setTpEmpenho(String tpEmpenho) {
        this.tpEmpenho = tpEmpenho;
    }

    public double getVlBruto() {
        return vlBruto;
    }

    public void setVlBruto(double vlBruto) {
        this.vlBruto = vlBruto;
    }

    public String getEspecificacaoEmpenho() {
        return especificacaoEmpenho;
    }

    public void setEspecificacaoEmpenho(String especificacaoEmpenho) {
        this.especificacaoEmpenho = especificacaoEmpenho;
    }

    public int getDespDecContrato() {
        return despDecContrato;
    }

    public void setDespDecContrato(int despDecContrato) {
        this.despDecContrato = despDecContrato;
    }

    public String getCodOrgaoRespContrato() {
        return codOrgaoRespContrato;
    }

    public void setCodOrgaoRespContrato(String codOrgaoRespContrato) {
        this.codOrgaoRespContrato = codOrgaoRespContrato;
    }

    public String getCodUnidadeSubRespContrato() {
        return codUnidadeSubRespContrato;
    }

    public void setCodUnidadeSubRespContrato(String codUnidadeSubRespContrato) {
        this.codUnidadeSubRespContrato = codUnidadeSubRespContrato;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public date getDataAssinaturaContrato() {
        return dataAssinaturaContrato;
    }

    public void setDataAssinaturaContrato(date dataAssinaturaContrato) {
        this.dataAssinaturaContrato = dataAssinaturaContrato;
    }

    public int getNroSequencialTermoAditivo() {
        return nroSequencialTermoAditivo;
    }

    public void setNroSequencialTermoAditivo(int nroSequencialTermoAditivo) {
        this.nroSequencialTermoAditivo = nroSequencialTermoAditivo;
    }

    public int getDespDecConvenio() {
        return despDecConvenio;
    }

    public void setDespDecConvenio(int despDecConvenio) {
        this.despDecConvenio = despDecConvenio;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public date getDataAssinaturaConvenio() {
        return dataAssinaturaConvenio;
    }

    public void setDataAssinaturaConvenio(date dataAssinaturaConvenio) {
        this.dataAssinaturaConvenio = dataAssinaturaConvenio;
    }

    public int getDespDecConvenioConge() {
        return despDecConvenioConge;
    }

    public void setDespDecConvenioConge(int despDecConvenioConge) {
        this.despDecConvenioConge = despDecConvenioConge;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConge() {
        return dataAssinaturaConge;
    }

    public void setDataAssinaturaConge(date dataAssinaturaConge) {
        this.dataAssinaturaConge = dataAssinaturaConge;
    }

    public int getDespDecLicitacao() {
        return despDecLicitacao;
    }

    public void setDespDecLicitacao(int despDecLicitacao) {
        this.despDecLicitacao = despDecLicitacao;
    }

    public String getCodOrgaoRespLicit() {
        return CodOrgaoRespLicit;
    }

    public void setCodOrgaoRespLicit(String codOrgaoRespLicit) {
        CodOrgaoRespLicit = codOrgaoRespLicit;
    }

    public String getCodUnidadeSubRespLicit() {
        return codUnidadeSubRespLicit;
    }

    public void setCodUnidadeSubRespLicit(String codUnidadeSubRespLicit) {
        this.codUnidadeSubRespLicit = codUnidadeSubRespLicit;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getExercicioProcessoLicitatorio() {
        return exercicioProcessoLicitatorio;
    }

    public void setExercicioProcessoLicitatorio(int exercicioProcessoLicitatorio) {
        this.exercicioProcessoLicitatorio = exercicioProcessoLicitatorio;
    }

    public int getTipoProcesso() {
        return tipoProcesso;
    }

    public void setTipoProcesso(int tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }

    public String getCpfOrdenador() {
        return cpfOrdenador;
    }

    public void setCpfOrdenador(String cpfOrdenador) {
        this.cpfOrdenador = cpfOrdenador;
    }

    public int getTipoDespesaEmpRPPS() {
        return tipoDespesaEmpRPPS;
    }

    public void setTipoDespesaEmpRPPS(int tipoDespesaEmpRPPS) {
        this.tipoDespesaEmpRPPS = tipoDespesaEmpRPPS;
    }
}