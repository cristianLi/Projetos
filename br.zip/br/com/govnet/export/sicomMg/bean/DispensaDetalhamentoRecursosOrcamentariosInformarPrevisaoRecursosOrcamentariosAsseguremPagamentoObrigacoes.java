//Nome do Arquivo: Dispensa
//10 – Dispensa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DispensaDetalhamentoRecursosOrcamentariosInformarPrevisaoRecursosOrcamentariosAsseguremPagamentoObrigacoe {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = true)
    String codOrgaoResp;
    @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSubResp;
    @SicomColumn(description = "ExercicioProcesso", length = 4, type = Type.INTEIRO, required = true)
    int exercicioProcesso;
    @SicomColumn(description = "NroProcesso", length = 12, type = Type.TEXTO, required = true)
    String nroProcesso;
    @SicomColumn(description = "TipoProcesso", length = 1, type = Type.INTEIRO, required = true)
    int tipoProcesso;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "CodFuncao", length = 2, type = Type.TEXTO, required = true)
    String codFuncao;
    @SicomColumn(description = "CodSubFuncao", length = 3, type = Type.TEXTO, required = true)
    String codSubFuncao;
    @SicomColumn(description = "CodPrograma", length = 4, type = Type.TEXTO, required = true)
    String codPrograma;
    @SicomColumn(description = "IdAcao", length = 4, type = Type.TEXTO, required = true)
    String idAcao;
    @SicomColumn(description = "IdSubAcao", length = 4, type = Type.TEXTO, required = true)
    String idSubAcao;
    @SicomColumn(description = "NaturezaDespesa", length = 6, type = Type.INTEIRO, required = true)
    int naturezaDespesa;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlRecurso", length = 14, type = Type.DOUBLE, required = true)
    double vlRecurso;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgaoResp() {
        return codOrgaoResp;
    }

    public void setCodOrgaoResp(String codOrgaoResp) {
        this.codOrgaoResp = codOrgaoResp;
    }

    public String getCodUnidadeSubResp() {
        return codUnidadeSubResp;
    }

    public void setCodUnidadeSubResp(String codUnidadeSubResp) {
        this.codUnidadeSubResp = codUnidadeSubResp;
    }

    public int getExercicioProcesso() {
        return exercicioProcesso;
    }

    public void setExercicioProcesso(int exercicioProcesso) {
        this.exercicioProcesso = exercicioProcesso;
    }

    public String getNroProcesso() {
        return nroProcesso;
    }

    public void setNroProcesso(String nroProcesso) {
        this.nroProcesso = nroProcesso;
    }

    public int getTipoProcesso() {
        return tipoProcesso;
    }

    public void setTipoProcesso(int tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodFuncao() {
        return codFuncao;
    }

    public void setCodFuncao(String codFuncao) {
        this.codFuncao = codFuncao;
    }

    public String getCodSubFuncao() {
        return codSubFuncao;
    }

    public void setCodSubFuncao(String codSubFuncao) {
        this.codSubFuncao = codSubFuncao;
    }

    public String getCodPrograma() {
        return codPrograma;
    }

    public void setCodPrograma(String codPrograma) {
        this.codPrograma = codPrograma;
    }

    public String getIdAcao() {
        return idAcao;
    }

    public void setIdAcao(String idAcao) {
        this.idAcao = idAcao;
    }

    public String getIdSubAcao() {
        return idSubAcao;
    }

    public void setIdSubAcao(String idSubAcao) {
        this.idSubAcao = idSubAcao;
    }

    public int getNaturezaDespesa() {
        return naturezaDespesa;
    }

    public void setNaturezaDespesa(int naturezaDespesa) {
        this.naturezaDespesa = naturezaDespesa;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlRecurso() {
        return vlRecurso;
    }

    public void setVlRecurso(double vlRecurso) {
        this.vlRecurso = vlRecurso;
    }
}