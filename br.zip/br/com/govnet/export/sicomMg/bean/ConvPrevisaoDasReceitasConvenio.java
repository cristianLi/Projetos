//Nome do Arquivo:ConvPrevisaoDasReceitasConvenio
//30 – Conv - PrevisaoDasReceitasConvenio

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ConvPrevisaoDasReceitasConvenio{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReceita", length = 15, type = Type.INTEIRO, required = true)
    int codReceita;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NaturezaReceita", length = 8, type = Type.INTEIRO, required = true)
    int naturezaReceita;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlPrevisao", length = 14, type = Type.DOUBLE, required = true)
    double vlPrevisao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReceita() {
        return codReceita;
    }

    public void setCodReceita(int codReceita) {
        this.codReceita = codReceita;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getNaturezaReceita() {
        return naturezaReceita;
    }

    public void setNaturezaReceita(int naturezaReceita) {
        this.naturezaReceita = naturezaReceita;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlPrevisao() {
        return vlPrevisao;
    }

    public void setVlPrevisao(double vlPrevisao) {
        this.vlPrevisao = vlPrevisao;
    }
}