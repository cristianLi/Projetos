//Nome do Arquivo:DCLRFPublicacaoPeriodicidadeRGFDaLRF
//40 – DCLRF - PublicacaoPeriodicidadeRGFDaLRF
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DCLRFPublicacaoPeriodicidadeRGFDaLRF{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "publicRGF", length = 1, type = Type.INTEIRO, required = true)
    int publicRGF;
    @SicomColumn(description = "dtPublicacaoRGF", length = 8, type = Type.DATA, required = false)
    date dtPublicacaoRGF;
    @SicomColumn(description = "localPublicacaoRGF", length = 1000, type = Type.TEXTO, required = false)
    String localPublicacaoRGF;
    @SicomColumn(description = "tpPeriodo", length = 1, type = Type.INTEIRO, required = false)
    int tpPeriodo;
    @SicomColumn(description = "exercicioTpPeriodo", length = 4, type = Type.INTEIRO, required = false)
    int exercicioTpPeriodo;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getPublicRGF() {
        return publicRGF;
    }

    public void setPublicRGF(int publicRGF) {
        this.publicRGF = publicRGF;
    }

    public date getDtPublicacaoRGF() {
        return dtPublicacaoRGF;
    }

    public void setDtPublicacaoRGF(date dtPublicacaoRGF) {
        this.dtPublicacaoRGF = dtPublicacaoRGF;
    }

    public String getLocalPublicacaoRGF() {
        return localPublicacaoRGF;
    }

    public void setLocalPublicacaoRGF(String localPublicacaoRGF) {
        this.localPublicacaoRGF = localPublicacaoRGF;
    }

    public int getTpPeriodo() {
        return tpPeriodo;
    }

    public void setTpPeriodo(int tpPeriodo) {
        this.tpPeriodo = tpPeriodo;
    }

    public int getExercicioTpPeriodo() {
        return exercicioTpPeriodo;
    }

    public void setExercicioTpPeriodo(int exercicioTpPeriodo) {
        this.exercicioTpPeriodo = exercicioTpPeriodo;
    }
}

