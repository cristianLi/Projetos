//Nome do Arquivo:ContratosDetalhamentoDostensContratados
//11 – Contratos - DetalhamentoDostensContratados

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ContratosDetalhamentoDostensContratados{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodContrato", length = 15, type = Type.INTEIRO, required = true)
    int codContrato;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "QuantidadeItem", length = 14, type = Type.DOUBLE, required = true)
    double quantidadeItem;
    @SicomColumn(description = "ValorUnitarioItem", length = 14, type = Type.DOUBLE, required = true)
    double valorUnitarioItem;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodContrato() {
        return codContrato;
    }

    public void setCodContrato(int codContrato) {
        this.codContrato = codContrato;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public double getQuantidadeItem() {
        return quantidadeItem;
    }

    public void setQuantidadeItem(double quantidadeItem) {
        this.quantidadeItem = quantidadeItem;
    }

    public double getValorUnitarioItem() {
        return valorUnitarioItem;
    }

    public void setValorUnitarioItem(double valorUnitarioItem) {
        this.valorUnitarioItem = valorUnitarioItem;
    }
}