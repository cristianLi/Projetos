//Nome do Arquivo:CTBSaldosBancariosAgentesArrecadadoresPorFonteRecurso
//31 – CTB - SaldosBancariosAgentesArrecadadoresPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class CTBSaldosBancariosAgentesArrecadadoresPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodAgenteArrecadador", length = 15, type = Type.INTEIRO, required = true)
    int codAgenteArrecadador;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlSaldoInicialAgFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoInicialAgFonte;
    @SicomColumn(description = "VlEntradaFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlEntradaFonte;
    @SicomColumn(description = "VlSaidaFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaidaFonte;
    @SicomColumn(description = "VlSaldoFinalAgFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinalAgFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodAgenteArrecadador() {
        return codAgenteArrecadador;
    }

    public void setCodAgenteArrecadador(int codAgenteArrecadador) {
        this.codAgenteArrecadador = codAgenteArrecadador;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlSaldoInicialAgFonte() {
        return vlSaldoInicialAgFonte;
    }

    public void setVlSaldoInicialAgFonte(double vlSaldoInicialAgFonte) {
        this.vlSaldoInicialAgFonte = vlSaldoInicialAgFonte;
    }

    public double getVlEntradaFonte() {
        return vlEntradaFonte;
    }

    public void setVlEntradaFonte(double vlEntradaFonte) {
        this.vlEntradaFonte = vlEntradaFonte;
    }

    public double getVlSaidaFonte() {
        return vlSaidaFonte;
    }

    public void setVlSaidaFonte(double vlSaidaFonte) {
        this.vlSaidaFonte = vlSaidaFonte;
    }

    public double getVlSaldoFinalAgFonte() {
        return vlSaldoFinalAgFonte;
    }

    public void setVlSaldoFinalAgFonte(double vlSaldoFinalAgFonte) {
        this.vlSaldoFinalAgFonte = vlSaldoFinalAgFonte;
    }
}