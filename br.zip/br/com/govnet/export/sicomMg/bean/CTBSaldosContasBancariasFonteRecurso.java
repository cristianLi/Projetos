//Nome do Arquivo:CTBSaldosContasBancariasFonteRecurso
//20 – CTB - SaldosContasBancariasFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public CTBSaldosContasBancariasFonteRecurso{
    
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "Tipo do registro", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "Tipo do registro", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlSaldoInicialFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoInicialFonte;
    @SicomColumn(description = "VlSaldoFinalFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinalFonte;
    
    public int getTipoRegistro(){
        return tipoRegistro;
    }
    public int setTipoRegistro(){
        return tipoRegistro;
    }
    public String getCodOrgao(){
        return codOrgao;
    }
    public String setCodOrgao(){
        return codOrgao;
    }
    public int getCodCTB(){
        return codCTB;
    }
    public int setCodCTB(){
        return codCTB;
    }
    public int getCodFontRecursos(){
        return codFontRecursos;
    }
    public int setCodFontRecursos(){
        return codFontRecursos;
    }
    public double getVlSaldoInicialFonte(){
        return vlSaldoInicialFonte;
    }
    public double setVlSaldoInicialFonte(){
        return vlSaldoInicialFonte;
    }
    public double getVlSaldoFinalFonte(){
        return vlSaldoFinalFonte;
    }
    public double setVlSaldoFinalFonte(){
        return vlSaldoFinalFonte;
    }
}