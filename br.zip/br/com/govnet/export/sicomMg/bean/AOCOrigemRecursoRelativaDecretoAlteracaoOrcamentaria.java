//Nome do Arquivo: AOCOrigemRecursoRelativaDecretoAlteracaoOrcamentaria
//13 – AOC - OrigemRecursoRelativaDecretoAlteracaoOrcamentaria

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class AOCOrigemRecursoRelativaDecretoAlteracaoOrcamentaria{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzidoDecreto", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoDecreto;
    @SicomColumn(description = "OrigemRecAlteracao", length = 2, type = Type.TEXTO, required = true)
    String origemRecAlteracao;
    @SicomColumn(description = "ValorAbertoOrigem", length = 14, type = Type.DOUBLE, required = true)
    double valorAbertoOrigem;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoDecreto() {
        return codReduzidoDecreto;
    }

    public void setCodReduzidoDecreto(int codReduzidoDecreto) {
        this.codReduzidoDecreto = codReduzidoDecreto;
    }

    public String getOrigemRecAlteracao() {
        return origemRecAlteracao;
    }

    public void setOrigemRecAlteracao(String origemRecAlteracao) {
        this.origemRecAlteracao = origemRecAlteracao;
    }

    public double getValorAbertoOrigem() {
        return valorAbertoOrigem;
    }

    public void setValorAbertoOrigem(double valorAbertoOrigem) {
        this.valorAbertoOrigem = valorAbertoOrigem;
    }
}