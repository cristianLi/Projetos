//Nome do Arquivo:DDC
//10 – DDC
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DDC{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "nroLeiAutorizacao", length = 2, type = Type.TEXTO, required = true)
    String nroLeiAutorizacao;
    @SicomColumn(description = "dtLeiAutorizacao", length = 8, type = Type.DATA, required = true)
    date dtLeiAutorizacao;
    @SicomColumn(description = "dtPublicacaoLeiAutorizacao", length = 8, type = Type.DATA, required = true)
    date dtPublicacaoLeiAutorizacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroLeiAutorizacao() {
        return nroLeiAutorizacao;
    }

    public void setNroLeiAutorizacao(String nroLeiAutorizacao) {
        this.nroLeiAutorizacao = nroLeiAutorizacao;
    }

    public date getDtLeiAutorizacao() {
        return dtLeiAutorizacao;
    }

    public void setDtLeiAutorizacao(date dtLeiAutorizacao) {
        this.dtLeiAutorizacao = dtLeiAutorizacao;
    }

    public date getDtPublicacaoLeiAutorizacao() {
        return dtPublicacaoLeiAutorizacao;
    }

    public void setDtPublicacaoLeiAutorizacao(date dtPublicacaoLeiAutorizacao) {
        this.dtPublicacaoLeiAutorizacao = dtPublicacaoLeiAutorizacao;
    }
}