package br.com.govnet.export.sicomMg;

public enum Type {
    TEXTO,
    INTEIRO,
    DATA,
    DOUBLE,
}
