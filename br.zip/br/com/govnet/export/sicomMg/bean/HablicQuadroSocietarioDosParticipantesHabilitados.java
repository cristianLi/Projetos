//Nome do Arquivo: HablicQuadroSocietarioDosParticipantesHabilitados
//10 – Hablic - QuadroSocietarioDosParticipantesHabilitados

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class HablicQuadroSocietarioDosParticipantesHabilitados{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "TipoDocumentoCNPJEmpresaHablic", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoCNPJEmpresaHablic;
    @SicomColumn(description = "CNPJEmpresaHablic", length = 14, type = Type.TEXTO, required = true)
    String CNPJEmpresaHablic;
    @SicomColumn(description = "TipoDocumentoSocio", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoSocio;
    @SicomColumn(description = "NroDocumentoSocio", length = 14, type = Type.TEXTO, required = true)
    String nroDocumentoSocio;
    @SicomColumn(description = "TipoParticipacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoParticipacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getTipoDocumentoCNPJEmpresaHablic() {
        return tipoDocumentoCNPJEmpresaHablic;
    }

    public void setTipoDocumentoCNPJEmpresaHablic(int tipoDocumentoCNPJEmpresaHablic) {
        this.tipoDocumentoCNPJEmpresaHablic = tipoDocumentoCNPJEmpresaHablic;
    }

    public String getCNPJEmpresaHablic() {
        return CNPJEmpresaHablic;
    }

    public void setCNPJEmpresaHablic(String CNPJEmpresaHablic) {
        this.CNPJEmpresaHablic = CNPJEmpresaHablic;
    }

    public int getTipoDocumentoSocio() {
        return tipoDocumentoSocio;
    }

    public void setTipoDocumentoSocio(int tipoDocumentoSocio) {
        this.tipoDocumentoSocio = tipoDocumentoSocio;
    }

    public String getNroDocumentoSocio() {
        return nroDocumentoSocio;
    }

    public void setNroDocumentoSocio(String nroDocumentoSocio) {
        this.nroDocumentoSocio = nroDocumentoSocio;
    }

    public int getTipoParticipacao() {
        return tipoParticipacao;
    }

    public void setTipoParticipacao(int tipoParticipacao) {
        this.tipoParticipacao = tipoParticipacao;
    }
}