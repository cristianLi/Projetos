//Nome do Arquivo:CuteDetalhamentoMovimentacaoContaUnica
//21 – Cute - DetalhamentoMovimentacaoContaUnica

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CuteDetalhamentoMovimentacaoContaUnica{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "tipoMovimentacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoMovimentacao;
    @SicomColumn(description = "tipoEntrSaida", length = 2, type = Type.TEXTO, required = true)
    String tipoEntrSaida;
    @SicomColumn(description = "valorEntrSaida", length = 14, type = Type.DOUBLE, required = true)
    double valorEntrSaida;
    @SicomColumn(description = "codOrgaoTransf", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoTransf;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public int getTipoMovimentacao() {
        return tipoMovimentacao;
    }

    public void setTipoMovimentacao(int tipoMovimentacao) {
        this.tipoMovimentacao = tipoMovimentacao;
    }

    public String getTipoEntrSaida() {
        return tipoEntrSaida;
    }

    public void setTipoEntrSaida(String tipoEntrSaida) {
        this.tipoEntrSaida = tipoEntrSaida;
    }

    public double getValorEntrSaida() {
        return valorEntrSaida;
    }

    public void setValorEntrSaida(double valorEntrSaida) {
        this.valorEntrSaida = valorEntrSaida;
    }

    public String getCodOrgaoTransf() {
        return codOrgaoTransf;
    }

    public void setCodOrgaoTransf(String codOrgaoTransf) {
        this.codOrgaoTransf = codOrgaoTransf;
    }
}