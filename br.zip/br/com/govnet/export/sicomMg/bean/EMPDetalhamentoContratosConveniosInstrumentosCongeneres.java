//Nome do Arquivo:EMPDetalhamentoContratosConveniosInstrumentosCongeneres
//30 – EMP - DetalhamentoContratosConveniosInstrumentosCongeneres

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EMPDetalhamentoContratosConveniosInstrumentosCongeneres{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;

    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;

    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;

    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;


    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;


    @SicomColumn(description = "codOrgaoRespContrato", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoRespContrato;


    @SicomColumn(description = "codUnidadeSubRespContrato", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubRespContrato;


    @SicomColumn(description = "nroContrato", length = 14, type = Type.INTEIRO, required = false)
    int nroContrato;


    @SicomColumn(description = "dataAssinaturaContrato", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaContrato;


    @SicomColumn(description = "nroSequencialTermoAditivo", length = 2, type = Type.INTEIRO, required = false)
    int nroSequencialTermoAditivo;


    @SicomColumn(description = "nroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;


    @SicomColumn(description = "dataAssinaturaConvenio", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConvenio;


    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = false)
    String nroConvenioConge;


    @SicomColumn(description = "dataAssinaturaConge", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConge;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public String getCodOrgaoRespContrato() {
        return codOrgaoRespContrato;
    }

    public void setCodOrgaoRespContrato(String codOrgaoRespContrato) {
        this.codOrgaoRespContrato = codOrgaoRespContrato;
    }

    public String getCodUnidadeSubRespContrato() {
        return codUnidadeSubRespContrato;
    }

    public void setCodUnidadeSubRespContrato(String codUnidadeSubRespContrato) {
        this.codUnidadeSubRespContrato = codUnidadeSubRespContrato;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public date getDataAssinaturaContrato() {
        return dataAssinaturaContrato;
    }

    public void setDataAssinaturaContrato(date dataAssinaturaContrato) {
        this.dataAssinaturaContrato = dataAssinaturaContrato;
    }

    public int getNroSequencialTermoAditivo() {
        return nroSequencialTermoAditivo;
    }

    public void setNroSequencialTermoAditivo(int nroSequencialTermoAditivo) {
        this.nroSequencialTermoAditivo = nroSequencialTermoAditivo;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public date getDataAssinaturaConvenio() {
        return dataAssinaturaConvenio;
    }

    public void setDataAssinaturaConvenio(date dataAssinaturaConvenio) {
        this.dataAssinaturaConvenio = dataAssinaturaConvenio;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConge() {
        return dataAssinaturaConge;
    }

    public void setDataAssinaturaConge(date dataAssinaturaConge) {
        this.dataAssinaturaConge = dataAssinaturaConge;
    }
}