package br.com.govnet.export.sicomMg;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface SicomColumn {
    String name() default "";

    String description() default "";

    int length() default 1;

    Type type() default Type.TEXTO;

    boolean required() default false;
}

