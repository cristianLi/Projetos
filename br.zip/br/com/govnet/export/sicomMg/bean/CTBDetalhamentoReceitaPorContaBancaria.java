//Nome do Arquivo:CTBDetalhamentoReceitaPorContaBancaria
//22 – CTB - DetalhamentoReceitaPorContaBancaria

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CTBDetalhamentoReceitaPorContaBancaria{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzidoMOV", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoMOV;
    @SicomColumn(description = "EDeducaoDeReceita", length = 1, type = Type.INTEIRO, required = true)
    int eDeducaoDeReceita;
    @SicomColumn(description = "IdentificadorDeducao", length = 2, type = Type.INTEIRO, required = false)
    int identificadorDeducao;
    @SicomColumn(description = "NaturezaReceita", length = 8, type = Type.INTEIRO, required = true)
    int naturezaReceita;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlrReceitaCont", length = 14, type = Type.DOUBLE, required = true)
    double vlrReceitaCont;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoMOV() {
        return codReduzidoMOV;
    }

    public void setCodReduzidoMOV(int codReduzidoMOV) {
        this.codReduzidoMOV = codReduzidoMOV;
    }

    public int geteDeducaoDeReceita() {
        return eDeducaoDeReceita;
    }

    public void seteDeducaoDeReceita(int eDeducaoDeReceita) {
        this.eDeducaoDeReceita = eDeducaoDeReceita;
    }

    public int getIdentificadorDeducao() {
        return identificadorDeducao;
    }

    public void setIdentificadorDeducao(int identificadorDeducao) {
        this.identificadorDeducao = identificadorDeducao;
    }

    public int getNaturezaReceita() {
        return naturezaReceita;
    }

    public void setNaturezaReceita(int naturezaReceita) {
        this.naturezaReceita = naturezaReceita;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlrReceitaCont() {
        return vlrReceitaCont;
    }

    public void setVlrReceitaCont(double vlrReceitaCont) {
        this.vlrReceitaCont = vlrReceitaCont;
    }
}