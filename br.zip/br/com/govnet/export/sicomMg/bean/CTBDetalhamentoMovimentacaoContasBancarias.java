//Nome do Arquivo:CTBDetalhamentoMovimentacaoContasBancarias
//21 – CTB - DetalhamentoMovimentacaoContasBancarias

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CTBDetalhamentoMovimentacaoContasBancarias{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "CodReduzidoMOV", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoMOV;
    @SicomColumn(description = "TipoMovimentacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoMovimentacao;
    @SicomColumn(description = "TipoEntrSaida", length = 2, type = Type.TEXTO, required = true)
    String tipoEntrSaida;
    @SicomColumn(description = "DscOutrasMov", length = 50, type = Type.TEXTO, required = false)
    String dscOutrasMov;
    @SicomColumn(description = "ValorEntrSaida", length = 14, type = Type.DOUBLE, required = true)
    double valorEntrSaida;
    @SicomColumn(description = "CodCTBTransf", length = 20, type = Type.INTEIRO, required = false)
    int codCTBTransf;
    @SicomColumn(description = "CodFonteCTBTransf", length = 3, type = Type.INTEIRO, required = false)
    int codFonteCTBTransf;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public int getCodReduzidoMOV() {
        return codReduzidoMOV;
    }

    public void setCodReduzidoMOV(int codReduzidoMOV) {
        this.codReduzidoMOV = codReduzidoMOV;
    }

    public int getTipoMovimentacao() {
        return tipoMovimentacao;
    }

    public void setTipoMovimentacao(int tipoMovimentacao) {
        this.tipoMovimentacao = tipoMovimentacao;
    }

    public String getTipoEntrSaida() {
        return tipoEntrSaida;
    }

    public void setTipoEntrSaida(String tipoEntrSaida) {
        this.tipoEntrSaida = tipoEntrSaida;
    }

    public String getDscOutrasMov() {
        return dscOutrasMov;
    }

    public void setDscOutrasMov(String dscOutrasMov) {
        this.dscOutrasMov = dscOutrasMov;
    }

    public double getValorEntrSaida() {
        return valorEntrSaida;
    }

    public void setValorEntrSaida(double valorEntrSaida) {
        this.valorEntrSaida = valorEntrSaida;
    }

    public int getCodCTBTransf() {
        return codCTBTransf;
    }

    public void setCodCTBTransf(int codCTBTransf) {
        this.codCTBTransf = codCTBTransf;
    }

    public int getCodFonteCTBTransf() {
        return codFonteCTBTransf;
    }

    public void setCodFonteCTBTransf(int codFonteCTBTransf) {
        this.codFonteCTBTransf = codFonteCTBTransf;
    }
}