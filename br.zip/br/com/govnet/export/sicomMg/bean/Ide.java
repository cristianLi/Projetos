//Nome do Arquivo: IDE
package br.com.govnet.export.sicomMg.bean;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

import java.util.Date;

public class Ide {

    @SicomColumn(description = "Código do Município", length = 5, type = Type.TEXTO, required = true)
    String codMunicipio;
    @SicomColumn(description = "CNPJ do Município", length = 14, type = Type.TEXTO, required = true)
    String cnpjMunicipio;
    @SicomColumn(description = "Código do órgão", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "Tipo do órgão", length = 2, type = Type.TEXTO, required = true)
    String tipoOrgao;
    @SicomColumn(description = "Exercício de referência dos arquivos", length = 4, type = Type.INTEIRO, required = true)
    int exercicioReferencia;
    @SicomColumn(description = "Mês de referência dos arquivos", length = 2, type = Type.INTEIRO, required = true)
    int mesReferencia;
    @SicomColumn(description = "Data de geração do arquivo", length = 8, type = Type.DATA, required = true)
    Date dataGeracao;
    @SicomColumn(description = "Código de controle externo da remessa", length = 20, type = Type.DATA, required = true)
    String codControleRemessa;

    public String getCodMunicipio() {
        return codMunicipio;
    }

    public void setCodMunicipio(String codMunicipio) {
        this.codMunicipio = codMunicipio;
    }

    public String getCnpjMunicipio() {
        return cnpjMunicipio;
    }

    public void setCnpjMunicipio(String cnpjMunicipio) {
        this.cnpjMunicipio = cnpjMunicipio;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getTipoOrgao() {
        return tipoOrgao;
    }

    public void setTipoOrgao(String tipoOrgao) {
        this.tipoOrgao = tipoOrgao;
    }

    public int getExercicioReferencia() {
        return exercicioReferencia;
    }

    public void setExercicioReferencia(int exercicioReferencia) {
        this.exercicioReferencia = exercicioReferencia;
    }

    public int getMesReferencia() {
        return mesReferencia;
    }

    public void setMesReferencia(int mesReferencia) {
        this.mesReferencia = mesReferencia;
    }

    public Date getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(Date dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public String getCodControleRemessa() {
        return codControleRemessa;
    }

    public void setCodControleRemessa(String codControleRemessa) {
        this.codControleRemessa = codControleRemessa;
    }
}
