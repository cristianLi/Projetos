//Nome do Arquivo: PESSOA
//10 – Cadastro de Pessoas
//Propósito: Cadastrar pessoas físicas e jurídicas que serão referenciadas posteriormente em todo o leiaute.
//OBS: Devem ser cadastradas uma única vez. Após o cadastro, utilizar o número do documento da pessoa para referenciá-la no mês de cadastro e nos meses e exercícios subsequentes.


package br.com.govnet.export.sicomMg.bean;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Pessoa {
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "Tipo do documento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "Número do documento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "Número do documento", length = 120, type = Type.TEXTO, required = true)
    String nomeRazaoSocial;
    @SicomColumn(description = "Tipo de Cadastro", length = 1, type = Type.TEXTO, required = true)
    int tipoCadastro;
    @SicomColumn(description = "Justificativa para a alteração", length = 100, type = Type.TEXTO)
    String justificativaAlteracao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }

    public void setNomeRazaoSocial(String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }

    public int getTipoCadastro() {
        return tipoCadastro;
    }

    public void setTipoCadastro(int tipoCadastro) {
        this.tipoCadastro = tipoCadastro;
    }

    public String getJustificativaAlteracao() {
        return justificativaAlteracao;
    }

    public void setJustificativaAlteracao(String justificativaAlteracao) {
        this.justificativaAlteracao = justificativaAlteracao;
    }
}
