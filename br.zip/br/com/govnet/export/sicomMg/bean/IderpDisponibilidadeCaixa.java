//Nome do Arquivo:IderpDisponibilidadeCaixa
//20 – Iderp - DisponibilidadeCaixa
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class IderpDisponibilidadeCaixa{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlCaixaBruta", length = 14, type = Type.DOUBLE, required = true)
    double vlCaixaBruta;
    @SicomColumn(description = "vlRspExerciciosAnteriores", length = 14, type = Type.DOUBLE, required = true)
    double vlRspExerciciosAnteriores;
    @SicomColumn(description = "vlRestituiveisRecolher", length = 14, type = Type.DOUBLE, required = true)
    double vlRestituiveisRecolher;
    @SicomColumn(description = "vlRestituiveisAtivoFinanceiro", length = 14, type = Type.DOUBLE, required = true)
    double vlRestituiveisAtivoFinanceiro;
    @SicomColumn(description = "vlSaldoDispCaixa", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoDispCaixa;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlCaixaBruta() {
        return vlCaixaBruta;
    }

    public void setVlCaixaBruta(double vlCaixaBruta) {
        this.vlCaixaBruta = vlCaixaBruta;
    }

    public double getVlRspExerciciosAnteriores() {
        return vlRspExerciciosAnteriores;
    }

    public void setVlRspExerciciosAnteriores(double vlRspExerciciosAnteriores) {
        this.vlRspExerciciosAnteriores = vlRspExerciciosAnteriores;
    }

    public double getVlRestituiveisRecolher() {
        return vlRestituiveisRecolher;
    }

    public void setVlRestituiveisRecolher(double vlRestituiveisRecolher) {
        this.vlRestituiveisRecolher = vlRestituiveisRecolher;
    }

    public double getVlRestituiveisAtivoFinanceiro() {
        return vlRestituiveisAtivoFinanceiro;
    }

    public void setVlRestituiveisAtivoFinanceiro(double vlRestituiveisAtivoFinanceiro) {
        this.vlRestituiveisAtivoFinanceiro = vlRestituiveisAtivoFinanceiro;
    }

    public double getVlSaldoDispCaixa() {
        return vlSaldoDispCaixa;
    }

    public void setVlSaldoDispCaixa(double vlSaldoDispCaixa) {
        this.vlSaldoDispCaixa = vlSaldoDispCaixa;
    }
}