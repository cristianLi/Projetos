//Nome do Arquivo:ContratosDetalhamentoApostilamento
//30 – Contratos - DetalhamentoApostilamento

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ContratosDetalhamentoApostilamento{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSub;
    @SicomColumn(description = "NroContrato", length = 14, type = Type.INTEIRO, required = true)
    int nroContrato;
    @SicomColumn(description = "DataAssinaturaContOriginal", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaContOriginal;
    @SicomColumn(description = "TipoApostila", length = 2, type = Type.TEXTO, required = true)
    String tipoApostila;
    @SicomColumn(description = "NroSeqApostila", length = 3, type = Type.INTEIRO, required = true)
    int nroSeqApostila;
    @SicomColumn(description = "DataApostila", length = 8, type = Type.DATA, required = true)
    Date dataApostila;
    @SicomColumn(description = "TipoAlteracaoApostila", length = 1, type = Type.INTEIRO, required = true)
    int tipoAlteracaoApostila;
    @SicomColumn(description = "DscAlteracao", length = 250, type = Type.TEXTO, required = true)
    String dscAlteracao;
    @SicomColumn(description = "ValorApostila", length = 14, type = Type.DOUBLE, required = true)
    double valorApostila;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public Date getDataAssinaturaContOriginal() {
        return dataAssinaturaContOriginal;
    }

    public void setDataAssinaturaContOriginal(Date dataAssinaturaContOriginal) {
        this.dataAssinaturaContOriginal = dataAssinaturaContOriginal;
    }

    public String getTipoApostila() {
        return tipoApostila;
    }

    public void setTipoApostila(String tipoApostila) {
        this.tipoApostila = tipoApostila;
    }

    public int getNroSeqApostila() {
        return nroSeqApostila;
    }

    public void setNroSeqApostila(int nroSeqApostila) {
        this.nroSeqApostila = nroSeqApostila;
    }

    public Date getDataApostila() {
        return dataApostila;
    }

    public void setDataApostila(Date dataApostila) {
        this.dataApostila = dataApostila;
    }

    public int getTipoAlteracaoApostila() {
        return tipoAlteracaoApostila;
    }

    public void setTipoAlteracaoApostila(int tipoAlteracaoApostila) {
        this.tipoAlteracaoApostila = tipoAlteracaoApostila;
    }

    public String getDscAlteracao() {
        return dscAlteracao;
    }

    public void setDscAlteracao(String dscAlteracao) {
        this.dscAlteracao = dscAlteracao;
    }

    public double getValorApostila() {
        return valorApostila;
    }

    public void setValorApostila(double valorApostila) {
        this.valorApostila = valorApostila;
    }
}