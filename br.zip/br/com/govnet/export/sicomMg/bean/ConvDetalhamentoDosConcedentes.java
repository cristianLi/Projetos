//Nome do Arquivo:ConvDetalhamentoDosConcedentes
//11 – Conv - DetalhamentoDosConcedentes

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ConvDetalhamentoDosConcedentes{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodConvenio", length = 15, type = Type.INTEIRO, required = true)
    int codConvenio;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = false)
    int nroDocumento;
    @SicomColumn(description = "EsferaConcedente", length = 1, type = Type.INTEIRO, required = true)
    int esferaConcedente;
    @SicomColumn(description = "DscExterior", length = 120, type = Type.TEXTO, required = false)
    String dscExterior;
    @SicomColumn(description = "ValorConcedido", length = 14, type = Type.DOUBLE, required = true)
    double valorConcedido;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodConvenio() {
        return codConvenio;
    }

    public void setCodConvenio(int codConvenio) {
        this.codConvenio = codConvenio;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public int getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(int nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public int getEsferaConcedente() {
        return esferaConcedente;
    }

    public void setEsferaConcedente(int esferaConcedente) {
        this.esferaConcedente = esferaConcedente;
    }

    public String getDscExterior() {
        return dscExterior;
    }

    public void setDscExterior(String dscExterior) {
        this.dscExterior = dscExterior;
    }

    public double getValorConcedido() {
        return valorConcedido;
    }

    public void setValorConcedido(double valorConcedido) {
        this.valorConcedido = valorConcedido;
    }
}