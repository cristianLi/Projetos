//Nome do Arquivo:EXTDetalhamentoPagamentosDespesasExtraorcamentarias
//30 – EXT - DetalhamentoPagamentosDespesasExtraorcamentarias
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EXTDetalhamentoPagamentosDespesasExtraorcamentarias{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codEXT", length = 15, type = Type.INTEIRO, required = true)
    int codEXT;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "codReduzidoOP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoOP;
    @SicomColumn(description = "nroOP", length = 22, type = Type.INTEIRO, required = true)
    int nroOP;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "dtPagamento", length = 8, type = Type.DATA, required = true)
    date dtPagamento;
    @SicomColumn(description = "tipoDocumentoCredor", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumentoCredor;
    @SicomColumn(description = "nroDocumentoCredor", length = 14, type = Type.TEXTO, required = false)
    String nroDocumentoCredor;
    @SicomColumn(description = "vlOP", length = 14, type = Type.DOUBLE, required = true)
    double vlOP;
    @SicomColumn(description = "especificacaoOP", length = 500, type = Type.TEXTO, required = true)
    String especificacaoOP;
    @SicomColumn(description = "cpfRespPgto", length = 11, type = Type.TEXTO, required = true)
    String cpfRespPgto;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodEXT() {
        return codEXT;
    }

    public void setCodEXT(int codEXT) {
        this.codEXT = codEXT;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public int getCodReduzidoOP() {
        return codReduzidoOP;
    }

    public void setCodReduzidoOP(int codReduzidoOP) {
        this.codReduzidoOP = codReduzidoOP;
    }

    public int getNroOP() {
        return nroOP;
    }

    public void setNroOP(int nroOP) {
        this.nroOP = nroOP;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public date getDtPagamento() {
        return dtPagamento;
    }

    public void setDtPagamento(date dtPagamento) {
        this.dtPagamento = dtPagamento;
    }

    public int getTipoDocumentoCredor() {
        return tipoDocumentoCredor;
    }

    public void setTipoDocumentoCredor(int tipoDocumentoCredor) {
        this.tipoDocumentoCredor = tipoDocumentoCredor;
    }

    public String getNroDocumentoCredor() {
        return nroDocumentoCredor;
    }

    public void setNroDocumentoCredor(String nroDocumentoCredor) {
        this.nroDocumentoCredor = nroDocumentoCredor;
    }

    public double getVlOP() {
        return vlOP;
    }

    public void setVlOP(double vlOP) {
        this.vlOP = vlOP;
    }

    public String getEspecificacaoOP() {
        return especificacaoOP;
    }

    public void setEspecificacaoOP(String especificacaoOP) {
        this.especificacaoOP = especificacaoOP;
    }

    public String getCpfRespPgto() {
        return cpfRespPgto;
    }

    public void setCpfRespPgto(String cpfRespPgto) {
        this.cpfRespPgto = cpfRespPgto;
    }
}