//Nome do Arquivo:NTF
//10 – NTF
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class NTF{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codNotaFiscal", length = 15, type = Type.INTEIRO, required = true)
    int codNotaFiscal;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "nfNumero", length = 20, type = Type.INTEIRO, required = true)
    int nfNumero;
    @SicomColumn(description = "nfSerie", length = 8, type = Type.TEXTO, required = false)
    String nfSerie;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "nroInscEstadual", length = 30, type = Type.TEXTO, required = false)
    String nroInscEstadual;
    @SicomColumn(description = "nroInscMunicipal", length = 30, type = Type.TEXTO, required = false)
    String nroInscMunicipal;
    @SicomColumn(description = "nomeMunicipio", length = 120, type = Type.TEXTO, required = true)
    String nomeMunicipio;
    @SicomColumn(description = "cepMunicipio", length = 8, type = Type.INTEIRO, required = true)
    int cepMunicipio;
    @SicomColumn(description = "ufCredor", length = 2, type = Type.TEXTO, required = true)
    String ufCredor;
    @SicomColumn(description = "notaFiscalEletronica", length = 1, type = Type.INTEIRO, required = true)
    int notaFiscalEletronica;
    @SicomColumn(description = "chaveAcesso", length = 44, type = Type.INTEIRO, required = false)
    int chaveAcesso;
    @SicomColumn(description = "outraChaveAcesso", length = 60, type = Type.TEXTO, required = false)
    String outraChaveAcesso;
    @SicomColumn(description = "nfAIDF", length = 15, type = Type.TEXTO, required = false)
    String nfAIDF;
    @SicomColumn(description = "dtEmissaoNF", length = 8, type = Type.DATA, required = true)
    date dtEmissaoNF;
    @SicomColumn(description = "dtVencimentoNF", length = 8, type = Type.DATA, required = false)
    date dtVencimentoNF;
    @SicomColumn(description = "nfValorTotal", length = 14, type = Type.DOUBLE, required = true)
    double nfValorTotal;
    @SicomColumn(description = "nfValorDesconto", length = 14, type = Type.DOUBLE, required = true)
    double nfValorDesconto;
    @SicomColumn(description = "nfValorLiquido", length = 14, type = Type.DOUBLE, required = true)
    double nfValorLiquido;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodNotaFiscal() {
        return codNotaFiscal;
    }

    public void setCodNotaFiscal(int codNotaFiscal) {
        this.codNotaFiscal = codNotaFiscal;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getNfNumero() {
        return nfNumero;
    }

    public void setNfNumero(int nfNumero) {
        this.nfNumero = nfNumero;
    }

    public String getNfSerie() {
        return nfSerie;
    }

    public void setNfSerie(String nfSerie) {
        this.nfSerie = nfSerie;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getNroInscEstadual() {
        return nroInscEstadual;
    }

    public void setNroInscEstadual(String nroInscEstadual) {
        this.nroInscEstadual = nroInscEstadual;
    }

    public String getNroInscMunicipal() {
        return nroInscMunicipal;
    }

    public void setNroInscMunicipal(String nroInscMunicipal) {
        this.nroInscMunicipal = nroInscMunicipal;
    }

    public String getNomeMunicipio() {
        return nomeMunicipio;
    }

    public void setNomeMunicipio(String nomeMunicipio) {
        this.nomeMunicipio = nomeMunicipio;
    }

    public int getCepMunicipio() {
        return cepMunicipio;
    }

    public void setCepMunicipio(int cepMunicipio) {
        this.cepMunicipio = cepMunicipio;
    }

    public String getUfCredor() {
        return ufCredor;
    }

    public void setUfCredor(String ufCredor) {
        this.ufCredor = ufCredor;
    }

    public int getNotaFiscalEletronica() {
        return notaFiscalEletronica;
    }

    public void setNotaFiscalEletronica(int notaFiscalEletronica) {
        this.notaFiscalEletronica = notaFiscalEletronica;
    }

    public int getChaveAcesso() {
        return chaveAcesso;
    }

    public void setChaveAcesso(int chaveAcesso) {
        this.chaveAcesso = chaveAcesso;
    }

    public String getOutraChaveAcesso() {
        return outraChaveAcesso;
    }

    public void setOutraChaveAcesso(String outraChaveAcesso) {
        this.outraChaveAcesso = outraChaveAcesso;
    }

    public String getNfAIDF() {
        return nfAIDF;
    }

    public void setNfAIDF(String nfAIDF) {
        this.nfAIDF = nfAIDF;
    }

    public date getDtEmissaoNF() {
        return dtEmissaoNF;
    }

    public void setDtEmissaoNF(date dtEmissaoNF) {
        this.dtEmissaoNF = dtEmissaoNF;
    }

    public date getDtVencimentoNF() {
        return dtVencimentoNF;
    }

    public void setDtVencimentoNF(date dtVencimentoNF) {
        this.dtVencimentoNF = dtVencimentoNF;
    }

    public double getNfValorTotal() {
        return nfValorTotal;
    }

    public void setNfValorTotal(double nfValorTotal) {
        this.nfValorTotal = nfValorTotal;
    }

    public double getNfValorDesconto() {
        return nfValorDesconto;
    }

    public void setNfValorDesconto(double nfValorDesconto) {
        this.nfValorDesconto = nfValorDesconto;
    }

    public double getNfValorLiquido() {
        return nfValorLiquido;
    }

    public void setNfValorLiquido(double nfValorLiquido) {
        this.nfValorLiquido = nfValorLiquido;
    }
}
