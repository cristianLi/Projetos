//Nome do Arquivo:EXTDetalhamentoDasRetencoes
//32 – EXT - DetalhamentoDasRetencoes
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EXTDetalhamentoDasRetencoes{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoOP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoOP;
    @SicomColumn(description = "tipoRetencao", length = 4, type = Type.TEXTO, required = true)
    String tipoRetencao;
    @SicomColumn(description = "descricaoRetencao", length = 50, type = Type.TEXTO, required = false)
    String descricaoRetencao;
    @SicomColumn(description = "vlRetencao", length = 14, type = Type.DOUBLE, required = true)
    double vlRetencao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoOP() {
        return codReduzidoOP;
    }

    public void setCodReduzidoOP(int codReduzidoOP) {
        this.codReduzidoOP = codReduzidoOP;
    }

    public String getTipoRetencao() {
        return tipoRetencao;
    }

    public void setTipoRetencao(String tipoRetencao) {
        this.tipoRetencao = tipoRetencao;
    }

    public String getDescricaoRetencao() {
        return descricaoRetencao;
    }

    public void setDescricaoRetencao(String descricaoRetencao) {
        this.descricaoRetencao = descricaoRetencao;
    }

    public double getVlRetencao() {
        return vlRetencao;
    }

    public void setVlRetencao(double vlRetencao) {
        this.vlRetencao = vlRetencao;
    }
}