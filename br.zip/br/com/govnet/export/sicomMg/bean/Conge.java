//Nome do Arquivo:Conge
//10 – Conge
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Conge{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codConvenioConge", length = 15, type = Type.INTEIRO, required = true)
    int codConvenioConge;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dscInstrumento", length = 50, type = Type.TEXTO, required = true)
    String dscInstrumento;
    @SicomColumn(description = "dataAssinaturaConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaConge;
    @SicomColumn(description = "dataPublicConge", length = 8, type = Type.DATA, required = true)
    date dataPublicConge;
    @SicomColumn(description = "nroCPFRespConge", length = 11, type = Type.TEXTO, required = true)
    String nroCPFRespConge;
    @SicomColumn(description = "dscCargoRespConge", length = 50, type = Type.TEXTO, required = true)
    String dscCargoRespConge;
    @SicomColumn(description = "objetoConvenioConge", length = 500, type = Type.TEXTO, required = true)
    String objetoConvenioConge;
    @SicomColumn(description = "dataInicioVigenciaConge", length = 8, type = Type.DATA, required = true)
    date dataInicioVigenciaConge;
    @SicomColumn(description = "dataFinalVigenciaConge", length = 8, type = Type.DATA, required = true)
    date dataFinalVigenciaConge;
    @SicomColumn(description = "formaRepasse", length = 1, type = Type.INTEIRO, required = true)
    int formaRepasse;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento Incentivador;
    @SicomColumn(description = "nroDocumentoIncentivador", length = 14, type = Type.TEXTO, required = false)
    String nroDocumentoIncentivador;
    @SicomColumn(description = "quantParcelas", length = 3, type = Type.INTEIRO, required = true)
    int quantParcelas;
    @SicomColumn(description = "vlTotalConvenioConge", length = 14, type = Type.DOUBLE, required = true)
    double vlTotalConvenioConge;
    @SicomColumn(description = "vlContrapartidaConge", length = 14, type = Type.DOUBLE, required = true)
    double vlContrapartidaConge;
    @SicomColumn(description = "tipoDocumentoBeneficiario", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoBeneficiario;
    @SicomColumn(description = "nroDocumentoBeneficiario", length = 14, type = Type.TEXTO, required = true)
    String nroDocumentoBeneficiario;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodConvenioConge() {
        return codConvenioConge;
    }

    public void setCodConvenioConge(int codConvenioConge) {
        this.codConvenioConge = codConvenioConge;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public String getDscInstrumento() {
        return dscInstrumento;
    }

    public void setDscInstrumento(String dscInstrumento) {
        this.dscInstrumento = dscInstrumento;
    }

    public date getDataAssinaturaConge() {
        return dataAssinaturaConge;
    }

    public void setDataAssinaturaConge(date dataAssinaturaConge) {
        this.dataAssinaturaConge = dataAssinaturaConge;
    }

    public date getDataPublicConge() {
        return dataPublicConge;
    }

    public void setDataPublicConge(date dataPublicConge) {
        this.dataPublicConge = dataPublicConge;
    }

    public String getNroCPFRespConge() {
        return nroCPFRespConge;
    }

    public void setNroCPFRespConge(String nroCPFRespConge) {
        this.nroCPFRespConge = nroCPFRespConge;
    }

    public String getDscCargoRespConge() {
        return dscCargoRespConge;
    }

    public void setDscCargoRespConge(String dscCargoRespConge) {
        this.dscCargoRespConge = dscCargoRespConge;
    }

    public String getObjetoConvenioConge() {
        return objetoConvenioConge;
    }

    public void setObjetoConvenioConge(String objetoConvenioConge) {
        this.objetoConvenioConge = objetoConvenioConge;
    }

    public date getDataInicioVigenciaConge() {
        return dataInicioVigenciaConge;
    }

    public void setDataInicioVigenciaConge(date dataInicioVigenciaConge) {
        this.dataInicioVigenciaConge = dataInicioVigenciaConge;
    }

    public date getDataFinalVigenciaConge() {
        return dataFinalVigenciaConge;
    }

    public void setDataFinalVigenciaConge(date dataFinalVigenciaConge) {
        this.dataFinalVigenciaConge = dataFinalVigenciaConge;
    }

    public int getFormaRepasse() {
        return formaRepasse;
    }

    public void setFormaRepasse(int formaRepasse) {
        this.formaRepasse = formaRepasse;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumentoIncentivador() {
        return nroDocumentoIncentivador;
    }

    public void setNroDocumentoIncentivador(String nroDocumentoIncentivador) {
        this.nroDocumentoIncentivador = nroDocumentoIncentivador;
    }

    public int getQuantParcelas() {
        return quantParcelas;
    }

    public void setQuantParcelas(int quantParcelas) {
        this.quantParcelas = quantParcelas;
    }

    public double getVlTotalConvenioConge() {
        return vlTotalConvenioConge;
    }

    public void setVlTotalConvenioConge(double vlTotalConvenioConge) {
        this.vlTotalConvenioConge = vlTotalConvenioConge;
    }

    public double getVlContrapartidaConge() {
        return vlContrapartidaConge;
    }

    public void setVlContrapartidaConge(double vlContrapartidaConge) {
        this.vlContrapartidaConge = vlContrapartidaConge;
    }

    public int getTipoDocumentoBeneficiario() {
        return tipoDocumentoBeneficiario;
    }

    public void setTipoDocumentoBeneficiario(int tipoDocumentoBeneficiario) {
        this.tipoDocumentoBeneficiario = tipoDocumentoBeneficiario;
    }

    public String getNroDocumentoBeneficiario() {
        return nroDocumentoBeneficiario;
    }

    public void setNroDocumentoBeneficiario(String nroDocumentoBeneficiario) {
        this.nroDocumentoBeneficiario = nroDocumentoBeneficiario;
    }
}
