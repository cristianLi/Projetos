//Nome do Arquivo:RegadesaoDetalhamentoAdesaoRegistroPrecos
//10 – Regadesao - DetalhamentoAdesaoRegistroPrecos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RegadesaoDetalhamentoAdesaoRegistroPrecos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String;
    @SicomColumn(description = "NroProcAdesao", length = 12, type = Type.TEXTO, required = true)
    String nroProcAdesao;
    @SicomColumn(description = "ExercicioAdesao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioAdesao;
    @SicomColumn(description = "NroLote", length = 4, type = Type.INTEIRO, required = false)
    int nroLote;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = false)
    int codItem;
    @SicomColumn(description = "PercDesconto", length = 6, type = Type.DOUBLE, required = true)
    double percDesconto;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroProcAdesao() {
        return nroProcAdesao;
    }

    public void setNroProcAdesao(String nroProcAdesao) {
        this.nroProcAdesao = nroProcAdesao;
    }

    public int getExercicioAdesao() {
        return exercicioAdesao;
    }

    public void setExercicioAdesao(int exercicioAdesao) {
        this.exercicioAdesao = exercicioAdesao;
    }

    public int getNroLote() {
        return nroLote;
    }

    public void setNroLote(int nroLote) {
        this.nroLote = nroLote;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public double getPercDesconto() {
        return percDesconto;
    }

    public void setPercDesconto(double percDesconto) {
        this.percDesconto = percDesconto;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }
}