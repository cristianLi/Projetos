//Nome do Arquivo: ORGAO
//10 – Órgãos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Orgao {
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "Código do Órgão", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "Tipo de Órgão", length = 2, type = Type.TEXTO, required = true)
    String tipoOrgao;
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.TEXTO, required = true)
    String cnpjOrgao;
    @SicomColumn(description = "Tipo de documento do fornecedor de software", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoFornSoftware;
    @SicomColumn(description = "Número do documento do fornecedor de software", length = 14, type = Type.TEXTO, required = true)
    String nroDocumentoFornSoftware;
    @SicomColumn(description = "Versão do Software", length = 50, type = Type.TEXTO, required = true)
    String versaoSoftware;
    @SicomColumn(description = "Possui assessoria contábil", length = 1, type = Type.INTEIRO, required = true)
    String assessoriaContabil;
    @SicomColumn(description = "Tipo de Documento da Assessoria", length = 1, type = Type.INTEIRO)
    int tipoDocumentoAssessoria;
    @SicomColumn(description = "Tipo do registro", length = 14, type = Type.TEXTO)
    String nroDocumentoAssessoria;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(int codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getTipoOrgao() {
        return tipoOrgao;
    }

    public void setTipoOrgao(int tipoOrgao) {
        this.tipoOrgao = tipoOrgao;
    }

    public int getCnpjOrgao() {
        return cnpjOrgao;
    }

    public void setCnpjOrgao(int cnpjOrgao) {
        this.cnpjOrgao = cnpjOrgao;
    }

    public int getTipoDocumentoFornSoftware() {
        return tipoDocumentoFornSoftware;
    }

    public void setTipoDocumentoFornSoftware(int tipoDocumentoFornSoftware) {
        this.tipoDocumentoFornSoftware = tipoDocumentoFornSoftware;
    }

    public String getNroDocumentoFornSoftware() {
        return nroDocumentoFornSoftware;
    }

    public void setNroDocumentoFornSoftware(String nroDocumentoFornSoftware) {
        this.nroDocumentoFornSoftware = nroDocumentoFornSoftware;
    }

    public String getVersaoSoftware() {
        return versaoSoftware;
    }

    public void setVersaoSoftware(String versaoSoftware) {
        this.versaoSoftware = versaoSoftware;
    }

    public String getAssessoriaContabil() {
        return assessoriaContabil;
    }

    public void setAssessoriaContabil(String assessoriaContabil) {
        this.assessoriaContabil = assessoriaContabil;
    }

    public int getTipoDocumentoAssessoria() {
        return tipoDocumentoAssessoria;
    }

    public void setTipoDocumentoAssessoria(int tipoDocumentoAssessoria) {
        this.tipoDocumentoAssessoria = tipoDocumentoAssessoria;
    }

    public String getNroDocumentoAssessoria() {
        return nroDocumentoAssessoria;
    }

    public void setNroDocumentoAssessoria(String nroDocumentoAssessoria) {
        this.nroDocumentoAssessoria = nroDocumentoAssessoria;
    }
}

// Nome do Arquivo: ORGAO
// 10 – Órgãos - Identificação dos Responsáveis

public class OrgaoIdentificacaoResponsaveis {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "Tipo de Responsável", length = 2, type = Type.INTEIRO, required = true)
    int tipoResponsavel;
    @SicomColumn(description = "Identidade do responsável", length = 10, type = Type.String, required = true)
    String cartIdent;
    @SicomColumn(description = "Órgão emissor da carteira de identidade do responsável", length = 10, type = Type.String, required = true)
    String orgEmissorCi;
    @SicomColumn(description = "Número do CPF do responsável", length = 11, type = Type.String, required = true)
    String cpf;
    @SicomColumn(description = "Número do CRC do contador responsável", length = 11, type = Type.String, required = false)
    String crcContador;
    @SicomColumn(description = "Estado de origem do CRC do contador responsável", length = 2, type = Type.String, required = false)
    String ufCrcContador;
    @SicomColumn(description = "Cargo do Ordenador por Despesa por Delegação", length = 50, type = Type.String, required = false)
    String cargoOrdDespDeleg;
    @SicomColumn(description = "Data inicial", length = 8, type = Type.DATA, required = true)
    Date dtInicio;
    @SicomColumn(description = "Data final", length = 8, type = Type.DATA, required = true)
    Date dtFinal;
    @SicomColumn(description = "Endereço eletrônico (e-mail) ", length = 50, type = Type.TEXTO, required = true)
    String email;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public int setTipoRegistro() {
        return tipoRegistro;
    }

    public int getTipoResponsavel() {
        return tipoResponsavel;
    }

    public int setTipoResponsavel() {
        return tipoResponsavel;
    }

    public String getCartIdent() {
        return cartIdent;
    }

    public String setCartIdent() {
        return cartIdent;
    }

    public String getOrgEmissorCi() {
        return orgEmissorCi;
    }

    public String setOrgEmissorCi() {
        return orgEmissorCi;
    }

    public String getCpf() {
        return cpf;
    }

    public String setCpf() {
        return cpf;
    }

    public String getCrcContador() {
        return crcContador;
    }

    public String setCrcContador() {
        return crcContador;
    }

    public String getUfCrcContador() {
        return ufCrcContador;
    }

    public String setUfCrcContador() {
        return ufCrcContador;
    }

    public String getCargoOrdDespDeleg() {
        return cargoOrdDespDeleg;
    }

    public String setCargoOrdDespDeleg() {
        return cargoOrdDespDeleg;
    }

    public Date getDtInicio() {
        return dtInicio;
    }

    public Date setDtInicio() {
        return dtInicio;
    }

    public Date getDtFinal() {
        return dtFinal;
    }
    public Date setDtFinal(){
        return dtFinal;
    }

    public String getEmail() {
        return email;
    }
    public String setEmail(){
        return email;
    }
}
