//Nome do Arquivo: Dispensa
//10 – Dispensa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

    public class DispensaDetalhamentoCredenciadoPreencherDetalhamentoProcessosInexigibilidadeCredenciamentoChamadaPublicaDispensaChamadaPublica {

        @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
        int tipoRegistro;
        @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.INTEIRO, required = true)
        int codOrgaoResp;
        @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.INTEIRO, required = true)
        int codUnidadeSubResp;
        @SicomColumn(description = "ExercicioProcesso", length = 4, type = Type.INTEIRO, required = true)
        int exercicioProcesso;
        @SicomColumn(description = "NroProcesso", length = 12, type = Type.INTEIRO, required = true)
        int nroProcesso;
        @SicomColumn(description = "TipoProcesso", length = 1, type = Type.INTEIRO, required = true)
        int tipoProcesso;
        @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = true)
        int tipoDocumento;
        @SicomColumn(description = "NroDocumento", length = 14, type = Type.INTEIRO, required = true)
        int nroDocumento;
        @SicomColumn(description = "DataCredenciamento", length = 8, type = Type.INTEIRO, required = true)
        int dataCredenciamento;
        @SicomColumn(description = "NroLote", length = 4, type = Type.INTEIRO, required = true)
        int nroLote;
        @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
        int codItem;
        @SicomColumn(description = "NroInscricaoEstadual", length = 30, type = Type.INTEIRO, required = true)
        int nroInscricaoEstadual;
        @SicomColumn(description = "UfInscricaoEstadual", length = 2, type = Type.INTEIRO, required = true)
        int ufInscricaoEstadual;
        @SicomColumn(description = "NroCertidaoRegularidadeINSS", length = 30, type = Type.INTEIRO, required = true)
        int nroCertidaoRegularidadeINSS;
        @SicomColumn(description = "DataEmissaoCertidaoRegularidadeINSS", length = 8, type = Type.INTEIRO, required = true)
        int dataEmissaoCertidaoRegularidadeINSS;
        @SicomColumn(description = "DataValidadeCertidaoRegularidadeINSS", length = 8, type = Type.INTEIRO, required = true)
        int dataValidadeCertidaoRegularidadeINSS;
        @SicomColumn(description = "NroCertidaoRegularidadeFGTS", length = 30, type = Type.INTEIRO, required = true)
        int nroCertidaoRegularidadeFGTS;
        @SicomColumn(description = "DataEmissaoCertidaoRegularidadeFGTS", length = 8, type = Type.INTEIRO, required = true)
        int dataEmissaoCertidaoRegularidadeFGTS;
        @SicomColumn(description = "DataValidadeCertidaoRegularidadeFGTS", length = 8, type = Type.INTEIRO, required = true)
        int dataValidadeCertidaoRegularidadeFGTS;
        @SicomColumn(description = "NroCNDT", length = 30, type = Type.INTEIRO, required = true)
        int nroCNDT;
        @SicomColumn(description = "DtEmissaoCNDT", length = 8, type = Type.INTEIRO, required = true)
        int dtEmissaoCNDT;
        @SicomColumn(description = "DtValidadeCNDT", length = 8, type = Type.INTEIRO, required = true)
        int dtValidadeCNDT;

        public int getTipoRegistro() {
            return tipoRegistro;
        }

        public void setTipoRegistro(int tipoRegistro) {
            this.tipoRegistro = tipoRegistro;
        }

        public int getCodOrgaoResp() {
            return codOrgaoResp;
        }

        public void setCodOrgaoResp(int codOrgaoResp) {
            this.codOrgaoResp = codOrgaoResp;
        }

        public int getCodUnidadeSubResp() {
            return codUnidadeSubResp;
        }

        public void setCodUnidadeSubResp(int codUnidadeSubResp) {
            this.codUnidadeSubResp = codUnidadeSubResp;
        }

        public int getExercicioProcesso() {
            return exercicioProcesso;
        }

        public void setExercicioProcesso(int exercicioProcesso) {
            this.exercicioProcesso = exercicioProcesso;
        }

        public int getNroProcesso() {
            return nroProcesso;
        }

        public void setNroProcesso(int nroProcesso) {
            this.nroProcesso = nroProcesso;
        }

        public int getTipoProcesso() {
            return tipoProcesso;
        }

        public void setTipoProcesso(int tipoProcesso) {
            this.tipoProcesso = tipoProcesso;
        }

        public int getTipoDocumento() {
            return tipoDocumento;
        }

        public void setTipoDocumento(int tipoDocumento) {
            this.tipoDocumento = tipoDocumento;
        }

        public int getNroDocumento() {
            return nroDocumento;
        }

        public void setNroDocumento(int nroDocumento) {
            this.nroDocumento = nroDocumento;
        }

        public int getDataCredenciamento() {
            return dataCredenciamento;
        }

        public void setDataCredenciamento(int dataCredenciamento) {
            this.dataCredenciamento = dataCredenciamento;
        }

        public int getNroLote() {
            return nroLote;
        }

        public void setNroLote(int nroLote) {
            this.nroLote = nroLote;
        }

        public int getCodItem() {
            return codItem;
        }

        public void setCodItem(int codItem) {
            this.codItem = codItem;
        }

        public int getNroInscricaoEstadual() {
            return nroInscricaoEstadual;
        }

        public void setNroInscricaoEstadual(int nroInscricaoEstadual) {
            this.nroInscricaoEstadual = nroInscricaoEstadual;
        }

        public int getUfInscricaoEstadual() {
            return ufInscricaoEstadual;
        }

        public void setUfInscricaoEstadual(int ufInscricaoEstadual) {
            this.ufInscricaoEstadual = ufInscricaoEstadual;
        }

        public int getNroCertidaoRegularidadeINSS() {
            return nroCertidaoRegularidadeINSS;
        }

        public void setNroCertidaoRegularidadeINSS(int nroCertidaoRegularidadeINSS) {
            this.nroCertidaoRegularidadeINSS = nroCertidaoRegularidadeINSS;
        }

        public int getDataEmissaoCertidaoRegularidadeINSS() {
            return dataEmissaoCertidaoRegularidadeINSS;
        }

        public void setDataEmissaoCertidaoRegularidadeINSS(int dataEmissaoCertidaoRegularidadeINSS) {
            this.dataEmissaoCertidaoRegularidadeINSS = dataEmissaoCertidaoRegularidadeINSS;
        }

        public int getDataValidadeCertidaoRegularidadeINSS() {
            return dataValidadeCertidaoRegularidadeINSS;
        }

        public void setDataValidadeCertidaoRegularidadeINSS(int dataValidadeCertidaoRegularidadeINSS) {
            this.dataValidadeCertidaoRegularidadeINSS = dataValidadeCertidaoRegularidadeINSS;
        }

        public int getNroCertidaoRegularidadeFGTS() {
            return nroCertidaoRegularidadeFGTS;
        }

        public void setNroCertidaoRegularidadeFGTS(int nroCertidaoRegularidadeFGTS) {
            this.nroCertidaoRegularidadeFGTS = nroCertidaoRegularidadeFGTS;
        }

        public int getDataEmissaoCertidaoRegularidadeFGTS() {
            return dataEmissaoCertidaoRegularidadeFGTS;
        }

        public void setDataEmissaoCertidaoRegularidadeFGTS(int dataEmissaoCertidaoRegularidadeFGTS) {
            this.dataEmissaoCertidaoRegularidadeFGTS = dataEmissaoCertidaoRegularidadeFGTS;
        }

        public int getDataValidadeCertidaoRegularidadeFGTS() {
            return dataValidadeCertidaoRegularidadeFGTS;
        }

        public void setDataValidadeCertidaoRegularidadeFGTS(int dataValidadeCertidaoRegularidadeFGTS) {
            this.dataValidadeCertidaoRegularidadeFGTS = dataValidadeCertidaoRegularidadeFGTS;
        }

        public int getNroCNDT() {
            return nroCNDT;
        }

        public void setNroCNDT(int nroCNDT) {
            this.nroCNDT = nroCNDT;
        }

        public int getDtEmissaoCNDT() {
            return dtEmissaoCNDT;
        }

        public void setDtEmissaoCNDT(int dtEmissaoCNDT) {
            this.dtEmissaoCNDT = dtEmissaoCNDT;
        }

        public int getDtValidadeCNDT() {
            return dtValidadeCNDT;
        }

        public void setDtValidadeCNDT(int dtValidadeCNDT) {
            this.dtValidadeCNDT = dtValidadeCNDT;
        }
    }