//Nome do Arquivo:DDCSaldoContratoDivida
//30 – DDC - SaldoContratoDivida
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DDCSaldoContratoDivida{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "nroContratoDivida", length = 30, type = Type.TEXTO, required = true)
    String nroContratoDivida;
    @SicomColumn(description = "dtAssinatura", length = 8, type = Type.DATA, required = true)
    date dtAssinatura;
    @SicomColumn(description = "tipoLancamento", length = 2, type = Type.TEXTO, required = true)
    String tipoLancamento;
    @SicomColumn(description = "subTipo", length = 1, type = Type.INTEIRO, required = false)
    int subTipo;
    @SicomColumn(description = "tipoDocumentoCredor", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumentoCredor;
    @SicomColumn(description = "nroDocumentoCredor", length = 14, type = Type.TEXTO, required = false)
    String nroDocumentoCredor;
    @SicomColumn(description = "justificativaCancelamento", length = 500, type = Type.TEXTO, required = false)
    String justificativaCancelamento;
    @SicomColumn(description = "vlSaldoAnterior", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAnterior;
    @SicomColumn(description = "vlContratacao", length = 14, type = Type.DOUBLE, required = true)
    double vlContratacao;
    @SicomColumn(description = "vlAmortizacao", length = 14, type = Type.DOUBLE, required = true)
    double vlAmortizacao;
    @SicomColumn(description = "vlCancelamento", length = 14, type = Type.DOUBLE, required = true)
    double vlCancelamento;
    @SicomColumn(description = "vlEncampacao", length = 14, type = Type.DOUBLE, required = true)
    double vlEncampacao;
    @SicomColumn(description = "vlAtualizacao", length = 14, type = Type.DOUBLE, required = true)
    double vlAtualizacao;
    @SicomColumn(description = "vlSaldoAtual", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtual;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroContratoDivida() {
        return nroContratoDivida;
    }

    public void setNroContratoDivida(String nroContratoDivida) {
        this.nroContratoDivida = nroContratoDivida;
    }

    public date getDtAssinatura() {
        return dtAssinatura;
    }

    public void setDtAssinatura(date dtAssinatura) {
        this.dtAssinatura = dtAssinatura;
    }

    public String getTipoLancamento() {
        return tipoLancamento;
    }

    public void setTipoLancamento(String tipoLancamento) {
        this.tipoLancamento = tipoLancamento;
    }

    public int getSubTipo() {
        return subTipo;
    }

    public void setSubTipo(int subTipo) {
        this.subTipo = subTipo;
    }

    public int getTipoDocumentoCredor() {
        return tipoDocumentoCredor;
    }

    public void setTipoDocumentoCredor(int tipoDocumentoCredor) {
        this.tipoDocumentoCredor = tipoDocumentoCredor;
    }

    public String getNroDocumentoCredor() {
        return nroDocumentoCredor;
    }

    public void setNroDocumentoCredor(String nroDocumentoCredor) {
        this.nroDocumentoCredor = nroDocumentoCredor;
    }

    public String getJustificativaCancelamento() {
        return justificativaCancelamento;
    }

    public void setJustificativaCancelamento(String justificativaCancelamento) {
        this.justificativaCancelamento = justificativaCancelamento;
    }

    public double getVlSaldoAnterior() {
        return vlSaldoAnterior;
    }

    public void setVlSaldoAnterior(double vlSaldoAnterior) {
        this.vlSaldoAnterior = vlSaldoAnterior;
    }

    public double getVlContratacao() {
        return vlContratacao;
    }

    public void setVlContratacao(double vlContratacao) {
        this.vlContratacao = vlContratacao;
    }

    public double getVlAmortizacao() {
        return vlAmortizacao;
    }

    public void setVlAmortizacao(double vlAmortizacao) {
        this.vlAmortizacao = vlAmortizacao;
    }

    public double getVlCancelamento() {
        return vlCancelamento;
    }

    public void setVlCancelamento(double vlCancelamento) {
        this.vlCancelamento = vlCancelamento;
    }

    public double getVlEncampacao() {
        return vlEncampacao;
    }

    public void setVlEncampacao(double vlEncampacao) {
        this.vlEncampacao = vlEncampacao;
    }

    public double getVlAtualizacao() {
        return vlAtualizacao;
    }

    public void setVlAtualizacao(double vlAtualizacao) {
        this.vlAtualizacao = vlAtualizacao;
    }

    public double getVlSaldoAtual() {
        return vlSaldoAtual;
    }

    public void setVlSaldoAtual(double vlSaldoAtual) {
        this.vlSaldoAtual = vlSaldoAtual;
    }
}