//Nome do Arquivo:CongeRepassesRealizadosPorMeioConveniosInstrumentosCongeneres
//30 – Conge - RepassesRealizadosPorMeioConveniosInstrumentosCongeneres
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CongeRepassesRealizadosPorMeioConveniosInstrumentosCongeneres{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dataAssinaturaConvOriginalConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaConvOriginalConge;
    @SicomColumn(description = "numeroParcela", length = 3, type = Type.INTEIRO, required = true)
    int numeroParcela;
    @SicomColumn(description = "dataRepasseConge", length = 8, type = Type.DATA, required = true)
    date dataRepasseConge;
    @SicomColumn(description = "vlRepassadoConge", length = 14, type = Type.DOUBLE, required = true)
    double vlRepassadoConge;
    @SicomColumn(description = "banco", length = 3, type = Type.INTEIRO, required = true)
    int banco;
    @SicomColumn(description = "agencia", length = 6, type = Type.TEXTO, required = true)
    String agencia;
    @SicomColumn(description = "digitoVerificadorAgencia", length = 2, type = Type.TEXTO, required = false)
    String digitoVerificadorAgencia;
    @SicomColumn(description = "contaBancaria", length = 12, type = Type.INTEIRO, required = true)
    int contaBancaria;
    @SicomColumn(description = "digitoVerificadorContaBancaria", length = 2, type = Type.TEXTO, required = true)
    String digitoVerificadorContaBancaria;
    @SicomColumn(description = "tipoDocumentoTitularConta", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumentoTitularConta;
    @SicomColumn(description = "nroDocumentoTitular", length = 14, type = Type.TEXTO, required = true)
    String nroDocumentoTitularConta;
    @SicomColumn(description = "prazoPrestaContas", length = 8, type = Type.DATA, required = true)
    date prazoPrestaContas;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConvOriginalConge() {
        return dataAssinaturaConvOriginalConge;
    }

    public void setDataAssinaturaConvOriginalConge(date dataAssinaturaConvOriginalConge) {
        this.dataAssinaturaConvOriginalConge = dataAssinaturaConvOriginalConge;
    }

    public int getNumeroParcela() {
        return numeroParcela;
    }

    public void setNumeroParcela(int numeroParcela) {
        this.numeroParcela = numeroParcela;
    }

    public date getDataRepasseConge() {
        return dataRepasseConge;
    }

    public void setDataRepasseConge(date dataRepasseConge) {
        this.dataRepasseConge = dataRepasseConge;
    }

    public double getVlRepassadoConge() {
        return vlRepassadoConge;
    }

    public void setVlRepassadoConge(double vlRepassadoConge) {
        this.vlRepassadoConge = vlRepassadoConge;
    }

    public int getBanco() {
        return banco;
    }

    public void setBanco(int banco) {
        this.banco = banco;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getDigitoVerificadorAgencia() {
        return digitoVerificadorAgencia;
    }

    public void setDigitoVerificadorAgencia(String digitoVerificadorAgencia) {
        this.digitoVerificadorAgencia = digitoVerificadorAgencia;
    }

    public int getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(int contaBancaria) {
        this.contaBancaria = contaBancaria;
    }

    public String getDigitoVerificadorContaBancaria() {
        return digitoVerificadorContaBancaria;
    }

    public void setDigitoVerificadorContaBancaria(String digitoVerificadorContaBancaria) {
        this.digitoVerificadorContaBancaria = digitoVerificadorContaBancaria;
    }

    public int getTipoDocumentoTitularConta() {
        return tipoDocumentoTitularConta;
    }

    public void setTipoDocumentoTitularConta(int tipoDocumentoTitularConta) {
        this.tipoDocumentoTitularConta = tipoDocumentoTitularConta;
    }

    public String getNroDocumentoTitularConta() {
        return nroDocumentoTitularConta;
    }

    public void setNroDocumentoTitularConta(String nroDocumentoTitularConta) {
        this.nroDocumentoTitularConta = nroDocumentoTitularConta;
    }

    public date getPrazoPrestaContas() {
        return prazoPrestaContas;
    }

    public void setPrazoPrestaContas(date prazoPrestaContas) {
        this.prazoPrestaContas = prazoPrestaContas;
    }
}


