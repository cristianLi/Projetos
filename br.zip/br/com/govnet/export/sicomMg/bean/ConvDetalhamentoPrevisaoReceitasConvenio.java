//Nome do Arquivo:ConvDetalhamentoPrevisaoReceitasConvenio
//31 – Conv - DetalhamentoPrevisaoReceitasConvenio

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ConvDetalhamentoPrevisaoReceitasConvenio{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReceita", length = 15, type = Type.INTEIRO, required = true)
    int codReceita;
    @SicomColumn(description = "PrevOrcamentoAssin", length = 1, type = Type.INTEIRO, required = true)
    int prevOrcamentoAssin;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;
    @SicomColumn(description = "DataAssinatura", length = 8, type = Type.DATA, required = false)
    Date dataAssinatura;
    @SicomColumn(description = "VlPrevisaoConvenio", length = 14, type = Type.DOUBLE, required = true)
    double vlPrevisaoConvenio;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReceita() {
        return codReceita;
    }

    public void setCodReceita(int codReceita) {
        this.codReceita = codReceita;
    }

    public int getPrevOrcamentoAssin() {
        return prevOrcamentoAssin;
    }

    public void setPrevOrcamentoAssin(int prevOrcamentoAssin) {
        this.prevOrcamentoAssin = prevOrcamentoAssin;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public double getVlPrevisaoConvenio() {
        return vlPrevisaoConvenio;
    }

    public void setVlPrevisaoConvenio(double vlPrevisaoConvenio) {
        this.vlPrevisaoConvenio = vlPrevisaoConvenio;
    }
}