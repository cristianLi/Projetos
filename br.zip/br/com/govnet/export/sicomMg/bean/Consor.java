//Nome do Arquivo: CONSOR
//10 – Consor

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Consor {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "Código do órgão", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "Número do CNPJ do Consórcio.", length = 14, type = Type.TEXTO, required = true)
    String CNPJConsorcio;
    @SicomColumn(description = "Área de atuação do Consórcio", length = 2, type = Type.TEXTO, required = true)
    String areaAtuacao;
    @SicomColumn(description = "Descrição da área de atuação do Consórcio", length = 150, type = Type.TEXTO, required = false)
    String descAreaAtuacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCNPJConsorcio() {
        return CNPJConsorcio;
    }

    public void setCNPJConsorcio(String CNPJConsorcio) {
        this.CNPJConsorcio = CNPJConsorcio;
    }

    public String getAreaAtuacao() {
        return areaAtuacao;
    }

    public void setAreaAtuacao(String areaAtuacao) {
        this.areaAtuacao = areaAtuacao;
    }

    public String getDescAreaAtuacao() {
        return descAreaAtuacao;
    }

    public void setDescAreaAtuacao(String descAreaAtuacao) {
        this.descAreaAtuacao = descAreaAtuacao;
    }
}



