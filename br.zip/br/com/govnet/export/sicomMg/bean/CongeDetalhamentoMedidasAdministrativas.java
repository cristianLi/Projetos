//Nome do Arquivo:CongeDetalhamentoMedidasAdministrativas
//50 – Conge - DetalhamentoMedidasAdministrativas
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CongeDetalhamentoMedidasAdministrativas{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dataAssinaturaConvOriginalConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaConvOriginalConge;
    @SicomColumn(description = "dscMedidaAdministrativa", length = 500, type = Type.TEXTO, required = true)
    String dscMedidaAdministrativa;
    @SicomColumn(description = "dataInicioMedida", length = 8, type = Type.DATA, required = true)
    date dataInicioMedida;
    @SicomColumn(description = "dataFinalMedida", length = 8, type = Type.DATA, required = true)
    date dataFinalMedida;
    @SicomColumn(description = "adocaoMedidasAdmin", length = 1, type = Type.INTEIRO, required = true)
    int adocaoMedidasAdmin;
    @SicomColumn(description = "nroCPFRespMedidaConge", length = 11, type = Type.TEXTO, required = true)
    String nroCPFRespMedidaConge;
    @SicomColumn(description = "dscCargoRespMedidaConge", length = 50, type = Type.TEXTO, required = true)
    String dscCargoRespMedidaConge;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConvOriginalConge() {
        return dataAssinaturaConvOriginalConge;
    }

    public void setDataAssinaturaConvOriginalConge(date dataAssinaturaConvOriginalConge) {
        this.dataAssinaturaConvOriginalConge = dataAssinaturaConvOriginalConge;
    }

    public String getDscMedidaAdministrativa() {
        return dscMedidaAdministrativa;
    }

    public void setDscMedidaAdministrativa(String dscMedidaAdministrativa) {
        this.dscMedidaAdministrativa = dscMedidaAdministrativa;
    }

    public date getDataInicioMedida() {
        return dataInicioMedida;
    }

    public void setDataInicioMedida(date dataInicioMedida) {
        this.dataInicioMedida = dataInicioMedida;
    }

    public date getDataFinalMedida() {
        return dataFinalMedida;
    }

    public void setDataFinalMedida(date dataFinalMedida) {
        this.dataFinalMedida = dataFinalMedida;
    }

    public int getAdocaoMedidasAdmin() {
        return adocaoMedidasAdmin;
    }

    public void setAdocaoMedidasAdmin(int adocaoMedidasAdmin) {
        this.adocaoMedidasAdmin = adocaoMedidasAdmin;
    }

    public String getNroCPFRespMedidaConge() {
        return nroCPFRespMedidaConge;
    }

    public void setNroCPFRespMedidaConge(String nroCPFRespMedidaConge) {
        this.nroCPFRespMedidaConge = nroCPFRespMedidaConge;
    }

    public String getDscCargoRespMedidaConge() {
        return dscCargoRespMedidaConge;
    }

    public void setDscCargoRespMedidaConge(String dscCargoRespMedidaConge) {
        this.dscCargoRespMedidaConge = dscCargoRespMedidaConge;
    }
}


