//Nome do Arquivo: ArcDetalhamentoDosEstornosReceita
//10 – Arc - DetalhamentoDosEstornosReceita

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ArcDetalhamentoDosEstornosReceita{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodEstorno", length = 15, type = Type.INTEIRO, required = true)
    int codEstorno;
    @SicomColumn(description = "EDeducaoDeReceita", length = 1, type = Type.INTEIRO, required = true)
    int eDeducaoDeReceita;
    @SicomColumn(description = "IdentificadorDeducao", length = 2, type = Type.INTEIRO, required = false)
    int identificadorDeducao;
    @SicomColumn(description = "NaturezaReceitaEstornada", length = 8, type = Type.INTEIRO, required = true)
    int naturezaReceitaEstornada;
    @SicomColumn(description = "VlEstornado", length = 14, type = Type.DOUBLE, required = true)
    double vlEstornado;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodEstorno() {
        return codEstorno;
    }

    public void setCodEstorno(int codEstorno) {
        this.codEstorno = codEstorno;
    }

    public int geteDeducaoDeReceita() {
        return eDeducaoDeReceita;
    }

    public void seteDeducaoDeReceita(int eDeducaoDeReceita) {
        this.eDeducaoDeReceita = eDeducaoDeReceita;
    }

    public int getIdentificadorDeducao() {
        return identificadorDeducao;
    }

    public void setIdentificadorDeducao(int identificadorDeducao) {
        this.identificadorDeducao = identificadorDeducao;
    }

    public int getNaturezaReceitaEstornada() {
        return naturezaReceitaEstornada;
    }

    public void setNaturezaReceitaEstornada(int naturezaReceitaEstornada) {
        this.naturezaReceitaEstornada = naturezaReceitaEstornada;
    }

    public double getVlEstornado() {
        return vlEstornado;
    }

    public void setVlEstornado(double vlEstornado) {
        this.vlEstornado = vlEstornado;
    }
}