//Nome do Arquivo:Conv
//10 – Conv

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Conv{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodConvenio", length = 15, type = Type.INTEIRO, required = true)
    int codConvenio;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = true)
    String nroConvenio;
    @SicomColumn(description = "DataAssinatura", length = 8, type = Type.DATA, required = true)
    Date dataAssinatura;
    @SicomColumn(description = "ObjetoConvenio", length = 500, type = Type.TEXTO, required = true)
    String objetoConvenio;
    @SicomColumn(description = "DataInicioVigencia", length = 8, type = Type.DATA, required = true)
    Date dataInicioVigencia;
    @SicomColumn(description = "DataFinalVigencia", length = 8, type = Type.DATA, required = true)
    Date dataFinalVigencia;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "VlConvenio", length = 14, type = Type.DOUBLE, required = true)
    double vlConvenio;
    @SicomColumn(description = "VlContrapartida", length = 14, type = Type.DOUBLE, required = true)
    double vlContrapartida;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodConvenio() {
        return codConvenio;
    }

    public void setCodConvenio(int codConvenio) {
        this.codConvenio = codConvenio;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public String getObjetoConvenio() {
        return objetoConvenio;
    }

    public void setObjetoConvenio(String objetoConvenio) {
        this.objetoConvenio = objetoConvenio;
    }

    public Date getDataInicioVigencia() {
        return dataInicioVigencia;
    }

    public void setDataInicioVigencia(Date dataInicioVigencia) {
        this.dataInicioVigencia = dataInicioVigencia;
    }

    public Date getDataFinalVigencia() {
        return dataFinalVigencia;
    }

    public void setDataFinalVigencia(Date dataFinalVigencia) {
        this.dataFinalVigencia = dataFinalVigencia;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlConvenio() {
        return vlConvenio;
    }

    public void setVlConvenio(double vlConvenio) {
        this.vlConvenio = vlConvenio;
    }

    public double getVlContrapartida() {
        return vlContrapartida;
    }

    public void setVlContrapartida(double vlContrapartida) {
        this.vlContrapartida = vlContrapartida;
    }
}