//Nome do Arquivo: ArcDetalhamentoDasReceitasEstornadasMesPorFonteRecursos
//21 – Arc - DetalhamentoDasReceitasEstornadasMesPorFonteRecursos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ArcDetalhamentoDasReceitasEstornadasMesPorFonteRecursos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodEstorno", length = 15, type = Type.INTEIRO, required = true)
    int codEstorno;
    @SicomColumn(description = "CodFonteEstornada", length = 3, type = Type.INTEIRO, required = true)
    int codFonteEstornada;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = false)
    String nroDocumento;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;
    @SicomColumn(description = "DataAssinatura", length = 8, type = Type.DATA, required = false)
    Date dataAssinatura;
    @SicomColumn(description = "VlEstornadoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlEstornadoFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodEstorno() {
        return codEstorno;
    }

    public void setCodEstorno(int codEstorno) {
        this.codEstorno = codEstorno;
    }

    public int getCodFonteEstornada() {
        return codFonteEstornada;
    }

    public void setCodFonteEstornada(int codFonteEstornada) {
        this.codFonteEstornada = codFonteEstornada;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public double getVlEstornadoFonte() {
        return vlEstornadoFonte;
    }

    public void setVlEstornadoFonte(double vlEstornadoFonte) {
        this.vlEstornadoFonte = vlEstornadoFonte;
    }
}