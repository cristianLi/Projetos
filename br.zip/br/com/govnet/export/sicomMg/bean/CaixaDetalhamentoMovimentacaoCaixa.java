//Nome do Arquivo:CaixaDetalhamentoMovimentacaoCaixa
//12 – Caixa - DetalhamentoMovimentacaoCaixa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CaixaDetalhamentoMovimentacaoCaixa{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "codFonteCaixa", length = 3, type = Type.INTEIRO, required = true)
    int codFonteCaixa;
    @SicomColumn(description = "tipoMovimentacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoMovimentacao;
    @SicomColumn(description = "tipoEntrSaida", length = 2, type = Type.TEXTO, required = true)
    String tipoEntrSaida;
    @SicomColumn(description = "descrMovimentacao", length = 50, type = Type.TEXTO, required = false)
    String descrMovimentacao;
    @SicomColumn(description = "ValorEntrSaida", length = 14, type = Type.DOUBLE, required = true)
    double ValorEntrSaida;
    @SicomColumn(description = "codCTBTransf", length = 20, type = Type.INTEIRO, required = false)
    int codCTBTransf;
    @SicomColumn(description = "codFonteCTBTransf", length = 3, type = Type.INTEIRO, required = false)
    int codFonteCTBTransf;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public int getCodFonteCaixa() {
        return codFonteCaixa;
    }

    public void setCodFonteCaixa(int codFonteCaixa) {
        this.codFonteCaixa = codFonteCaixa;
    }

    public int getTipoMovimentacao() {
        return tipoMovimentacao;
    }

    public void setTipoMovimentacao(int tipoMovimentacao) {
        this.tipoMovimentacao = tipoMovimentacao;
    }

    public String getTipoEntrSaida() {
        return tipoEntrSaida;
    }

    public void setTipoEntrSaida(String tipoEntrSaida) {
        this.tipoEntrSaida = tipoEntrSaida;
    }

    public String getDescrMovimentacao() {
        return descrMovimentacao;
    }

    public void setDescrMovimentacao(String descrMovimentacao) {
        this.descrMovimentacao = descrMovimentacao;
    }

    public double getValorEntrSaida() {
        return ValorEntrSaida;
    }

    public void setValorEntrSaida(double valorEntrSaida) {
        ValorEntrSaida = valorEntrSaida;
    }

    public int getCodCTBTransf() {
        return codCTBTransf;
    }

    public void setCodCTBTransf(int codCTBTransf) {
        this.codCTBTransf = codCTBTransf;
    }

    public int getCodFonteCTBTransf() {
        return codFonteCTBTransf;
    }

    public void setCodFonteCTBTransf(int codFonteCTBTransf) {
        this.codFonteCTBTransf = codFonteCTBTransf;
    }
}