//Nome do Arquivo:
//10 –

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class LQD{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "tpLiquidacao", length = 1, type = Type.INTEIRO, required = true)
    int tpLiquidacao;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "dtLiquidacao", length = 8, type = Type.DATA, required = true)
    date dtLiquidacao;
    @SicomColumn(description = "nroLiquidacao", length = 22, type = Type.INTEIRO, required = true)
    int nroLiquidacao;
    @SicomColumn(description = "vlLiquidado", length = 14, type = Type.DOUBLE, required = true)
    double vlLiquidado;
    @SicomColumn(description = "cpfLiquidante", length = 11, type = Type.TEXTO, required = true)
    String cpfLiquidante;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getTpLiquidacao() {
        return tpLiquidacao;
    }

    public void setTpLiquidacao(int tpLiquidacao) {
        this.tpLiquidacao = tpLiquidacao;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public int getNroLiquidacao() {
        return nroLiquidacao;
    }

    public void setNroLiquidacao(int nroLiquidacao) {
        this.nroLiquidacao = nroLiquidacao;
    }

    public double getVlLiquidado() {
        return vlLiquidado;
    }

    public void setVlLiquidado(double vlLiquidado) {
        this.vlLiquidado = vlLiquidado;
    }

    public String getCpfLiquidante() {
        return cpfLiquidante;
    }

    public void setCpfLiquidante(String cpfLiquidante) {
        this.cpfLiquidante = cpfLiquidante;
    }
}