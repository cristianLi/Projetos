//Nome do Arquivo:ContratosDetalhamentoDosContratadosEmpresasConsorciadas
//13 – Contratos - DetalhamentoDosContratadosEmpresasConsorciadas

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ContratosDetalhamentoDosContratadosEmpresasConsorciadas{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodContrato", length = 15, type = Type.INTEIRO, required = true)
    int codContrato;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "CpfrepresentanteLegal", length = 11, type = Type.TEXTO, required = true)
    String cpfrepresentanteLegal;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodContrato() {
        return codContrato;
    }

    public void setCodContrato(int codContrato) {
        this.codContrato = codContrato;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getCpfrepresentanteLegal() {
        return cpfrepresentanteLegal;
    }

    public void setCpfrepresentanteLegal(String cpfrepresentanteLegal) {
        this.cpfrepresentanteLegal = cpfrepresentanteLegal;
    }
}