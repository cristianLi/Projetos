//Nome do Arquivo:ANL
//10 – ANL

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ANL{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "dtAnulacao", length = 8, type = Type.DATA, required = true)
    date dtAnulacao;
    @SicomColumn(description = "nroAnulacao", length = 22, type = Type.INTEIRO, required = true)
    int nroAnulacao;
    @SicomColumn(description = "tipoAnulacao", length = 1, type = Type.INTEIRO, required = true)
    int tipoAnulacao;
    @SicomColumn(description = "especAnulacaoEmpenho", length = 500, type = Type.TEXTO, required = true)
    String especAnulacaoEmpenho;
    @SicomColumn(description = "vlAnulacao", length = 14, type = Type.DOUBLE, required = true)
    double vlAnulacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public date getDtAnulacao() {
        return dtAnulacao;
    }

    public void setDtAnulacao(date dtAnulacao) {
        this.dtAnulacao = dtAnulacao;
    }

    public int getNroAnulacao() {
        return nroAnulacao;
    }

    public void setNroAnulacao(int nroAnulacao) {
        this.nroAnulacao = nroAnulacao;
    }

    public int getTipoAnulacao() {
        return tipoAnulacao;
    }

    public void setTipoAnulacao(int tipoAnulacao) {
        this.tipoAnulacao = tipoAnulacao;
    }

    public String getEspecAnulacaoEmpenho() {
        return especAnulacaoEmpenho;
    }

    public void setEspecAnulacaoEmpenho(String especAnulacaoEmpenho) {
        this.especAnulacaoEmpenho = especAnulacaoEmpenho;
    }

    public double getVlAnulacao() {
        return vlAnulacao;
    }

    public void setVlAnulacao(double vlAnulacao) {
        this.vlAnulacao = vlAnulacao;
    }
}