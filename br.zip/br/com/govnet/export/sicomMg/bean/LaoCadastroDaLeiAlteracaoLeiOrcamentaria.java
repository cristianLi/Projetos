//Nome do Arquivo: LaoCadastroDaLeiAlteracaoLeiOrcamentaria
//20 – Lao - Cadastro da Lei de alteração da Lei Orçamentária (OPCIONAL) Deve ser informado quando houver lei que altera o percentual autorizado na Lei Orçamentária Anual)

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class LaoCadastroDaLeiAlteracaoLeiOrcamentaria{


    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NroLeiAlterOrcam", length = 6, type = Type.TEXTO, required = true)
    String nroLeiAlterOrcam;
    @SicomColumn(description = "DataLeiAlterOrcam", length = 8, type = Type.DATA, required = true)
    Date dataLeiAlterOrcam;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroLeiAlterOrcam() {
        return nroLeiAlterOrcam;
    }

    public void setNroLeiAlterOrcam(String nroLeiAlterOrcam) {
        this.nroLeiAlterOrcam = nroLeiAlterOrcam;
    }

    public Date getDataLeiAlterOrcam() {
        return dataLeiAlterOrcam;
    }

    public void setDataLeiAlterOrcam(Date dataLeiAlterOrcam) {
        this.dataLeiAlterOrcam = dataLeiAlterOrcam;
    }
}