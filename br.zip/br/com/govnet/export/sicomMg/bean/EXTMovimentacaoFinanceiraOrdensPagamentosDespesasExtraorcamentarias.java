//Nome do Arquivo:EXTMovimentacaoFinanceiraOrdensPagamentosDespesasExtraorcamentarias
//31 – EXT - MovimentacaoFinanceiraOrdensPagamentosDespesasExtraorcamentarias
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EXTMovimentacaoFinanceiraOrdensPagamentosDespesasExtraorcamentarias{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoOP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoOP;
    @SicomColumn(description = "tipoDocumentoOP", length = 2, type = Type.TEXTO, required = true)
    String tipoDocumentoOP;
    @SicomColumn(description = "nroDocumento", length = 15, type = Type.TEXTO, required = false)
    String nroDocumento;
    @SicomColumn(description = "codCTB", length = 20, type = Type.INTEIRO, required = false)
    int codCTB;
    @SicomColumn(description = "codFonteCTB", length = 3, type = Type.INTEIRO, required = false)
    int codFonteCTB;
    @SicomColumn(description = "descTipoDocumentoOP", length = 50, type = Type.TEXTO, required = false)
    String descTipoDocumentoOP;
    @SicomColumn(description = "dtEmissao", length = 8, type = Type.DATA, required = true)
    date dtEmissao;
    @SicomColumn(description = "vlDocumento", length = 14, type = Type.DOUBLE, required = true)
    double vlDocumento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoOP() {
        return codReduzidoOP;
    }

    public void setCodReduzidoOP(int codReduzidoOP) {
        this.codReduzidoOP = codReduzidoOP;
    }

    public String getTipoDocumentoOP() {
        return tipoDocumentoOP;
    }

    public void setTipoDocumentoOP(String tipoDocumentoOP) {
        this.tipoDocumentoOP = tipoDocumentoOP;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public int getCodFonteCTB() {
        return codFonteCTB;
    }

    public void setCodFonteCTB(int codFonteCTB) {
        this.codFonteCTB = codFonteCTB;
    }

    public String getDescTipoDocumentoOP() {
        return descTipoDocumentoOP;
    }

    public void setDescTipoDocumentoOP(String descTipoDocumentoOP) {
        this.descTipoDocumentoOP = descTipoDocumentoOP;
    }

    public date getDtEmissao() {
        return dtEmissao;
    }

    public void setDtEmissao(date dtEmissao) {
        this.dtEmissao = dtEmissao;
    }

    public double getVlDocumento() {
        return vlDocumento;
    }

    public void setVlDocumento(double vlDocumento) {
        this.vlDocumento = vlDocumento;
    }
}