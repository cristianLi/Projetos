//Nome do Arquivo:CVCDetalhamentoTransporteEscolar
//10 – CVC - DetalhamentoTransporteEscolar
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CVCDetalhamentoTransporteEscolar{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codVeiculo", length = 10, type = Type.TEXTO, required = true)
    String codVeiculo;
    @SicomColumn(description = "nomeEstabelecimento", length = 250, type = Type.TEXTO, required = true)
    String nomeEstabelecimento;
    @SicomColumn(description = "localidade", length = 250, type = Type.TEXTO, required = true)
    String localidade;
    @SicomColumn(description = "qtdeDiasRodados", length = 2, type = Type.INTEIRO, required = true)
    int qtdeDiasRodados;
    @SicomColumn(description = "distanciaEstabelecimento", length = 11, type = Type.DOUBLE, required = true)
    double distanciaEstabelecimento;
    @SicomColumn(description = "numeroPassageiros", length = 5, type = Type.INTEIRO, required = true)
    int numeroPassageiros;
    @SicomColumn(description = "turnos", length = 2, type = Type.TEXTO, required = true)
    String turnos;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodVeiculo() {
        return codVeiculo;
    }

    public void setCodVeiculo(String codVeiculo) {
        this.codVeiculo = codVeiculo;
    }

    public String getNomeEstabelecimento() {
        return nomeEstabelecimento;
    }

    public void setNomeEstabelecimento(String nomeEstabelecimento) {
        this.nomeEstabelecimento = nomeEstabelecimento;
    }

    public String getLocalidade() {
        return localidade;
    }

    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }

    public int getQtdeDiasRodados() {
        return qtdeDiasRodados;
    }

    public void setQtdeDiasRodados(int qtdeDiasRodados) {
        this.qtdeDiasRodados = qtdeDiasRodados;
    }

    public double getDistanciaEstabelecimento() {
        return distanciaEstabelecimento;
    }

    public void setDistanciaEstabelecimento(double distanciaEstabelecimento) {
        this.distanciaEstabelecimento = distanciaEstabelecimento;
    }

    public int getNumeroPassageiros() {
        return numeroPassageiros;
    }

    public void setNumeroPassageiros(int numeroPassageiros) {
        this.numeroPassageiros = numeroPassageiros;
    }

    public String getTurnos() {
        return turnos;
    }

    public void setTurnos(String turnos) {
        this.turnos = turnos;
    }
}


