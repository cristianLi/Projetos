//Nome do Arquivo:ALQ
//10 – ALQ

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ALQ{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATE, required = true)
    date dtEmpenho;
    @SicomColumn(description = "dtLiquidacao", length = 8, type = Type.DATA, required = true)
    date dtLiquidacao;
    @SicomColumn(description = "nroLiquidacao", length = 22, type = Type.INTEIRO, required = true)
    int nroLiquidacao;
    @SicomColumn(description = "dtAnulacaoLiq", length = 8, type = Type.DATA, required = true)
    date dtAnulacaoLiq;
    @SicomColumn(description = "nroLiquidacaoANL", length = 22, type = Type.INTEIRO, required = true)
    int nroLiquidacaoANL;
    @SicomColumn(description = "tpLiquidacao", length = 1, type = Type.INTEIRO, required = true)
    int tpLiquidacao;
    @SicomColumn(description = "justificativaAnulacao", length = 500, type = Type.TEXTO, required = true)
    String justificativaAnulacao;
    @SicomColumn(description = "vlAnulado", length = 14, type = Type.DOUBLE, required = true)
    double vlAnulado;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public int getNroLiquidacao() {
        return nroLiquidacao;
    }

    public void setNroLiquidacao(int nroLiquidacao) {
        this.nroLiquidacao = nroLiquidacao;
    }

    public date getDtAnulacaoLiq() {
        return dtAnulacaoLiq;
    }

    public void setDtAnulacaoLiq(date dtAnulacaoLiq) {
        this.dtAnulacaoLiq = dtAnulacaoLiq;
    }

    public int getNroLiquidacaoANL() {
        return nroLiquidacaoANL;
    }

    public void setNroLiquidacaoANL(int nroLiquidacaoANL) {
        this.nroLiquidacaoANL = nroLiquidacaoANL;
    }

    public int getTpLiquidacao() {
        return tpLiquidacao;
    }

    public void setTpLiquidacao(int tpLiquidacao) {
        this.tpLiquidacao = tpLiquidacao;
    }

    public String getJustificativaAnulacao() {
        return justificativaAnulacao;
    }

    public void setJustificativaAnulacao(String justificativaAnulacao) {
        this.justificativaAnulacao = justificativaAnulacao;
    }

    public double getVlAnulado() {
        return vlAnulado;
    }

    public void setVlAnulado(double vlAnulado) {
        this.vlAnulado = vlAnulado;
    }
}