//Nome do Arquivo: Hablic
//10 – Hablic

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Hablic{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "ObjetoSocial", length = 2000, type = Type.TEXTO, required = false)
    String objetoSocial;
    @SicomColumn(description = "OrgaoRespRegistro", length = 1, type = Type.INTEIRO, required = false)
    int orgaoRespRegistro;
    @SicomColumn(description = "DataRegistro", length = 8, type = Type.DATA, required = false)
    Date dataRegistro;
    @SicomColumn(description = "NroRegistro", length = 20, type = Type.TEXTO, required = false)
    String nroRegistro;
    @SicomColumn(description = "DataRegistroCVM", length = 8, type = Type.DATA, required = false)
    Date dataRegistroCVM;
    @SicomColumn(description = "NroRegistroCVM", length = 20, type = Type.TEXTO, required = false)
    String nroRegistroCVM;
    @SicomColumn(description = "NroInscricaoEstadual", length = 30, type = Type.TEXTO, required = false)
    String nroInscricaoEstadual;
    @SicomColumn(description = "UfInscricaoEstadual", length = 2, type = Type.TEXTO, required = false)
    String ufInscricaoEstadual;
    @SicomColumn(description = "NroCertidaoRegularidadeINSS", length = 30, type = Type.TEXTO, required = false)
    String nroCertidaoRegularidadeINSS;
    @SicomColumn(description = "DtEmissaoCertidaoRegularidadeINSS", length = 8, type = Type.DATA, required = false)
    Date dtEmissaoCertidaoRegularidadeINSS;
    @SicomColumn(description = "DtValidadeCertidaoRegularidadeINSS", length = 8, type = Type.DATA, required = false)
    Date dtValidadeCertidaoRegularidadeINSS;
    @SicomColumn(description = "NroCertidaoRegularidadeFGTS", length = 30, type = Type.TEXTO, required = false)
    String nroCertidaoRegularidadeFGTS;
    @SicomColumn(description = "DtEmissaoCertidaoRegularidadeFGTS", length = 8, type = Type.DATA, required = false)
    Date dtEmissaoCertidaoRegularidadeFGTS;
    @SicomColumn(description = "DtValidadeCertidaoRegularidadeFGTS", length = 8, type = Type.DATA, required = false)
    Date dtValidadeCertidaoRegularidadeFGTS;
    @SicomColumn(description = "nroCNDT", length = 30, type = Type.TEXTO, required = false)
    String nroCNDT;
    @SicomColumn(description = "DtEmissaoCNDT", length = 8, type = Type.DATA, required = false)
    Date dtEmissaoCNDT;
    @SicomColumn(description = "DtValidadeCNDT", length = 8, type = Type.DATA, required = false)
    Date dtValidadeCNDT;
    @SicomColumn(description = "DtHabilitacao", length = 8, type = Type.DATA, required = true)
    Date dtHabilitacao;
    @SicomColumn(description = "PresencaLicitantes", length = 1, type = Type.INTEIRO, required = true)
    int presencaLicitantes;
    @SicomColumn(description = "RenunciaRecurso", length = 1, type = Type.INTEIRO, required = true)
    int renunciaRecurso;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getObjetoSocial() {
        return objetoSocial;
    }

    public void setObjetoSocial(String objetoSocial) {
        this.objetoSocial = objetoSocial;
    }

    public int getOrgaoRespRegistro() {
        return orgaoRespRegistro;
    }

    public void setOrgaoRespRegistro(int orgaoRespRegistro) {
        this.orgaoRespRegistro = orgaoRespRegistro;
    }

    public Date getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(Date dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public String getNroRegistro() {
        return nroRegistro;
    }

    public void setNroRegistro(String nroRegistro) {
        this.nroRegistro = nroRegistro;
    }

    public Date getDataRegistroCVM() {
        return dataRegistroCVM;
    }

    public void setDataRegistroCVM(Date dataRegistroCVM) {
        this.dataRegistroCVM = dataRegistroCVM;
    }

    public String getNroRegistroCVM() {
        return nroRegistroCVM;
    }

    public void setNroRegistroCVM(String nroRegistroCVM) {
        this.nroRegistroCVM = nroRegistroCVM;
    }

    public String getNroInscricaoEstadual() {
        return nroInscricaoEstadual;
    }

    public void setNroInscricaoEstadual(String nroInscricaoEstadual) {
        this.nroInscricaoEstadual = nroInscricaoEstadual;
    }

    public String getUfInscricaoEstadual() {
        return ufInscricaoEstadual;
    }

    public void setUfInscricaoEstadual(String ufInscricaoEstadual) {
        this.ufInscricaoEstadual = ufInscricaoEstadual;
    }

    public String getNroCertidaoRegularidadeINSS() {
        return nroCertidaoRegularidadeINSS;
    }

    public void setNroCertidaoRegularidadeINSS(String nroCertidaoRegularidadeINSS) {
        this.nroCertidaoRegularidadeINSS = nroCertidaoRegularidadeINSS;
    }

    public Date getDtEmissaoCertidaoRegularidadeINSS() {
        return dtEmissaoCertidaoRegularidadeINSS;
    }

    public void setDtEmissaoCertidaoRegularidadeINSS(Date dtEmissaoCertidaoRegularidadeINSS) {
        this.dtEmissaoCertidaoRegularidadeINSS = dtEmissaoCertidaoRegularidadeINSS;
    }

    public Date getDtValidadeCertidaoRegularidadeINSS() {
        return dtValidadeCertidaoRegularidadeINSS;
    }

    public void setDtValidadeCertidaoRegularidadeINSS(Date dtValidadeCertidaoRegularidadeINSS) {
        this.dtValidadeCertidaoRegularidadeINSS = dtValidadeCertidaoRegularidadeINSS;
    }

    public String getNroCertidaoRegularidadeFGTS() {
        return nroCertidaoRegularidadeFGTS;
    }

    public void setNroCertidaoRegularidadeFGTS(String nroCertidaoRegularidadeFGTS) {
        this.nroCertidaoRegularidadeFGTS = nroCertidaoRegularidadeFGTS;
    }

    public Date getDtEmissaoCertidaoRegularidadeFGTS() {
        return dtEmissaoCertidaoRegularidadeFGTS;
    }

    public void setDtEmissaoCertidaoRegularidadeFGTS(Date dtEmissaoCertidaoRegularidadeFGTS) {
        this.dtEmissaoCertidaoRegularidadeFGTS = dtEmissaoCertidaoRegularidadeFGTS;
    }

    public Date getDtValidadeCertidaoRegularidadeFGTS() {
        return dtValidadeCertidaoRegularidadeFGTS;
    }

    public void setDtValidadeCertidaoRegularidadeFGTS(Date dtValidadeCertidaoRegularidadeFGTS) {
        this.dtValidadeCertidaoRegularidadeFGTS = dtValidadeCertidaoRegularidadeFGTS;
    }

    public String getNroCNDT() {
        return nroCNDT;
    }

    public void setNroCNDT(String nroCNDT) {
        this.nroCNDT = nroCNDT;
    }

    public Date getDtEmissaoCNDT() {
        return dtEmissaoCNDT;
    }

    public void setDtEmissaoCNDT(Date dtEmissaoCNDT) {
        this.dtEmissaoCNDT = dtEmissaoCNDT;
    }

    public Date getDtValidadeCNDT() {
        return dtValidadeCNDT;
    }

    public void setDtValidadeCNDT(Date dtValidadeCNDT) {
        this.dtValidadeCNDT = dtValidadeCNDT;
    }

    public Date getDtHabilitacao() {
        return dtHabilitacao;
    }

    public void setDtHabilitacao(Date dtHabilitacao) {
        this.dtHabilitacao = dtHabilitacao;
    }

    public int getPresencaLicitantes() {
        return presencaLicitantes;
    }

    public void setPresencaLicitantes(int presencaLicitantes) {
        this.presencaLicitantes = presencaLicitantes;
    }

    public int getRenunciaRecurso() {
        return renunciaRecurso;
    }

    public void setRenunciaRecurso(int renunciaRecurso) {
        this.renunciaRecurso = renunciaRecurso;
    }
}