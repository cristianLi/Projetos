//Nome do Arquivo:DDCSaldoPassivoAtuarial
//40 – DDC - SaldoPassivoAtuarial
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DDCSaldoPassivoAtuarial{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "passivoAtuarial", length = 1, type = Type.INTEIRO, required = true)
    int passivoAtuarial;
    @SicomColumn(description = "vlSaldoAnterior", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAnterior;
    @SicomColumn(description = "vlSaldoAtual", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtual;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getPassivoAtuarial() {
        return passivoAtuarial;
    }

    public void setPassivoAtuarial(int passivoAtuarial) {
        this.passivoAtuarial = passivoAtuarial;
    }

    public double getVlSaldoAnterior() {
        return vlSaldoAnterior;
    }

    public void setVlSaldoAnterior(double vlSaldoAnterior) {
        this.vlSaldoAnterior = vlSaldoAnterior;
    }

    public double getVlSaldoAtual() {
        return vlSaldoAtual;
    }

    public void setVlSaldoAtual(double vlSaldoAtual) {
        this.vlSaldoAtual = vlSaldoAtual;
    }
}



