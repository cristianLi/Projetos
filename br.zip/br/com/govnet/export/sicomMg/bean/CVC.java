//Nome do Arquivo:CVC
//10 – CVC
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CVC{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codVeiculo", length = 10, type = Type.TEXTO, required = true)
    String codVeiculo;
    @SicomColumn(description = "tpVeiculo", length = 2, type = Type.TEXTO, required = true)
    String tpVeiculo;
    @SicomColumn(description = "subTipoVeiculo", length = 2, type = Type.TEXTO, required = true)
    String subTipoVeiculo;
    @SicomColumn(description = "descVeiculo", length = 100, type = Type.TEXTO, required = true)
    String descVeiculo;
    @SicomColumn(description = "marca", length = 50, type = Type.TEXTO, required = true)
    String marca;
    @SicomColumn(description = "modelo", length = 50, type = Type.TEXTO, required = true)
    String modelo;
    @SicomColumn(description = "ano", length = 4, type = Type.INTEIRO, required = true)
    int ano;
    @SicomColumn(description = "placa", length = 8, type = Type.TEXTO, required = false)
    String placa;
    @SicomColumn(description = "chassi", length = 30, type = Type.TEXTO, required = false)
    String chassi;
    @SicomColumn(description = "numeroRenavam", length = 14, type = Type.INTEIRO, required = false)
    int numeroRenavam;
    @SicomColumn(description = "nroSerie", length = 20, type = Type.TEXTO, required = false)
    String nroSerie;
    @SicomColumn(description = "situacao", length = 2, type = Type.TEXTO, required = true)
    String situacao;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = false)
    String nroDocumento;
    @SicomColumn(description = "tpDeslocamento", length = 2, type = Type.TEXTO, required = true)
    String tpDeslocamento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodVeiculo() {
        return codVeiculo;
    }

    public void setCodVeiculo(String codVeiculo) {
        this.codVeiculo = codVeiculo;
    }

    public String getTpVeiculo() {
        return tpVeiculo;
    }

    public void setTpVeiculo(String tpVeiculo) {
        this.tpVeiculo = tpVeiculo;
    }

    public String getSubTipoVeiculo() {
        return subTipoVeiculo;
    }

    public void setSubTipoVeiculo(String subTipoVeiculo) {
        this.subTipoVeiculo = subTipoVeiculo;
    }

    public String getDescVeiculo() {
        return descVeiculo;
    }

    public void setDescVeiculo(String descVeiculo) {
        this.descVeiculo = descVeiculo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public int getNumeroRenavam() {
        return numeroRenavam;
    }

    public void setNumeroRenavam(int numeroRenavam) {
        this.numeroRenavam = numeroRenavam;
    }

    public String getNroSerie() {
        return nroSerie;
    }

    public void setNroSerie(String nroSerie) {
        this.nroSerie = nroSerie;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getTpDeslocamento() {
        return tpDeslocamento;
    }

    public void setTpDeslocamento(String tpDeslocamento) {
        this.tpDeslocamento = tpDeslocamento;
    }
}

