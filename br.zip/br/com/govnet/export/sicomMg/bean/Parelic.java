//Nome do Arquivo:Parelic
//10 – Parelic

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Parelic{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "DataParecer", length = 8, type = Type.DATA, required = true)
    Date dataParecer;
    @SicomColumn(description = "TipoParecer", length = 1, type = Type.INTEIRO, required = true)
    int tipoParecer;
    @SicomColumn(description = "NroCpf", length = 11, type = Type.TEXTO, required = true)
    String nroCpf;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public Date getDataParecer() {
        return dataParecer;
    }

    public void setDataParecer(Date dataParecer) {
        this.dataParecer = dataParecer;
    }

    public int getTipoParecer() {
        return tipoParecer;
    }

    public void setTipoParecer(int tipoParecer) {
        this.tipoParecer = tipoParecer;
    }

    public String getNroCpf() {
        return nroCpf;
    }

    public void setNroCpf(String nroCpf) {
        this.nroCpf = nroCpf;
    }
}