//Nome do Arquivo:ContratosDetalhamentoDosTermosAditivosDosContratos
//20 – Contratos - DetalhamentoDosTermosAditivosDosContratos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ContratosDetalhamentoDosTermosAditivosDosContratos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodAditivo", length = 15, type = Type.INTEIRO, required = true)
    int codAditivo;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSub;
    @SicomColumn(description = "NroContrato", length = 14, type = Type.INTEIRO, required = true)
    int nroContrato;
    @SicomColumn(description = "DataAssinaturaContOriginal", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaContOriginal;
    @SicomColumn(description = "NroSeqTermoAditivo", length = 2, type = Type.INTEIRO, required = true)
    int nroSeqTermoAditivo;
    @SicomColumn(description = "DataAssinaturaTermoAditivo", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaTermoAditivo;
    @SicomColumn(description = "TipoAlteracaoValor", length = 1, type = Type.INTEIRO, required = true)
    int tipoAlteracaoValor;
    @SicomColumn(description = "TipoTermoAditivo", length = 2, type = Type.TEXTO, required = true)
    String tipoTermoAditivo;
    @SicomColumn(description = "DscAlteracao", length = 250, type = Type.TEXTO, required = false)
    String dscAlteracao;
    @SicomColumn(description = "NovaDataTermino", length = 8, type = Type.DATA, required = false)
    Date novaDataTermino;
    @SicomColumn(description = "ValorAditivo", length = 14, type = Type.DOUBLE, required = true)
    double valorAditivo;
    @SicomColumn(description = "DataPublicacao", length = 8, type = Type.DATA, required = true)
    Date dataPublicacao;
    @SicomColumn(description = "VeiculoDivulgacao", length = 50, type = Type.TEXTO, required = true)
    String veiculoDivulgacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodAditivo() {
        return codAditivo;
    }

    public void setCodAditivo(int codAditivo) {
        this.codAditivo = codAditivo;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public Date getDataAssinaturaContOriginal() {
        return dataAssinaturaContOriginal;
    }

    public void setDataAssinaturaContOriginal(Date dataAssinaturaContOriginal) {
        this.dataAssinaturaContOriginal = dataAssinaturaContOriginal;
    }

    public int getNroSeqTermoAditivo() {
        return nroSeqTermoAditivo;
    }

    public void setNroSeqTermoAditivo(int nroSeqTermoAditivo) {
        this.nroSeqTermoAditivo = nroSeqTermoAditivo;
    }

    public Date getDataAssinaturaTermoAditivo() {
        return dataAssinaturaTermoAditivo;
    }

    public void setDataAssinaturaTermoAditivo(Date dataAssinaturaTermoAditivo) {
        this.dataAssinaturaTermoAditivo = dataAssinaturaTermoAditivo;
    }

    public int getTipoAlteracaoValor() {
        return tipoAlteracaoValor;
    }

    public void setTipoAlteracaoValor(int tipoAlteracaoValor) {
        this.tipoAlteracaoValor = tipoAlteracaoValor;
    }

    public String getTipoTermoAditivo() {
        return tipoTermoAditivo;
    }

    public void setTipoTermoAditivo(String tipoTermoAditivo) {
        this.tipoTermoAditivo = tipoTermoAditivo;
    }

    public String getDscAlteracao() {
        return dscAlteracao;
    }

    public void setDscAlteracao(String dscAlteracao) {
        this.dscAlteracao = dscAlteracao;
    }

    public Date getNovaDataTermino() {
        return novaDataTermino;
    }

    public void setNovaDataTermino(Date novaDataTermino) {
        this.novaDataTermino = novaDataTermino;
    }

    public double getValorAditivo() {
        return valorAditivo;
    }

    public void setValorAditivo(double valorAditivo) {
        this.valorAditivo = valorAditivo;
    }

    public Date getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(Date dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }

    public String getVeiculoDivulgacao() {
        return veiculoDivulgacao;
    }

    public void setVeiculoDivulgacao(String veiculoDivulgacao) {
        this.veiculoDivulgacao = veiculoDivulgacao;
    }
}