//Nome do Arquivo:CaixaDetalhamentoReceitaContaCaixa
//13 – Caixa - DetalhamentoReceitaContaCaixa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CaixaDetalhamentoReceitaContaCaixa{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "EDeducaoDeReceita", length = 1, type = Type.INTEIRO, required = true)
    int eDeducaoDeReceita;
    @SicomColumn(description = "IdentificadorDeducao", length = 2, type = Type.INTEIRO, required = false)
    int identificadorDeducao;
    @SicomColumn(description = "NaturezaReceita", length = 8, type = Type.INTEIRO, required = true)
    int naturezaReceita;
    @SicomColumn(description = "CodFonteCaixa", length = 3, type = Type.INTEIRO, required = true)
    int codFonteCaixa;
    @SicomColumn(description = "VlrReceitaCont", length = 14, type = Type.DOUBLE, required = true)
    double vlrReceitaCont;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public int geteDeducaoDeReceita() {
        return eDeducaoDeReceita;
    }

    public void seteDeducaoDeReceita(int eDeducaoDeReceita) {
        this.eDeducaoDeReceita = eDeducaoDeReceita;
    }

    public int getIdentificadorDeducao() {
        return identificadorDeducao;
    }

    public void setIdentificadorDeducao(int identificadorDeducao) {
        this.identificadorDeducao = identificadorDeducao;
    }

    public int getNaturezaReceita() {
        return naturezaReceita;
    }

    public void setNaturezaReceita(int naturezaReceita) {
        this.naturezaReceita = naturezaReceita;
    }

    public int getCodFonteCaixa() {
        return codFonteCaixa;
    }

    public void setCodFonteCaixa(int codFonteCaixa) {
        this.codFonteCaixa = codFonteCaixa;
    }

    public double getVlrReceitaCont() {
        return vlrReceitaCont;
    }

    public void setVlrReceitaCont(double vlrReceitaCont) {
        this.vlrReceitaCont = vlrReceitaCont;
    }
}

