//Nome do Arquivo:ContratosDetalhamentoDosItensAditados
//21 – Contratos - DetalhamentoDosItensAditados

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class ContratosDetalhamentoDosItensAditados{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodAditivo", length = 15, type = Type.INTEIRO, required = true)
    int codAditivo;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "TipoAlteracaoItem", length = 1, type = Type.INTEIRO, required = true)
    int tipoAlteracaoItem;
    @SicomColumn(description = "QuantAcrescDecresc", length = 14, type = Type.DOUBLE, required = true)
    double quantAcrescDecresc;
    @SicomColumn(description = "ValorUnitarioItem", length = 14, type = Type.DOUBLE, required = true)
    double valorUnitarioItem;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodAditivo() {
        return codAditivo;
    }

    public void setCodAditivo(int codAditivo) {
        this.codAditivo = codAditivo;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public int getTipoAlteracaoItem() {
        return tipoAlteracaoItem;
    }

    public void setTipoAlteracaoItem(int tipoAlteracaoItem) {
        this.tipoAlteracaoItem = tipoAlteracaoItem;
    }

    public double getQuantAcrescDecresc() {
        return quantAcrescDecresc;
    }

    public void setQuantAcrescDecresc(double quantAcrescDecresc) {
        this.quantAcrescDecresc = quantAcrescDecresc;
    }

    public double getValorUnitarioItem() {
        return valorUnitarioItem;
    }

    public void setValorUnitarioItem(double valorUnitarioItem) {
        this.valorUnitarioItem = valorUnitarioItem;
    }
}