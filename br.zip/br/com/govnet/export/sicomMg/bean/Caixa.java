//Nome do Arquivo:Caixa
//10 – Caixa

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Caixa{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "VlSaldoInicial", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoInicial;
    @SicomColumn(description = "VlSaldoFinal", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinal;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public double getVlSaldoInicial() {
        return vlSaldoInicial;
    }

    public void setVlSaldoInicial(double vlSaldoInicial) {
        this.vlSaldoInicial = vlSaldoInicial;
    }

    public double getVlSaldoFinal() {
        return vlSaldoFinal;
    }

    public void setVlSaldoFinal(double vlSaldoFinal) {
        this.vlSaldoFinal = vlSaldoFinal;
    }
}