//Nome do Arquivo:CuteSaldosContaUnicaPorFonteRecurso
//20 – Cute - SaldosContaUnicaPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CuteSaldosContaUnicaPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlSaldoInicialFonte", length = 14, type = Type.DOUBLE, required = true)
    double  vlSaldoInicialFonte;
    @SicomColumn(description = "vlSaldoFinalFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinalFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlSaldoInicialFonte() {
        return vlSaldoInicialFonte;
    }

    public void setVlSaldoInicialFonte(double vlSaldoInicialFonte) {
        this.vlSaldoInicialFonte = vlSaldoInicialFonte;
    }

    public double getVlSaldoFinalFonte() {
        return vlSaldoFinalFonte;
    }

    public void setVlSaldoFinalFonte(double vlSaldoFinalFonte) {
        this.vlSaldoFinalFonte = vlSaldoFinalFonte;
    }
}