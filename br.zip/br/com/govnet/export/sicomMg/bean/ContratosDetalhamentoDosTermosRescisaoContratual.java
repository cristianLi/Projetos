//Nome do Arquivo:ContratosDetalhamentoDosTermosRescisaoContratual
//10 – Contratos - DetalhamentoDosTermosRescisaoContratual

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ContratosDetalhamentoDosTermosRescisaoContratual{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "NroContrato", length = 14, type = Type.INTEIRO, required = false)
    int nroContrato;
    @SicomColumn(description = "DataAssinaturaContOriginal", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaContOriginal;
    @SicomColumn(description = "DataRescisao", length = 8, type = Type.DATA, required = true)
    Date dataRescisao;
    @SicomColumn(description = "ValorCancelamentoContrato", length = 14, type = Type.DOUBLE, required = true)
    double valorCancelamentoContrato;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public Date getDataAssinaturaContOriginal() {
        return dataAssinaturaContOriginal;
    }

    public void setDataAssinaturaContOriginal(Date dataAssinaturaContOriginal) {
        this.dataAssinaturaContOriginal = dataAssinaturaContOriginal;
    }

    public Date getDataRescisao() {
        return dataRescisao;
    }

    public void setDataRescisao(Date dataRescisao) {
        this.dataRescisao = dataRescisao;
    }

    public double getValorCancelamentoContrato() {
        return valorCancelamentoContrato;
    }

    public void setValorCancelamentoContrato(double valorCancelamentoContrato) {
        this.valorCancelamentoContrato = valorCancelamentoContrato;
    }
}