//Nome do Arquivo:DCLRF
//10 – DCLRF
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DCLRF {

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "passivosReconhecidos", length = 14, type = Type.DOUBLE, required = true)
    double passivosReconhecidos;
    @SicomColumn(description = "vlSaldoAtualConcGarantiaInterna", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtualConcGarantiaInterna;
    @SicomColumn(description = "vlSaldoAtualConcGarantia", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtualConcGarantia;
    @SicomColumn(description = "vlSaldoAtualContraGarantiaInterna", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtualContraGarantiaInterna;
    @SicomColumn(description = "vlSaldoAtualContraGarantiaExterna", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtualContraGarantiaExterna;
    @SicomColumn(description = "medidasCorretivas", length = 4000, type = Type.TEXTO, required = false)
    String medidasCorretivas;
    @SicomColumn(description = "recAlienInvPermanente", length = 14, type = Type.DOUBLE, required = true)
    double recAlienInvPermanente;
    @SicomColumn(description = "vlDotAtualizadaIncentContrib", length = 14, type = Type.DOUBLE, required = true)
    double vlDotAtualizadaIncentContrib;
    @SicomColumn(description = "vlEmpenhadoIcentContrib", length = 14, type = Type.DOUBLE, required = true)
    double vlEmpenhadoIcentContrib;
    @SicomColumn(description = "vlDotAtualizadaIncentInstFinanc", length = 14, type = Type.DOUBLE, required = true)
    double vlDotAtualizadaIncentInstFinanc;
    @SicomColumn(description = "vlEmpenhadoIncentInstFinanc", length = 14, type = Type.DOUBLE, required = true)
    double vlEmpenhadoIncentInstFinanc;
    @SicomColumn(description = "vlLiqIncentContrib", length = 14, type = Type.DOUBLE, required = true)
    double vlLiqIncentContrib;
    @SicomColumn(description = "vlLiqIncentInstFinanc", length = 14, type = Type.DOUBLE, required = true)
    double vlLiqIncentInstFinanc;
    @SicomColumn(description = "vlIRPNPIncentContrib", length = 14, type = Type.DOUBLE, required = true)
    double vlIRPNPIncentContrib;
    @SicomColumn(description = "vlIRPNPIncentInstFinanc", length = 14, type = Type.DOUBLE, required = true)
    double vlIRPNPIncentInstFinanc;
    @SicomColumn(description = "vlRecursosNaoAplicados", length = 14, type = Type.DOUBLE, required = true)
    double vlRecursosNaoAplicados;
    @SicomColumn(description = "vlApropiacaoDepositosJudiciais", length = 14, type = Type.DOUBLE, required = true)
    double vlApropiacaoDepositosJudiciais;
    @SicomColumn(description = "vlOutrosAjustes", length = 14, type = Type.DOUBLE, required = true)
    double vlOutrosAjustes;
    @SicomColumn(description = "metArrecada", length = 1, type = Type.INTEIRO, required = false)
    int metArrecada;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public double getPassivosReconhecidos() {
        return passivosReconhecidos;
    }

    public void setPassivosReconhecidos(double passivosReconhecidos) {
        this.passivosReconhecidos = passivosReconhecidos;
    }

    public double getVlSaldoAtualConcGarantiaInterna() {
        return vlSaldoAtualConcGarantiaInterna;
    }

    public void setVlSaldoAtualConcGarantiaInterna(double vlSaldoAtualConcGarantiaInterna) {
        this.vlSaldoAtualConcGarantiaInterna = vlSaldoAtualConcGarantiaInterna;
    }

    public double getVlSaldoAtualConcGarantia() {
        return vlSaldoAtualConcGarantia;
    }

    public void setVlSaldoAtualConcGarantia(double vlSaldoAtualConcGarantia) {
        this.vlSaldoAtualConcGarantia = vlSaldoAtualConcGarantia;
    }

    public double getVlSaldoAtualContraGarantiaInterna() {
        return vlSaldoAtualContraGarantiaInterna;
    }

    public void setVlSaldoAtualContraGarantiaInterna(double vlSaldoAtualContraGarantiaInterna) {
        this.vlSaldoAtualContraGarantiaInterna = vlSaldoAtualContraGarantiaInterna;
    }

    public double getVlSaldoAtualContraGarantiaExterna() {
        return vlSaldoAtualContraGarantiaExterna;
    }

    public void setVlSaldoAtualContraGarantiaExterna(double vlSaldoAtualContraGarantiaExterna) {
        this.vlSaldoAtualContraGarantiaExterna = vlSaldoAtualContraGarantiaExterna;
    }

    public String getMedidasCorretivas() {
        return medidasCorretivas;
    }

    public void setMedidasCorretivas(String medidasCorretivas) {
        this.medidasCorretivas = medidasCorretivas;
    }

    public double getRecAlienInvPermanente() {
        return recAlienInvPermanente;
    }

    public void setRecAlienInvPermanente(double recAlienInvPermanente) {
        this.recAlienInvPermanente = recAlienInvPermanente;
    }

    public double getVlDotAtualizadaIncentContrib() {
        return vlDotAtualizadaIncentContrib;
    }

    public void setVlDotAtualizadaIncentContrib(double vlDotAtualizadaIncentContrib) {
        this.vlDotAtualizadaIncentContrib = vlDotAtualizadaIncentContrib;
    }

    public double getVlEmpenhadoIcentContrib() {
        return vlEmpenhadoIcentContrib;
    }

    public void setVlEmpenhadoIcentContrib(double vlEmpenhadoIcentContrib) {
        this.vlEmpenhadoIcentContrib = vlEmpenhadoIcentContrib;
    }

    public double getVlDotAtualizadaIncentInstFinanc() {
        return vlDotAtualizadaIncentInstFinanc;
    }

    public void setVlDotAtualizadaIncentInstFinanc(double vlDotAtualizadaIncentInstFinanc) {
        this.vlDotAtualizadaIncentInstFinanc = vlDotAtualizadaIncentInstFinanc;
    }

    public double getVlEmpenhadoIncentInstFinanc() {
        return vlEmpenhadoIncentInstFinanc;
    }

    public void setVlEmpenhadoIncentInstFinanc(double vlEmpenhadoIncentInstFinanc) {
        this.vlEmpenhadoIncentInstFinanc = vlEmpenhadoIncentInstFinanc;
    }

    public double getVlLiqIncentContrib() {
        return vlLiqIncentContrib;
    }

    public void setVlLiqIncentContrib(double vlLiqIncentContrib) {
        this.vlLiqIncentContrib = vlLiqIncentContrib;
    }

    public double getVlLiqIncentInstFinanc() {
        return vlLiqIncentInstFinanc;
    }

    public void setVlLiqIncentInstFinanc(double vlLiqIncentInstFinanc) {
        this.vlLiqIncentInstFinanc = vlLiqIncentInstFinanc;
    }

    public double getVlIRPNPIncentContrib() {
        return vlIRPNPIncentContrib;
    }

    public void setVlIRPNPIncentContrib(double vlIRPNPIncentContrib) {
        this.vlIRPNPIncentContrib = vlIRPNPIncentContrib;
    }

    public double getVlIRPNPIncentInstFinanc() {
        return vlIRPNPIncentInstFinanc;
    }

    public void setVlIRPNPIncentInstFinanc(double vlIRPNPIncentInstFinanc) {
        this.vlIRPNPIncentInstFinanc = vlIRPNPIncentInstFinanc;
    }

    public double getVlRecursosNaoAplicados() {
        return vlRecursosNaoAplicados;
    }

    public void setVlRecursosNaoAplicados(double vlRecursosNaoAplicados) {
        this.vlRecursosNaoAplicados = vlRecursosNaoAplicados;
    }

    public double getVlApropiacaoDepositosJudiciais() {
        return vlApropiacaoDepositosJudiciais;
    }

    public void setVlApropiacaoDepositosJudiciais(double vlApropiacaoDepositosJudiciais) {
        this.vlApropiacaoDepositosJudiciais = vlApropiacaoDepositosJudiciais;
    }

    public double getVlOutrosAjustes() {
        return vlOutrosAjustes;
    }

    public void setVlOutrosAjustes(double vlOutrosAjustes) {
        this.vlOutrosAjustes = vlOutrosAjustes;
    }

    public int getMetArrecada() {
        return metArrecada;
    }

    public void setMetArrecada(int metArrecada) {
        this.metArrecada = metArrecada;
    }
}


