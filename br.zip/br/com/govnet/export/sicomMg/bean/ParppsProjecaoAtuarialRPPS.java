//Nome do Arquivo:ParppsProjecaoAtuarialRPPS
//20 – ParppsProjecaoAtuarialRPPS
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ParppsProjecaoAtuarialRPPS{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "tipoPlano", length = 1, type = Type.INTEIRO, required = true)
    int tipoPlano;
    @SicomColumn(description = "exercicio", length = 4, type = Type.INTEIRO, required = true)
    int exercicio;
    @SicomColumn(description = "vlReceitaPrevidenciaria", length = 14, type = Type.DOUBLE, required = true)
    double vlReceitaPrevidenciaria;
    @SicomColumn(description = "vlDespesaPrevidenciaria", length = 14, type = Type.DOUBLE, required = true)
    double vlDespesaPrevidenciaria;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getTipoPlano() {
        return tipoPlano;
    }

    public void setTipoPlano(int tipoPlano) {
        this.tipoPlano = tipoPlano;
    }

    public int getExercicio() {
        return exercicio;
    }

    public void setExercicio(int exercicio) {
        this.exercicio = exercicio;
    }

    public double getVlReceitaPrevidenciaria() {
        return vlReceitaPrevidenciaria;
    }

    public void setVlReceitaPrevidenciaria(double vlReceitaPrevidenciaria) {
        this.vlReceitaPrevidenciaria = vlReceitaPrevidenciaria;
    }

    public double getVlDespesaPrevidenciaria() {
        return vlDespesaPrevidenciaria;
    }

    public void setVlDespesaPrevidenciaria(double vlDespesaPrevidenciaria) {
        this.vlDespesaPrevidenciaria = vlDespesaPrevidenciaria;
    }
}


