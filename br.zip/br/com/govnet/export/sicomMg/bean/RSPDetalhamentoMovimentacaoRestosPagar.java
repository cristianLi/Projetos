//Nome do Arquivo:RSPDetalhamentoMovimentacaoRestosPagar
//20 – RSPDetalhamentoMovimentacaoRestosPagar

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSPDetalhamentoMovimentacaoRestosPagar{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoMov", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoMov;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codUnidadeSubOrig", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSubOrig;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "exercicioEmpenho", length = 4, type = Type.INTEIRO, required = true)
    int exercicioEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "tipoRestosPagar", length = 1, type = Type.INTEIRO, required = true)
    int tipoRestosPagar;
    @SicomColumn(description = "tipoMovimento", length = 1, type = Type.INTEIRO, required = true)
    int tipoMovimento;
    @SicomColumn(description = "dtMovimentacao", length = 8, type = Type.DATA, required = true)
    date dtMovimentacao;
    @SicomColumn(description = "dotOrig", length = 17, type = Type.TEXTO, required = false)
    String dotOrig;
    @SicomColumn(description = "vlMovimentacao", length = 14, type = Type.DOUBLE, required = true)
    double vlMovimentacao;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoEncampAtribuic;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubEncampAtribuic;
    @SicomColumn(description = "justificativa", length = 500, type = Type.TEXTO, required = true)
    String justificativa;
    @SicomColumn(description = "atoCancelamento", length = 20, type = Type.TEXTO, required = false)
    String atoCancelamento;
    @SicomColumn(description = "dataAtoCancelamento", length = 8, type = Type.DATA, required = false)
    date dataAtoCancelamento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoMov() {
        return codReduzidoMov;
    }

    public void setCodReduzidoMov(int codReduzidoMov) {
        this.codReduzidoMov = codReduzidoMov;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodUnidadeSubOrig() {
        return codUnidadeSubOrig;
    }

    public void setCodUnidadeSubOrig(String codUnidadeSubOrig) {
        this.codUnidadeSubOrig = codUnidadeSubOrig;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public int getExercicioEmpenho() {
        return exercicioEmpenho;
    }

    public void setExercicioEmpenho(int exercicioEmpenho) {
        this.exercicioEmpenho = exercicioEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getTipoRestosPagar() {
        return tipoRestosPagar;
    }

    public void setTipoRestosPagar(int tipoRestosPagar) {
        this.tipoRestosPagar = tipoRestosPagar;
    }

    public int getTipoMovimento() {
        return tipoMovimento;
    }

    public void setTipoMovimento(int tipoMovimento) {
        this.tipoMovimento = tipoMovimento;
    }

    public date getDtMovimentacao() {
        return dtMovimentacao;
    }

    public void setDtMovimentacao(date dtMovimentacao) {
        this.dtMovimentacao = dtMovimentacao;
    }

    public String getDotOrig() {
        return dotOrig;
    }

    public void setDotOrig(String dotOrig) {
        this.dotOrig = dotOrig;
    }

    public double getVlMovimentacao() {
        return vlMovimentacao;
    }

    public void setVlMovimentacao(double vlMovimentacao) {
        this.vlMovimentacao = vlMovimentacao;
    }

    public String getCodOrgaoEncampAtribuic() {
        return codOrgaoEncampAtribuic;
    }

    public void setCodOrgaoEncampAtribuic(String codOrgaoEncampAtribuic) {
        this.codOrgaoEncampAtribuic = codOrgaoEncampAtribuic;
    }

    public String getCodUnidadeSubEncampAtribuic() {
        return codUnidadeSubEncampAtribuic;
    }

    public void setCodUnidadeSubEncampAtribuic(String codUnidadeSubEncampAtribuic) {
        this.codUnidadeSubEncampAtribuic = codUnidadeSubEncampAtribuic;
    }

    public String getJustificativa() {
        return justificativa;
    }

    public void setJustificativa(String justificativa) {
        this.justificativa = justificativa;
    }

    public String getAtoCancelamento() {
        return atoCancelamento;
    }

    public void setAtoCancelamento(String atoCancelamento) {
        this.atoCancelamento = atoCancelamento;
    }

    public date getDataAtoCancelamento() {
        return dataAtoCancelamento;
    }

    public void setDataAtoCancelamento(date dataAtoCancelamento) {
        this.dataAtoCancelamento = dataAtoCancelamento;
    }
}