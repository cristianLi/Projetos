//Nome do Arquivo: CONSOHablicDetalhamentoDoCredenciadoR
//20 – Hablic - DetalhamentoDoCredenciado

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class HablicDetalhamentoDoCredenciado{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "DataCredenciamento", length = 8, type = Type.DATA, required = true)
    Date DataCredenciamento;
    @SicomColumn(description = "NroLote", length = 4, type = Type.INTEIRO, required = false)
    int nroLote;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "NroInscricaoEstadual", length = 30, type = Type.TEXTO, required = false)
    String nroInscricaoEstadual;
    @SicomColumn(description = "UfInscricaoEstadual", length = 2, type = Type.TEXTO, required = false)
    String ufInscricaoEstadual;
    @SicomColumn(description = "NroCertidaoRegularidadeINSS", length = 30, type = Type.TEXTO, required = false)
    String nroCertidaoRegularidadeINSS;
    @SicomColumn(description = "DataEmissaoCertidaoRegularidadeINSS", length = 8, type = Type.DATA, required = false)
    Date dataEmissaoCertidaoRegularidadeINSS;
    @SicomColumn(description = "DataValidadeCertidaoRegularidadeINSS", length = 8, type = Type.DATA, required = false)
    Date dataValidadeCertidaoRegularidadeINSS;
    @SicomColumn(description = "NroCertidaoRegularidadeFGTS", length = 30, type = Type.TEXTO, required = false)
    String nroCertidaoRegularidadeFGTS;
    @SicomColumn(description = "DataEmissaoCertidaoRegularidadeFGTS", length = 8, type = Type.DATA, required = false)
    Date dataEmissaoCertidaoRegularidadeFGTS;
    @SicomColumn(description = "DataValidadeCertidaoRegularidadeFGTS", length = 8, type = Type.DATA, required = false)
    Date dataValidadeCertidaoRegularidadeFGTS;
    @SicomColumn(description = "NroCNDT", length = 30, type = Type.TEXTO, required = false)
    String nroCNDT;
    @SicomColumn(description = "DtEmissaoCNDT", length = 8, type = Type.DATA, required = false)
    Date dtEmissaoCNDT;
    @SicomColumn(description = "DtValidadeCNDT", length = 8, type = Type.DATA, required = false)
    Date dtValidadeCNDT;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public Date getDataCredenciamento() {
        return DataCredenciamento;
    }

    public void setDataCredenciamento(Date dataCredenciamento) {
        DataCredenciamento = dataCredenciamento;
    }

    public int getNroLote() {
        return nroLote;
    }

    public void setNroLote(int nroLote) {
        this.nroLote = nroLote;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public String getNroInscricaoEstadual() {
        return nroInscricaoEstadual;
    }

    public void setNroInscricaoEstadual(String nroInscricaoEstadual) {
        this.nroInscricaoEstadual = nroInscricaoEstadual;
    }

    public String getUfInscricaoEstadual() {
        return ufInscricaoEstadual;
    }

    public void setUfInscricaoEstadual(String ufInscricaoEstadual) {
        this.ufInscricaoEstadual = ufInscricaoEstadual;
    }

    public String getNroCertidaoRegularidadeINSS() {
        return nroCertidaoRegularidadeINSS;
    }

    public void setNroCertidaoRegularidadeINSS(String nroCertidaoRegularidadeINSS) {
        this.nroCertidaoRegularidadeINSS = nroCertidaoRegularidadeINSS;
    }

    public Date getDataEmissaoCertidaoRegularidadeINSS() {
        return dataEmissaoCertidaoRegularidadeINSS;
    }

    public void setDataEmissaoCertidaoRegularidadeINSS(Date dataEmissaoCertidaoRegularidadeINSS) {
        this.dataEmissaoCertidaoRegularidadeINSS = dataEmissaoCertidaoRegularidadeINSS;
    }

    public Date getDataValidadeCertidaoRegularidadeINSS() {
        return dataValidadeCertidaoRegularidadeINSS;
    }

    public void setDataValidadeCertidaoRegularidadeINSS(Date dataValidadeCertidaoRegularidadeINSS) {
        this.dataValidadeCertidaoRegularidadeINSS = dataValidadeCertidaoRegularidadeINSS;
    }

    public String getNroCertidaoRegularidadeFGTS() {
        return nroCertidaoRegularidadeFGTS;
    }

    public void setNroCertidaoRegularidadeFGTS(String nroCertidaoRegularidadeFGTS) {
        this.nroCertidaoRegularidadeFGTS = nroCertidaoRegularidadeFGTS;
    }

    public Date getDataEmissaoCertidaoRegularidadeFGTS() {
        return dataEmissaoCertidaoRegularidadeFGTS;
    }

    public void setDataEmissaoCertidaoRegularidadeFGTS(Date dataEmissaoCertidaoRegularidadeFGTS) {
        this.dataEmissaoCertidaoRegularidadeFGTS = dataEmissaoCertidaoRegularidadeFGTS;
    }

    public Date getDataValidadeCertidaoRegularidadeFGTS() {
        return dataValidadeCertidaoRegularidadeFGTS;
    }

    public void setDataValidadeCertidaoRegularidadeFGTS(Date dataValidadeCertidaoRegularidadeFGTS) {
        this.dataValidadeCertidaoRegularidadeFGTS = dataValidadeCertidaoRegularidadeFGTS;
    }

    public String getNroCNDT() {
        return nroCNDT;
    }

    public void setNroCNDT(String nroCNDT) {
        this.nroCNDT = nroCNDT;
    }

    public Date getDtEmissaoCNDT() {
        return dtEmissaoCNDT;
    }

    public void setDtEmissaoCNDT(Date dtEmissaoCNDT) {
        this.dtEmissaoCNDT = dtEmissaoCNDT;
    }

    public Date getDtValidadeCNDT() {
        return dtValidadeCNDT;
    }

    public void setDtValidadeCNDT(Date dtValidadeCNDT) {
        this.dtValidadeCNDT = dtValidadeCNDT;
    }
}