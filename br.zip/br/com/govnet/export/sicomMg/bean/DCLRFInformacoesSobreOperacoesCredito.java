//Nome do Arquivo:DCLRFInformacoesSobreOperacoesCredito
//20 – DCLRF - InformacoesSobreOperacoesCredito
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DCLRFInformacoesSobreOperacoesCredito{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "contOpCredito", length = 1, type = Type.INTEIRO, required = true)
    int contOpCredito;
    @SicomColumn(description = "dscContOpCredito", length = 1000, type = Type.TEXTO, required = false)
    String dscContOpCredito;
    @SicomColumn(description = "realizOpCredito", length = 1, type = Type.INTEIRO, required = true)
    int realizOpCredito;
    @SicomColumn(description = "tipoRealizOpCreditoCapta", length = 1, type = Type.INTEIRO, required = false)
    int tipoRealizOpCreditoCapta;
    @SicomColumn(description = "tipoRealizOpCreditoReceb", length = 1, type = Type.INTEIRO, required = false)
    int tipoRealizOpCreditoReceb;
    @SicomColumn(description = "tipoRealizOpCreditoAssunDir", length = 1, type = Type.INTEIRO, required = false)
    int tipoRealizOpCreditoAssunDir;
    @SicomColumn(description = "tipoRealizOpCreditoAssunObg", length = 1, type = Type.INTEIRO, required = false)
    int tipoRealizOpCreditoAssunObg;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getContOpCredito() {
        return contOpCredito;
    }

    public void setContOpCredito(int contOpCredito) {
        this.contOpCredito = contOpCredito;
    }

    public String getDscContOpCredito() {
        return dscContOpCredito;
    }

    public void setDscContOpCredito(String dscContOpCredito) {
        this.dscContOpCredito = dscContOpCredito;
    }

    public int getRealizOpCredito() {
        return realizOpCredito;
    }

    public void setRealizOpCredito(int realizOpCredito) {
        this.realizOpCredito = realizOpCredito;
    }

    public int getTipoRealizOpCreditoCapta() {
        return tipoRealizOpCreditoCapta;
    }

    public void setTipoRealizOpCreditoCapta(int tipoRealizOpCreditoCapta) {
        this.tipoRealizOpCreditoCapta = tipoRealizOpCreditoCapta;
    }

    public int getTipoRealizOpCreditoReceb() {
        return tipoRealizOpCreditoReceb;
    }

    public void setTipoRealizOpCreditoReceb(int tipoRealizOpCreditoReceb) {
        this.tipoRealizOpCreditoReceb = tipoRealizOpCreditoReceb;
    }

    public int getTipoRealizOpCreditoAssunDir() {
        return tipoRealizOpCreditoAssunDir;
    }

    public void setTipoRealizOpCreditoAssunDir(int tipoRealizOpCreditoAssunDir) {
        this.tipoRealizOpCreditoAssunDir = tipoRealizOpCreditoAssunDir;
    }

    public int getTipoRealizOpCreditoAssunObg() {
        return tipoRealizOpCreditoAssunObg;
    }

    public void setTipoRealizOpCreditoAssunObg(int tipoRealizOpCreditoAssunObg) {
        this.tipoRealizOpCreditoAssunObg = tipoRealizOpCreditoAssunObg;
    }
}

