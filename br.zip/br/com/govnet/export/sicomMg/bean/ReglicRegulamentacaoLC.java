//Nome do Arquivo:ReglicRegulamentacaoLC
//20 – Reglic - RegulamentacaoLC

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

    public class ReglicRegulamentacaoLC{

        @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
        int tipoRegistro;
        @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
        String codOrgao;
        @SicomColumn(description = "RegulamentArt47", length = 1, type = Type.INTEIRO, required = true)
        int regulamentArt47;
        @SicomColumn(description = "NroNormaReg", length = 6, type = Type.TEXTO, required = false)
        String nroNormaReg;
        @SicomColumn(description = "DataNormaReg", length = 8, type = Type.DATA, required = false)
        Date dataNormaReg;
        @SicomColumn(description = "DataPubNormaReg", length = 8, type = Type.DATA, required = false)
        Date dataPubNormaReg;
        @SicomColumn(description = "RegExclusiva", length = 1, type = Type.INTEIRO, required = false)
        int regExclusiva;
        @SicomColumn(description = "ArtigoRegExclusiva", length = 6, type = Type.TEXTO, required = false)
        String artigoRegExclusiva;
        @SicomColumn(description = "ValorLimiteRegExclusiva", length = 14, type = Type.DOUBLE, required = true)
        double valorLimiteRegExclusiva;
        @SicomColumn(description = "ProcSubContratacao", length = 1, type = Type.INTEIRO, required = false)
        int procSubContratacao;
        @SicomColumn(description = "ArtigoProcSubContratacao", length = 6, type = Type.TEXTO, required = false)
        String artigoProcSubContratacao;
        @SicomColumn(description = "PercentualSubContratacao", length = 6, type = Type.DOUBLE, required = true)
        double percentualSubContratacao;
        @SicomColumn(description = "CriteriosEmpenhoPagamento", length = 1, type = Type.INTEIRO, required = false)
        int criteriosEmpenhoPagamento;
        @SicomColumn(description = "ArtigoEmpenhoPagamento", length = 6, type = Type.TEXTO, required = false)
        int artigoEmpenhoPagamento;
        @SicomColumn(description = "EstabeleceuPercContratacao", length = 1, type = Type.INTEIRO, required = false)
        int estabeleceuPercContratacao;
        @SicomColumn(description = "ArtigoPercContratacao", length = 6, type = Type.TEXTO, required = false)
        String artigoPercContratacao;
        @SicomColumn(description = "PercentualContratacao", length = 6, type = Type.DOUBLE, required = true)
        double percentualContratacao;

        public int getTipoRegistro() {
            return tipoRegistro;
        }

        public void setTipoRegistro(int tipoRegistro) {
            this.tipoRegistro = tipoRegistro;
        }

        public String getCodOrgao() {
            return codOrgao;
        }

        public void setCodOrgao(String codOrgao) {
            this.codOrgao = codOrgao;
        }

        public int getRegulamentArt47() {
            return regulamentArt47;
        }

        public void setRegulamentArt47(int regulamentArt47) {
            this.regulamentArt47 = regulamentArt47;
        }

        public String getNroNormaReg() {
            return nroNormaReg;
        }

        public void setNroNormaReg(String nroNormaReg) {
            this.nroNormaReg = nroNormaReg;
        }

        public Date getDataNormaReg() {
            return dataNormaReg;
        }

        public void setDataNormaReg(Date dataNormaReg) {
            this.dataNormaReg = dataNormaReg;
        }

        public Date getDataPubNormaReg() {
            return dataPubNormaReg;
        }

        public void setDataPubNormaReg(Date dataPubNormaReg) {
            this.dataPubNormaReg = dataPubNormaReg;
        }

        public int getRegExclusiva() {
            return regExclusiva;
        }

        public void setRegExclusiva(int regExclusiva) {
            this.regExclusiva = regExclusiva;
        }

        public String getArtigoRegExclusiva() {
            return artigoRegExclusiva;
        }

        public void setArtigoRegExclusiva(String artigoRegExclusiva) {
            this.artigoRegExclusiva = artigoRegExclusiva;
        }

        public double getValorLimiteRegExclusiva() {
            return valorLimiteRegExclusiva;
        }

        public void setValorLimiteRegExclusiva(double valorLimiteRegExclusiva) {
            this.valorLimiteRegExclusiva = valorLimiteRegExclusiva;
        }

        public int getProcSubContratacao() {
            return procSubContratacao;
        }

        public void setProcSubContratacao(int procSubContratacao) {
            this.procSubContratacao = procSubContratacao;
        }

        public String getArtigoProcSubContratacao() {
            return artigoProcSubContratacao;
        }

        public void setArtigoProcSubContratacao(String artigoProcSubContratacao) {
            this.artigoProcSubContratacao = artigoProcSubContratacao;
        }

        public double getPercentualSubContratacao() {
            return percentualSubContratacao;
        }

        public void setPercentualSubContratacao(double percentualSubContratacao) {
            this.percentualSubContratacao = percentualSubContratacao;
        }

        public int getCriteriosEmpenhoPagamento() {
            return criteriosEmpenhoPagamento;
        }

        public void setCriteriosEmpenhoPagamento(int criteriosEmpenhoPagamento) {
            this.criteriosEmpenhoPagamento = criteriosEmpenhoPagamento;
        }

        public int getArtigoEmpenhoPagamento() {
            return artigoEmpenhoPagamento;
        }

        public void setArtigoEmpenhoPagamento(int artigoEmpenhoPagamento) {
            this.artigoEmpenhoPagamento = artigoEmpenhoPagamento;
        }

        public int getEstabeleceuPercContratacao() {
            return estabeleceuPercContratacao;
        }

        public void setEstabeleceuPercContratacao(int estabeleceuPercContratacao) {
            this.estabeleceuPercContratacao = estabeleceuPercContratacao;
        }

        public String getArtigoPercContratacao() {
            return artigoPercContratacao;
        }

        public void setArtigoPercContratacao(String artigoPercContratacao) {
            this.artigoPercContratacao = artigoPercContratacao;
        }

        public double getPercentualContratacao() {
            return percentualContratacao;
        }

        public void setPercentualContratacao(double percentualContratacao) {
            this.percentualContratacao = percentualContratacao;
        }
    }