//Nome do Arquivo:Cute
//10 – Cute

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Cute{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "tipoConta", length = 2, type = Type.TEXTO, required = true)
    String tipoConta;
    @SicomColumn(description = "codCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "banco", length = 3, type = Type.INTEIRO, required = true)
    int banco;
    @SicomColumn(description = "agencia", length = 6, type = Type.TEXTO, required = true)
    String agencia;
    @SicomColumn(description = "digitoVerificadorAgencia", length = 2, type = Type.TEXTO, required = false)
    String digitoVerificadorAgencia;
    @SicomColumn(description = "contaBancaria", length = 12, type = Type.INTEIRO, required = true)
    int contaBancaria;
    @SicomColumn(description = "digitoVerificadorContaBancaria", length = 2, type = Type.TEXTO, required = true)
    String digitoVerificadorContaBancaria;
    @SicomColumn(description = "descContaBancaria", length = 50, type = Type.TEXTO, required = true)
    String descContaBancaria;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        this.tipoConta = tipoConta;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getBanco() {
        return banco;
    }

    public void setBanco(int banco) {
        this.banco = banco;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getDigitoVerificadorAgencia() {
        return digitoVerificadorAgencia;
    }

    public void setDigitoVerificadorAgencia(String digitoVerificadorAgencia) {
        this.digitoVerificadorAgencia = digitoVerificadorAgencia;
    }

    public int getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(int contaBancaria) {
        this.contaBancaria = contaBancaria;
    }

    public String getDigitoVerificadorContaBancaria() {
        return digitoVerificadorContaBancaria;
    }

    public void setDigitoVerificadorContaBancaria(String digitoVerificadorContaBancaria) {
        this.digitoVerificadorContaBancaria = digitoVerificadorContaBancaria;
    }

    public String getDescContaBancaria() {
        return descContaBancaria;
    }

    public void setDescContaBancaria(String descContaBancaria) {
        this.descContaBancaria = descContaBancaria;
    }
}