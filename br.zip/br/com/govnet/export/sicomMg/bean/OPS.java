//Nome do Arquivo:OPS
//10 – OPS
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class OPS{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroOP", length = 22, type = Type.INTEIRO, required = true)
    int nroOP;
    @SicomColumn(description = "dtPagamento", length = 8, type = Type.DATA, required = true)
    date dtPagamento;
    @SicomColumn(description = "vlOP", length = 14, type = Type.DOUBLE, required = true)
    double vlOP;
    @SicomColumn(description = "especificacaoOP", length = 500, type = Type.TEXTO, required = true)
    String especificacaoOP;
    @SicomColumn(description = "cpfRespPgto", length = 11, type = Type.TEXTO, required = true)
    String cpfRespPgto;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroOP() {
        return nroOP;
    }

    public void setNroOP(int nroOP) {
        this.nroOP = nroOP;
    }

    public date getDtPagamento() {
        return dtPagamento;
    }

    public void setDtPagamento(date dtPagamento) {
        this.dtPagamento = dtPagamento;
    }

    public double getVlOP() {
        return vlOP;
    }

    public void setVlOP(double vlOP) {
        this.vlOP = vlOP;
    }

    public String getEspecificacaoOP() {
        return especificacaoOP;
    }

    public void setEspecificacaoOP(String especificacaoOP) {
        this.especificacaoOP = especificacaoOP;
    }

    public String getCpfRespPgto() {
        return cpfRespPgto;
    }

    public void setCpfRespPgto(String cpfRespPgto) {
        this.cpfRespPgto = cpfRespPgto;
    }
}