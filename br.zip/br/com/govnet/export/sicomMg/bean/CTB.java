//Nome do Arquivo:CTB
//10 – CTB

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CTB{
    
    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodCTB", length = 20, type = Type.INTEIRO, required = true)    
    int codCTB;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "Banco", length = 3, type = Type.INTEIRO, required = true)
    int banco;
    @SicomColumn(description = "Agencia", length = 6, type = Type.TEXTO, required = true)
    String agencia;
    @SicomColumn(description = "DigitoVerificadorAgencia", length = 2, type = Type.TEXTO, required = false)
    String digitoVerificadorAgencia;
    @SicomColumn(description = "ContaBancaria", length = 12, type = Type.INTEIRO, required = true)
    int contaBancaria;
    @SicomColumn(description = "DigitoVerificadorContaBancaria", length = 2, type = Type.TEXTO, required = true)
    String digitoVerificadorContaBancaria;
    @SicomColumn(description = "TipoConta", length = 2, type = Type.TEXTO, required = true)
    String tipoConta;
    @SicomColumn(description = "TipoAplicacao", length = 2, type = Type.TEXTO, required = false)
    String tipoAplicacao;
    @SicomColumn(description = "NroSeqAplicacao", length = 2, type = Type.INTEIRO, required = false)
    int nroSeqAplicacao;
    @SicomColumn(description = "DescContaBancaria", length = 50, type = Type.TEXTO, required = true)
    String descContaBancaria;
    @SicomColumn(description = "ContaConvenio", length = 1, type = Type.INTEIRO, required = true)
    int contaConvenio;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;
    @SicomColumn(description = "DataAssinaturaConvenio", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConvenio;
        
    public int getTipoRegistro(){
        return tipoRegistro;
    }
    public int setTipoRegistro(){
        return tipoRegistro;
    }
    public int getCodCTB(){
        return codCTB;
    }
    public int setCodCTB(){
        return codCTB;
    }
    public String getCodOrgao(){
        return codOrgao;
    }
    public String setCodOrgao{
        return codOrgao;
    }
    public int getBanco(){
        return banco;
    }
    public int setBanco(){
        return banco;
    }
    public String getAgencia(){
        return agencia;
    }
    public String setAgencia(){
        return agencia;
    }
    public String getDigitoVerificadorAgencia(){
        return digitoVerificadorAgencia;
    }
    public String setDigitoVerificadorAgencia(){
        return digitoVerificadorAgencia;
    }
    public int getContaBancaria(){
        return contaBancaria;
    }
    public int setContaBancaria(){
        return contaBancaria;
    }
    public String getDigitoVerificadorContaBancaria(){
        return digitoVerificadorContaBancaria;
    }
    public String setDigitoVerificadorContaBancaria(){
        return digitoVerificadorContaBancaria;
    }
    public String getTipoConta(){
        return tipoConta;
    }
    public String setTipoConta(){
        return tipoConta;
    }
    public String getTipoAplicacao(){
        return tipoAplicacao;
    }
    public String setTipoAplicacao(){
        return tipoAplicacao;
    }
    public int getNroSeqAplicacao(){
        return nroSeqAplicacao;
    }
    public int setNroSeqAplicacao(){
        return nroSeqAplicacao;
    }
    public String getDescContaBancaria(){
        return descContaBancaria;
    }
    public String setDescContaBancaria(){
        return descContaBancaria;
    }
    public int getContaConvenio(){
        return contaConvenio;
    }
    public int setContaConvenio(){
        return contaConvenio;
    }
    public String getNroConvenio(){
        return nroConvenio;
    }
    public String setNroConvenio(){
        return nroConvenio;
    }
    public Date getDataAssinaturaConvenio(){
        return dataAssinaturaConvenio;
    }
    public Date setDataAssinaturaConvenio(){
        return dataAssinaturaConvenio;
    }
}