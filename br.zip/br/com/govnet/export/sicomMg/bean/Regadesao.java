//Nome do Arquivo:Regadesao
//10 – regadesao

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Regadesao{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "NroProcAdesao", length = 12, type = Type.TEXTO, required = true)
    String nroProcAdesao;
    @SicomColumn(description = "ExercicioAdesao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioAdesao;
    @SicomColumn(description = "DtAbertura", length = 8, type = Type.DATA, required = true)
    Date dtAbertura;
    @SicomColumn(description = "NomeOrgaoGerenciador", length = 100, type = Type.TEXTO, required = true)
    String nomeOrgaoGerenciador;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 20, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "CodModalidadeLicitacao", length = 1, type = Type.INTEIRO, required = true)
    int codModalidadeLicitacao;
    @SicomColumn(description = "NroModalidade", length = 10, type = Type.INTEIRO, required = true)
    int nroModalidade;
    @SicomColumn(description = "DtAtaRegPreco", length = 8, type = Type.DATA, required = true)
    Date dtAtaRegPreco;
    @SicomColumn(description = "DtValidade", length = 8, type = Type.DATA, required = true)
    Date;
    @SicomColumn(description = "NaturezaProcedimento", length = 1, type = Type.INTEIRO, required = true)
    int naturezaProcedimento;
    @SicomColumn(description = "DtPublicacaoAvisoIntencao", length = 8, type = Type.DATA, required = false)
    Date dtPublicacaoAvisoIntencao;
    @SicomColumn(description = "ObjetoAdesao", length = 500, type = Type.TEXTO, required = true)
    String objetoAdesao;
    @SicomColumn(description = "CpfResponsavel", length = 11, type = Type.TEXTO, required = true)
    String cpfResponsavel;
    @SicomColumn(description = "DescontoTabela", length = 1, type = Type.INTEIRO, required = true)
    int descontoTabela;
    @SicomColumn(description = "ProcessoPorLote", length = 1, type = Type.INTEIRO, required = true)
    int processoPorLote;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroProcAdesao() {
        return nroProcAdesao;
    }

    public void setNroProcAdesao(String nroProcAdesao) {
        this.nroProcAdesao = nroProcAdesao;
    }

    public int getExercicioAdesao() {
        return exercicioAdesao;
    }

    public void setExercicioAdesao(int exercicioAdesao) {
        this.exercicioAdesao = exercicioAdesao;
    }

    public Date getDtAbertura() {
        return dtAbertura;
    }

    public void setDtAbertura(Date dtAbertura) {
        this.dtAbertura = dtAbertura;
    }

    public String getNomeOrgaoGerenciador() {
        return nomeOrgaoGerenciador;
    }

    public void setNomeOrgaoGerenciador(String nomeOrgaoGerenciador) {
        this.nomeOrgaoGerenciador = nomeOrgaoGerenciador;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getCodModalidadeLicitacao() {
        return codModalidadeLicitacao;
    }

    public void setCodModalidadeLicitacao(int codModalidadeLicitacao) {
        this.codModalidadeLicitacao = codModalidadeLicitacao;
    }

    public int getNroModalidade() {
        return nroModalidade;
    }

    public void setNroModalidade(int nroModalidade) {
        this.nroModalidade = nroModalidade;
    }

    public Date getDtAtaRegPreco() {
        return dtAtaRegPreco;
    }

    public void setDtAtaRegPreco(Date dtAtaRegPreco) {
        this.dtAtaRegPreco = dtAtaRegPreco;
    }

    public int getNaturezaProcedimento() {
        return naturezaProcedimento;
    }

    public void setNaturezaProcedimento(int naturezaProcedimento) {
        this.naturezaProcedimento = naturezaProcedimento;
    }

    public Date getDtPublicacaoAvisoIntencao() {
        return dtPublicacaoAvisoIntencao;
    }

    public void setDtPublicacaoAvisoIntencao(Date dtPublicacaoAvisoIntencao) {
        this.dtPublicacaoAvisoIntencao = dtPublicacaoAvisoIntencao;
    }

    public String getObjetoAdesao() {
        return objetoAdesao;
    }

    public void setObjetoAdesao(String objetoAdesao) {
        this.objetoAdesao = objetoAdesao;
    }

    public String getCpfResponsavel() {
        return cpfResponsavel;
    }

    public void setCpfResponsavel(String cpfResponsavel) {
        this.cpfResponsavel = cpfResponsavel;
    }

    public int getDescontoTabela() {
        return descontoTabela;
    }

    public void setDescontoTabela(int descontoTabela) {
        this.descontoTabela = descontoTabela;
    }

    public int getProcessoPorLote() {
        return processoPorLote;
    }

    public void setProcessoPorLote(int processoPorLote) {
        this.processoPorLote = processoPorLote;
    }
}