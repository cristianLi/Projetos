//Nome do Arquivo:EXTSaldoDasExtraorcaMentariasPorFonteRecurso
//20 – EXT - SaldoDasExtraorcaMentariasPorFonteRecurso
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EXTSaldoDasExtraorcaMentariasPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codEXT", length = 15, type = Type.INTEIRO, required = true)
    int codEXT;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlSaldoAnteriorFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAnteriorFonte;
    @SicomColumn(description = "natSaldoAnteriorFonte", length = 1, type = Type.TEXTO, required = true)
    String natSaldoAnteriorFonte;
    @SicomColumn(description = "totalDebitos", length = 14, type = Type.DOUBLE, required = true)
    double totalDebitos;
    @SicomColumn(description = "totalCreditos", length = 14, type = Type.DOUBLE, required = true)
    double totalCreditos;
    @SicomColumn(description = "vlSaldoAtualFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAtualFonte;
    @SicomColumn(description = "natSaldoAtualFonte", length = 1, type = Type.TEXTO, required = true)
    String natSaldoAtualFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodEXT() {
        return codEXT;
    }

    public void setCodEXT(int codEXT) {
        this.codEXT = codEXT;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlSaldoAnteriorFonte() {
        return vlSaldoAnteriorFonte;
    }

    public void setVlSaldoAnteriorFonte(double vlSaldoAnteriorFonte) {
        this.vlSaldoAnteriorFonte = vlSaldoAnteriorFonte;
    }

    public String getNatSaldoAnteriorFonte() {
        return natSaldoAnteriorFonte;
    }

    public void setNatSaldoAnteriorFonte(String natSaldoAnteriorFonte) {
        this.natSaldoAnteriorFonte = natSaldoAnteriorFonte;
    }

    public double getTotalDebitos() {
        return totalDebitos;
    }

    public void setTotalDebitos(double totalDebitos) {
        this.totalDebitos = totalDebitos;
    }

    public double getTotalCreditos() {
        return totalCreditos;
    }

    public void setTotalCreditos(double totalCreditos) {
        this.totalCreditos = totalCreditos;
    }

    public double getVlSaldoAtualFonte() {
        return vlSaldoAtualFonte;
    }

    public void setVlSaldoAtualFonte(double vlSaldoAtualFonte) {
        this.vlSaldoAtualFonte = vlSaldoAtualFonte;
    }

    public String getNatSaldoAtualFonte() {
        return natSaldoAtualFonte;
    }

    public void setNatSaldoAtualFonte(String natSaldoAtualFonte) {
        this.natSaldoAtualFonte = natSaldoAtualFonte;
    }
}