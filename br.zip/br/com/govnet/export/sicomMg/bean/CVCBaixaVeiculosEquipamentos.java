//Nome do Arquivo:CVCBaixaVeiculosEquipamentos
//40 – CVC - BaixaVeiculosEquipamentos
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CVCBaixaVeiculosEquipamentos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codVeiculo", length = 10, type = Type.TEXTO, required = true)
    String codVeiculo;
    @SicomColumn(description = "tipoBaixa", length = 2, type = Type.TEXTO, required = true)
    String tipoBaixa;
    @SicomColumn(description = "descBaixa", length = 50, type = Type.TEXTO, required = false)
    String descBaixa;
    @SicomColumn(description = "dtBaixa", length = 8, type = Type.DATA, required = true)
    date dtBaixa;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodVeiculo() {
        return codVeiculo;
    }

    public void setCodVeiculo(String codVeiculo) {
        this.codVeiculo = codVeiculo;
    }

    public String getTipoBaixa() {
        return tipoBaixa;
    }

    public void setTipoBaixa(String tipoBaixa) {
        this.tipoBaixa = tipoBaixa;
    }

    public String getDescBaixa() {
        return descBaixa;
    }

    public void setDescBaixa(String descBaixa) {
        this.descBaixa = descBaixa;
    }

    public date getDtBaixa() {
        return dtBaixa;
    }

    public void setDtBaixa(date dtBaixa) {
        this.dtBaixa = dtBaixa;
    }
}
