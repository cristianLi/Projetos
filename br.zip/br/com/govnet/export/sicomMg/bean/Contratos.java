//Nome do Arquivo:Contratos
//10 – Contratos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Contratos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodContrato", length = 15, type = Type.INTEIRO, required = true)
    int codContrato;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "NroContrato", length = 14, type = Type.INTEIRO, required = true)
    int nroContrato;
    @SicomColumn(description = "ExercicioContrato", length = 4, type = Type.INTEIRO, required = true)
    int exercicioContrato;
    @SicomColumn(description = "DataAssinatura", length = 8, type = Type.DATA, required = true)
    Date dataAssinatura;
    @SicomColumn(description = "ContDecLicitacao", length = 1, type = Type.INTEIRO, required = true)
    int contDecLicitacao;
    @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoResp;
    @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeSubResp;
    @SicomColumn(description = "NroProcesso", length = 12, type = Type.TEXTO, required = false)
    String nroProcesso;
    @SicomColumn(description = "ExercicioProcesso", length = 4, type = Type.INTEIRO, required = false)
    int exercicioProcesso;
    @SicomColumn(description = "TipoProcesso", length = 1, type = Type.INTEIRO, required = false)
    int tipoProcesso;
    @SicomColumn(description = "NaturezaObjeto", length = 1, type = Type.INTEIRO, required = true)
    int naturezaObjeto;
    @SicomColumn(description = "ObjetoContrato", length = 500, type = Type.TEXTO, required = true)
    String objetoContrato;
    @SicomColumn(description = "TipoInstrumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoInstrumento;
    @SicomColumn(description = "DataInicioVigencia", length = 8, type = Type.DATA, required = true)
    Date dataInicioVigencia;
    @SicomColumn(description = "DataFinalVigencia", length = 8, type = Type.DATA, required = true)
    Date dataFinalVigencia;
    @SicomColumn(description = "VlContrato", length = 14, type = Type.DOUBLE, required = true)
    Double vlContrato;
    @SicomColumn(description = "FormaFornecimento", length = 50, type = Type.TEXTO, required = false)
    String formaFornecimento;
    @SicomColumn(description = "FormaPagamento", length = 100, type = Type.TEXTO, required = false)
    String formaPagamento;
    @SicomColumn(description = "PrazoExecucao", length = 100, type = Type.TEXTO, required = false)
    String prazoExecucao;
    @SicomColumn(description = "MultaRescisoria", length = 100, type = Type.TEXTO, required = false)
    String multaRescisoria;
    @SicomColumn(description = "MultaInadimplemento", length = 100, type = Type.TEXTO, required = false)
    String multaInadimplemento;
    @SicomColumn(description = "Garantia", length = 1, type = Type.INTEIRO, required = false)
    int garantia;
    @SicomColumn(description = "CpfsignatarioContratante", length = 11, type = Type.TEXTO, required = true)
    String cpfsignatarioContratante;
    @SicomColumn(description = "DataPublicacao", length = 8, type = Type.DATA, required = true)
    Date dataPublicacao;
    @SicomColumn(description = "VeiculoDivulgacao", length = 50, type = Type.TEXTO, required = true)
    String veiculoDivulgacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodContrato() {
        return codContrato;
    }

    public void setCodContrato(int codContrato) {
        this.codContrato = codContrato;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroContrato() {
        return nroContrato;
    }

    public void setNroContrato(int nroContrato) {
        this.nroContrato = nroContrato;
    }

    public int getExercicioContrato() {
        return exercicioContrato;
    }

    public void setExercicioContrato(int exercicioContrato) {
        this.exercicioContrato = exercicioContrato;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public int getContDecLicitacao() {
        return contDecLicitacao;
    }

    public void setContDecLicitacao(int contDecLicitacao) {
        this.contDecLicitacao = contDecLicitacao;
    }

    public String getCodOrgaoResp() {
        return codOrgaoResp;
    }

    public void setCodOrgaoResp(String codOrgaoResp) {
        this.codOrgaoResp = codOrgaoResp;
    }

    public String getCodUnidadeSubResp() {
        return codUnidadeSubResp;
    }

    public void setCodUnidadeSubResp(String codUnidadeSubResp) {
        this.codUnidadeSubResp = codUnidadeSubResp;
    }

    public String getNroProcesso() {
        return nroProcesso;
    }

    public void setNroProcesso(String nroProcesso) {
        this.nroProcesso = nroProcesso;
    }

    public int getExercicioProcesso() {
        return exercicioProcesso;
    }

    public void setExercicioProcesso(int exercicioProcesso) {
        this.exercicioProcesso = exercicioProcesso;
    }

    public int getTipoProcesso() {
        return tipoProcesso;
    }

    public void setTipoProcesso(int tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }

    public int getNaturezaObjeto() {
        return naturezaObjeto;
    }

    public void setNaturezaObjeto(int naturezaObjeto) {
        this.naturezaObjeto = naturezaObjeto;
    }

    public String getObjetoContrato() {
        return objetoContrato;
    }

    public void setObjetoContrato(String objetoContrato) {
        this.objetoContrato = objetoContrato;
    }

    public int getTipoInstrumento() {
        return tipoInstrumento;
    }

    public void setTipoInstrumento(int tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }

    public Date getDataInicioVigencia() {
        return dataInicioVigencia;
    }

    public void setDataInicioVigencia(Date dataInicioVigencia) {
        this.dataInicioVigencia = dataInicioVigencia;
    }

    public Date getDataFinalVigencia() {
        return dataFinalVigencia;
    }

    public void setDataFinalVigencia(Date dataFinalVigencia) {
        this.dataFinalVigencia = dataFinalVigencia;
    }

    public Double getVlContrato() {
        return vlContrato;
    }

    public void setVlContrato(Double vlContrato) {
        this.vlContrato = vlContrato;
    }

    public String getFormaFornecimento() {
        return formaFornecimento;
    }

    public void setFormaFornecimento(String formaFornecimento) {
        this.formaFornecimento = formaFornecimento;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public String getPrazoExecucao() {
        return prazoExecucao;
    }

    public void setPrazoExecucao(String prazoExecucao) {
        this.prazoExecucao = prazoExecucao;
    }

    public String getMultaRescisoria() {
        return multaRescisoria;
    }

    public void setMultaRescisoria(String multaRescisoria) {
        this.multaRescisoria = multaRescisoria;
    }

    public String getMultaInadimplemento() {
        return multaInadimplemento;
    }

    public void setMultaInadimplemento(String multaInadimplemento) {
        this.multaInadimplemento = multaInadimplemento;
    }

    public int getGarantia() {
        return garantia;
    }

    public void setGarantia(int garantia) {
        this.garantia = garantia;
    }

    public String getCpfsignatarioContratante() {
        return cpfsignatarioContratante;
    }

    public void setCpfsignatarioContratante(String cpfsignatarioContratante) {
        this.cpfsignatarioContratante = cpfsignatarioContratante;
    }

    public Date getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(Date dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }

    public String getVeiculoDivulgacao() {
        return veiculoDivulgacao;
    }

    public void setVeiculoDivulgacao(String veiculoDivulgacao) {
        this.veiculoDivulgacao = veiculoDivulgacao;
    }
}