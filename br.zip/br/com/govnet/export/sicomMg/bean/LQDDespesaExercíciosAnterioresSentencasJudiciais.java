//Nome do Arquivo:LQDDespesaExercíciosAnterioresSentencasJudiciais
//12 – LQDDespesaExercíciosAnterioresSentencasJudiciais

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class LQDDespesaExercíciosAnterioresSentencasJudiciais{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "mesCompetencia", length = 2, type = Type.TEXTO, required = true)
    String mesCompetencia;
    @SicomColumn(description = "exercicioCompetencia", length = 4, type = Type.INTEIRO, required = true)
    int exercicioCompetencia;
    @SicomColumn(description = "vlDspExerAnt", length = 14, type = Type.DOUBLE, required = true)
    double vlDspExerAnt;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public String getMesCompetencia() {
        return mesCompetencia;
    }

    public void setMesCompetencia(String mesCompetencia) {
        this.mesCompetencia = mesCompetencia;
    }

    public int getExercicioCompetencia() {
        return exercicioCompetencia;
    }

    public void setExercicioCompetencia(int exercicioCompetencia) {
        this.exercicioCompetencia = exercicioCompetencia;
    }

    public double getVlDspExerAnt() {
        return vlDspExerAnt;
    }

    public void setVlDspExerAnt(double vlDspExerAnt) {
        this.vlDspExerAnt = vlDspExerAnt;
    }
}