//Nome do Arquivo:CongeDetalhamentoPrestacaoContasConveniosInstrumentosCongeneres
//40 – Conge - DetalhamentoPrestacaoContasConveniosInstrumentosCongeneres
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CongeDetalhamentoPrestacaoContasConveniosInstrumentosCongeneres{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dataAssinaturaConvOriginalConge", length = 8, type = Type.DATA, required = true)
    date dataAssinaturaConvOriginalConge;
    @SicomColumn(description = "numeroParcela", length = 3, type = Type.INTEIRO, required = true)
    int numeroParcela;
    @SicomColumn(description = "dataRepasseConge", length = 8, type = Type.DATA, required = true)
    date dataRepasseConge;
    @SicomColumn(description = "prestacaoContasParcela", length = 1, type = Type.INTEIRO, required = true)
    int prestacaoContasParcela;
    @SicomColumn(description = "dataPrestaContasParcela", length = 8, type = Type.DATA, required = false)
    date dataPrestaContasParcela;
    @SicomColumn(description = "prestacaoContas", length = 1, type = Type.INTEIRO, required = true)
    int prestacaoContas;
    @SicomColumn(description = "dataCienFatos", length = 8, type = Type.DATA, required = false)
    date dataCienFatos;
    @SicomColumn(description = "prorrogPrazo", length = 1, type = Type.INTEIRO, required = false)
    int prorrogPrazo;
    @SicomColumn(description = "dataProrrogPrazo", length = 8, type = Type.DATA, required = false)
    date dataProrrogPrazo;
    @SicomColumn(description = "nroCPFRespPrestConge", length = 1, type = Type.INTEIRO, required = true)
    int nroCPFRespPrestConge;
    @SicomColumn(description = "dscCargoRespPrestConge", length = 8, type = Type.DATA, required = false)
    date dscCargoRespPrestConge;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinaturaConvOriginalConge() {
        return dataAssinaturaConvOriginalConge;
    }

    public void setDataAssinaturaConvOriginalConge(date dataAssinaturaConvOriginalConge) {
        this.dataAssinaturaConvOriginalConge = dataAssinaturaConvOriginalConge;
    }

    public int getNumeroParcela() {
        return numeroParcela;
    }

    public void setNumeroParcela(int numeroParcela) {
        this.numeroParcela = numeroParcela;
    }

    public date getDataRepasseConge() {
        return dataRepasseConge;
    }

    public void setDataRepasseConge(date dataRepasseConge) {
        this.dataRepasseConge = dataRepasseConge;
    }

    public int getPrestacaoContasParcela() {
        return prestacaoContasParcela;
    }

    public void setPrestacaoContasParcela(int prestacaoContasParcela) {
        this.prestacaoContasParcela = prestacaoContasParcela;
    }

    public date getDataPrestaContasParcela() {
        return dataPrestaContasParcela;
    }

    public void setDataPrestaContasParcela(date dataPrestaContasParcela) {
        this.dataPrestaContasParcela = dataPrestaContasParcela;
    }

    public int getPrestacaoContas() {
        return prestacaoContas;
    }

    public void setPrestacaoContas(int prestacaoContas) {
        this.prestacaoContas = prestacaoContas;
    }

    public date getDataCienFatos() {
        return dataCienFatos;
    }

    public void setDataCienFatos(date dataCienFatos) {
        this.dataCienFatos = dataCienFatos;
    }

    public int getProrrogPrazo() {
        return prorrogPrazo;
    }

    public void setProrrogPrazo(int prorrogPrazo) {
        this.prorrogPrazo = prorrogPrazo;
    }

    public date getDataProrrogPrazo() {
        return dataProrrogPrazo;
    }

    public void setDataProrrogPrazo(date dataProrrogPrazo) {
        this.dataProrrogPrazo = dataProrrogPrazo;
    }

    public int getNroCPFRespPrestConge() {
        return nroCPFRespPrestConge;
    }

    public void setNroCPFRespPrestConge(int nroCPFRespPrestConge) {
        this.nroCPFRespPrestConge = nroCPFRespPrestConge;
    }

    public date getDscCargoRespPrestConge() {
        return dscCargoRespPrestConge;
    }

    public void setDscCargoRespPrestConge(date dscCargoRespPrestConge) {
        this.dscCargoRespPrestConge = dscCargoRespPrestConge;
    }
}


