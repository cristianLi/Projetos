//Nome do Arquivo: Resplic
//10 – Resplic

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Resplic{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "TipoResp", length = 1, type = Type.INTEIRO, required = true)
    int tipoResp;
    @SicomColumn(description = "NroCPFResp", length = 11, type = Type.TEXTO, required = true)
    String nroCPFResp;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getTipoResp() {
        return tipoResp;
    }

    public void setTipoResp(int tipoResp) {
        this.tipoResp = tipoResp;
    }

    public String getNroCPFResp() {
        return nroCPFResp;
    }

    public void setNroCPFResp(String nroCPFResp) {
        this.nroCPFResp = nroCPFResp;
    }
}