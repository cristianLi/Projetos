//Nome do Arquivo: AberlicDetalhamentoPesquisaPrecosOrcamentosEmplanilha
//14 – Aberlic - DetalhamentoPesquisaPrecosOrcamentosEmplanilha

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AberlicDetalhamentoPesquisaPrecosOrcamentosEmplanilha{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = true)
    String codOrgaoResp;
    @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSubResp;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcesso", length = 4, type = Type.INTEIRO, required = true)
    int nroProcesso;
    @SicomColumn(description = "Licitatorio", length = 12, type = Type.TEXTO, required = true)
    String  Licitatorio;
    @SicomColumn(description = "NroLote", length = 4, type = Type.INTEIRO, required = false)
    int nroLote;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "DtCotacao", length = 8, type = Type.DATA, required = true)
    Date dtCotacao;
    @SicomColumn(description = "VlRefPercentual", length = 6, type = Type.DOUBLE, required = true)
    double vlRefPercentual;
    @SicomColumn(description = "VlCotPrecosUnitario", length = 15, type = Type.DOUBLE, required = true)
    double vlCotPrecosUnitario;
    @SicomColumn(description = "Quantidade", length = 14, type = Type.DOUBLE, required = true)
    double quantidade;
    @SicomColumn(description = "VlMinAlienBens", length = 14, type = Type.DOUBLE, required = true)
    double vlMinAlienBens;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgaoResp() {
        return codOrgaoResp;
    }

    public void setCodOrgaoResp(String codOrgaoResp) {
        this.codOrgaoResp = codOrgaoResp;
    }

    public String getCodUnidadeSubResp() {
        return codUnidadeSubResp;
    }

    public void setCodUnidadeSubResp(String codUnidadeSubResp) {
        this.codUnidadeSubResp = codUnidadeSubResp;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public int getNroProcesso() {
        return nroProcesso;
    }

    public void setNroProcesso(int nroProcesso) {
        this.nroProcesso = nroProcesso;
    }

    public String getLicitatorio() {
        return Licitatorio;
    }

    public void setLicitatorio(String licitatorio) {
        Licitatorio = licitatorio;
    }

    public int getNroLote() {
        return nroLote;
    }

    public void setNroLote(int nroLote) {
        this.nroLote = nroLote;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public Date getDtCotacao() {
        return dtCotacao;
    }

    public void setDtCotacao(Date dtCotacao) {
        this.dtCotacao = dtCotacao;
    }

    public double getVlRefPercentual() {
        return vlRefPercentual;
    }

    public void setVlRefPercentual(double vlRefPercentual) {
        this.vlRefPercentual = vlRefPercentual;
    }

    public double getVlCotPrecosUnitario() {
        return vlCotPrecosUnitario;
    }

    public void setVlCotPrecosUnitario(double vlCotPrecosUnitario) {
        this.vlCotPrecosUnitario = vlCotPrecosUnitario;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public double getVlMinAlienBens() {
        return vlMinAlienBens;
    }

    public void setVlMinAlienBens(double vlMinAlienBens) {
        this.vlMinAlienBens = vlMinAlienBens;
    }
}
