//Nome do Arquivo:NTFDetalhamentoliquidacaoNotaFiscal
//20 – NTF - DetalhamentoliquidacaoNotaFiscal
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class NTFDetalhamentoliquidacaoNotaFiscal{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "nfNumero", length = 20, type = Type.INTEIRO, required = true)
    int nfNumero;
    @SicomColumn(description = "nfSerie", length = 8, type = Type.TEXTO, required = false)
    String nfSerie;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = true)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = true)
    String nroDocumento;
    @SicomColumn(description = "chaveAcesso", length = 44, type = Type.INTEIRO, required = false)
    int chaveAcesso;
    @SicomColumn(description = "dtEmissaoNF", length = 8, type = Type.DATA, required = true)
    date dtEmissaoNF;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtLiquidacao", length = 8, type = Type.DATA, required = true)
    date dtLiquidacao;
    @SicomColumn(description = "nroLiquidacao", length = 22, type = Type.INTEIRO, required = true)
    int nroLiquidacao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getNfNumero() {
        return nfNumero;
    }

    public void setNfNumero(int nfNumero) {
        this.nfNumero = nfNumero;
    }

    public String getNfSerie() {
        return nfSerie;
    }

    public void setNfSerie(String nfSerie) {
        this.nfSerie = nfSerie;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public int getChaveAcesso() {
        return chaveAcesso;
    }

    public void setChaveAcesso(int chaveAcesso) {
        this.chaveAcesso = chaveAcesso;
    }

    public date getDtEmissaoNF() {
        return dtEmissaoNF;
    }

    public void setDtEmissaoNF(date dtEmissaoNF) {
        this.dtEmissaoNF = dtEmissaoNF;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public int getNroLiquidacao() {
        return nroLiquidacao;
    }

    public void setNroLiquidacao(int nroLiquidacao) {
        this.nroLiquidacao = nroLiquidacao;
    }
}

