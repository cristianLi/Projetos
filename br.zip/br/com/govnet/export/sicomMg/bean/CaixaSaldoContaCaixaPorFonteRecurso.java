//Nome do Arquivo:CaixaSaldoContaCaixaPorFonteRecurso
//11 – Caixa - SaldoContaCaixaPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CaixaSaldoContaCaixaPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodFonteCaixa", length = 3, type = Type.INTEIRO, required = true)
    int codFonteCaixa;
    @SicomColumn(description = "VlSaldoInicialFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoInicialFonte;
    @SicomColumn(description = "VlSaldoFinalFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinalFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodFonteCaixa() {
        return codFonteCaixa;
    }

    public void setCodFonteCaixa(int codFonteCaixa) {
        this.codFonteCaixa = codFonteCaixa;
    }

    public double getVlSaldoInicialFonte() {
        return vlSaldoInicialFonte;
    }

    public void setVlSaldoInicialFonte(double vlSaldoInicialFonte) {
        this.vlSaldoInicialFonte = vlSaldoInicialFonte;
    }

    public double getVlSaldoFinalFonte() {
        return vlSaldoFinalFonte;
    }

    public void setVlSaldoFinalFonte(double vlSaldoFinalFonte) {
        this.vlSaldoFinalFonte = vlSaldoFinalFonte;
    }
}