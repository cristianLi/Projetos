//Nome do Arquivo:Metareal
//10 – Metareal
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Metareal{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "codFuncao", length = 2, type = Type.TEXTO, required = true)
    String codFuncao;
    @SicomColumn(description = "codSubFuncao", length = 3, type = Type.TEXTO, required = true)
    String codSubFuncao;
    @SicomColumn(description = "codPrograma", length = 4, type = Type.TEXTO, required = true)
    String codPrograma;
    @SicomColumn(description = "idAcao", length = 4, type = Type.TEXTO, required = true)
    String idAcao;
    @SicomColumn(description = "idSubAcao", length = 4, type = Type.TEXTO, required = false)
    String idSubAcao;
    @SicomColumn(description = "metaRealizada", length = 11, type = Type.DOUBLE, required = true)
    double metaRealizada;
    @SicomColumn(description = "justificativa", length = 1000, type = Type.TEXTO, required = false)
    String justificativa;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getCodFuncao() {
        return codFuncao;
    }

    public void setCodFuncao(String codFuncao) {
        this.codFuncao = codFuncao;
    }

    public String getCodSubFuncao() {
        return codSubFuncao;
    }

    public void setCodSubFuncao(String codSubFuncao) {
        this.codSubFuncao = codSubFuncao;
    }

    public String getCodPrograma() {
        return codPrograma;
    }

    public void setCodPrograma(String codPrograma) {
        this.codPrograma = codPrograma;
    }

    public String getIdAcao() {
        return idAcao;
    }

    public void setIdAcao(String idAcao) {
        this.idAcao = idAcao;
    }

    public String getIdSubAcao() {
        return idSubAcao;
    }

    public void setIdSubAcao(String idSubAcao) {
        this.idSubAcao = idSubAcao;
    }

    public double getMetaRealizada() {
        return metaRealizada;
    }

    public void setMetaRealizada(double metaRealizada) {
        this.metaRealizada = metaRealizada;
    }

    public String getJustificativa() {
        return justificativa;
    }

    public void setJustificativa(String justificativa) {
        this.justificativa = justificativa;
    }
}