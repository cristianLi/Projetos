//Nome do Arquivo: ResplicDetalhamentoComposicaoComissaoLicitacao
//20 – Resplic - DetalhamentoComposicaoComissaoLicitacao

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class ResplicDetalhamentoComposicaoComissaoLicitacao{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
    int exercicioLicitacao;
    @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
    String nroProcessoLicitatorio;
    @SicomColumn(description = "CodTipoComissao", length = 1, type = Type.INTEIRO, required = true)
    int codTipoComissao;
    @SicomColumn(description = "DescricaoAtoNomeacao", length = 1, type = Type.INTEIRO, required = true)
    int descricaoAtoNomeacao;
    @SicomColumn(description = "NroAtoNomeacao", length = 7, type = Type.INTEIRO, required = true)
    int nroAtoNomeacao;
    @SicomColumn(description = "DataAtoNomeacao", length = 8, type = Type.DATA, required = true)
    Date dataAtoNomeacao;
    @SicomColumn(description = "InicioVigencia", length = 8, type = Type.DATA, required = true)
    Date inicioVigencia;
    @SicomColumn(description = "FinalVigencia", length = 8, type = Type.DATA, required = true)
    Date finalVigencia;
    @SicomColumn(description = "CpfMembroComissao", length = 11, type = Type.TEXTO, required = true)
    String cpfMembroComissao;
    @SicomColumn(description = "CodAtribuicao", length = 1, type = Type.INTEIRO, required = true)
    int codAtribuicao;
    @SicomColumn(description = "Cargo", length = 50, type = Type.TEXTO, required = true)
    String cargo;
    @SicomColumn(description = "NaturezaCargo", length = 1, type = Type.INTEIRO, required = true)
    int naturezaCargo;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getExercicioLicitacao() {
        return exercicioLicitacao;
    }

    public void setExercicioLicitacao(int exercicioLicitacao) {
        this.exercicioLicitacao = exercicioLicitacao;
    }

    public String getNroProcessoLicitatorio() {
        return nroProcessoLicitatorio;
    }

    public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
        this.nroProcessoLicitatorio = nroProcessoLicitatorio;
    }

    public int getCodTipoComissao() {
        return codTipoComissao;
    }

    public void setCodTipoComissao(int codTipoComissao) {
        this.codTipoComissao = codTipoComissao;
    }

    public int getDescricaoAtoNomeacao() {
        return descricaoAtoNomeacao;
    }

    public void setDescricaoAtoNomeacao(int descricaoAtoNomeacao) {
        this.descricaoAtoNomeacao = descricaoAtoNomeacao;
    }

    public int getNroAtoNomeacao() {
        return nroAtoNomeacao;
    }

    public void setNroAtoNomeacao(int nroAtoNomeacao) {
        this.nroAtoNomeacao = nroAtoNomeacao;
    }

    public Date getDataAtoNomeacao() {
        return dataAtoNomeacao;
    }

    public void setDataAtoNomeacao(Date dataAtoNomeacao) {
        this.dataAtoNomeacao = dataAtoNomeacao;
    }

    public Date getInicioVigencia() {
        return inicioVigencia;
    }

    public void setInicioVigencia(Date inicioVigencia) {
        this.inicioVigencia = inicioVigencia;
    }

    public Date getFinalVigencia() {
        return finalVigencia;
    }

    public void setFinalVigencia(Date finalVigencia) {
        this.finalVigencia = finalVigencia;
    }

    public String getCpfMembroComissao() {
        return cpfMembroComissao;
    }

    public void setCpfMembroComissao(String cpfMembroComissao) {
        this.cpfMembroComissao = cpfMembroComissao;
    }

    public int getCodAtribuicao() {
        return codAtribuicao;
    }

    public void setCodAtribuicao(int codAtribuicao) {
        this.codAtribuicao = codAtribuicao;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getNaturezaCargo() {
        return naturezaCargo;
    }

    public void setNaturezaCargo(int naturezaCargo) {
        this.naturezaCargo = naturezaCargo;
    }
}