//Nome do Arquivo: Aberlic
//10 – Aberlic

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

    public class Aberlic{

        @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
        int tipoRegistro;
        @SicomColumn(description = "CodOrgaoResp", length = 2, type = Type.TEXTO, required = true)
        String codOrgaoResp;
        @SicomColumn(description = "CodUnidadeSubResp", length = 8, type = Type.TEXTO, required = true)
        String codUnidadeSubResp;
        @SicomColumn(description = "ExercicioLicitacao", length = 4, type = Type.INTEIRO, required = true)
        int exercicioLicitacao;
        @SicomColumn(description = "NroProcessoLicitatorio", length = 12, type = Type.TEXTO, required = true)
        String nroProcessoLicitatorio;
        @SicomColumn(description = "CodModalidadeLicitacao", length = 1, type = Type.INTEIRO, required = true)
        int codModalidadeLicitacao;
        @SicomColumn(description = "NroModalidade", length = 10, type = Type.INTEIRO, required = true)
        int nroModalidade;
        @SicomColumn(description = "NaturezaProcedimento", length = 1, type = Type.INTEIRO, required = true)
        int naturezaProcedimento;
        @SicomColumn(description = "DtAbertura", length = 8, type = Type.DATA, required = true)
        Date dtAbertura;
        @SicomColumn(description = "DtEditalConvite", length = 8, type = Type.DATA, required = true)
        Date dtEditalConvite;
        @SicomColumn(description = "DtPublicacaoEditalDO", length = 8, type = Type.DATA, required = false)
        Date dtPublicacaoEditalDO;
        @SicomColumn(description = "DtPublicacaoEditalVeiculo1", length = 8, type = Type.DATA, required = false)
        Date dtPublicacaoEditalVeiculo1;
        @SicomColumn(description = "Veiculo1Publicacao", length = 50, type = Type.TEXTO, required = false)
        String veiculo1Publicacao;
        @SicomColumn(description = "DtPublicacaoEditalVeiculo2", length = 8, type = Type.DATA, required = false)
        Date dtPublicacaoEditalVeiculo2;
        @SicomColumn(description = "Veiculo2Publicacao", length = 50, type = Type.TEXTO, required = false)
        String veiculo2Publicacao;
        @SicomColumn(description = "DtRecebimentoDoc", length = 8, type = Type.DATA, required = true)
        Date dtRecebimentoDoc;
        @SicomColumn(description = "TipoLicitacao", length = 1, type = Type.INTEIRO, required = false)
        int tipoLicitacao;
        @SicomColumn(description = "NaturezaObjeto", length = 1, type = Type.INTEIRO, required = false)
        int naturezaObjeto;
        @SicomColumn(description = "Objeto", length = 500, type = Type.TEXTO, required = true)
        String Objeto;
        @SicomColumn(description = "RegimeExecucaoObras", length = 1, type = Type.INTEIRO, required = false)
        int regimeExecucaoObras;
        @SicomColumn(description = "NroConvidado", length = 3, type = Type.INTEIRO, required = false)
        int nroConvidado;
        @SicomColumn(description = "ClausulaProrrogacao", length = 250, type = Type.TEXTO, required = false)
        String clausulaProrrogacao;
        @SicomColumn(description = "UnidadeMedidaPrazoExecucao", length = 1, type = Type.INTEIRO, required = true)
        int unidadeMedidaPrazoExecucao;
        @SicomColumn(description = "PrazoExecucao", length = 4, type = Type.INTEIRO, required = true)
        prazoExecucao;
        @SicomColumn(description = "FormaPagamento", length = 80, type = Type.TEXTO, required = true)
        String formaPagamento;
        @SicomColumn(description = "CriterioAceitabilidade", length = 80, type = Type.TEXTO, required = false)
        String criterioAceitabilidade;
        @SicomColumn(description = "CriterioAdjudicacao", length = 1, type = Type.INTEIRO, required = true)
        int criterioAdjudicacao;
        @SicomColumn(description = "ProcessoPorLote", length = 1, type = Type.INTEIRO, required = true)
        int processoPorLote;
        @SicomColumn(description = "CriterioDesempate", length = 1, type = Type.INTEIRO, required = true)
        int criterioDesempate;
        @SicomColumn(description = "DestinacaoExclusiva", length = 1, type = Type.INTEIRO, required = true)
        int destinacaoExclusiva;
        @SicomColumn(description = "Subcontratacao", length = 1, type = Type.INTEIRO, required = true)
        int subcontratacao;
        @SicomColumn(description = "LimiteContratacao", length = 1, type = Type.INTEIRO, required = true)
        int limiteContratacao;

        public int getTipoRegistro() {
            return tipoRegistro;
        }

        public void setTipoRegistro(int tipoRegistro) {
            this.tipoRegistro = tipoRegistro;
        }

        public String getCodOrgaoResp() {
            return codOrgaoResp;
        }

        public void setCodOrgaoResp(String codOrgaoResp) {
            this.codOrgaoResp = codOrgaoResp;
        }

        public String getCodUnidadeSubResp() {
            return codUnidadeSubResp;
        }

        public void setCodUnidadeSubResp(String codUnidadeSubResp) {
            this.codUnidadeSubResp = codUnidadeSubResp;
        }

        public int getExercicioLicitacao() {
            return exercicioLicitacao;
        }

        public void setExercicioLicitacao(int exercicioLicitacao) {
            this.exercicioLicitacao = exercicioLicitacao;
        }

        public String getNroProcessoLicitatorio() {
            return nroProcessoLicitatorio;
        }

        public void setNroProcessoLicitatorio(String nroProcessoLicitatorio) {
            this.nroProcessoLicitatorio = nroProcessoLicitatorio;
        }

        public int getCodModalidadeLicitacao() {
            return codModalidadeLicitacao;
        }

        public void setCodModalidadeLicitacao(int codModalidadeLicitacao) {
            this.codModalidadeLicitacao = codModalidadeLicitacao;
        }

        public int getNroModalidade() {
            return nroModalidade;
        }

        public void setNroModalidade(int nroModalidade) {
            this.nroModalidade = nroModalidade;
        }

        public int getNaturezaProcedimento() {
            return naturezaProcedimento;
        }

        public void setNaturezaProcedimento(int naturezaProcedimento) {
            this.naturezaProcedimento = naturezaProcedimento;
        }

        public Date getDtAbertura() {
            return dtAbertura;
        }

        public void setDtAbertura(Date dtAbertura) {
            this.dtAbertura = dtAbertura;
        }

        public Date getDtEditalConvite() {
            return dtEditalConvite;
        }

        public void setDtEditalConvite(Date dtEditalConvite) {
            this.dtEditalConvite = dtEditalConvite;
        }

        public Date getDtPublicacaoEditalDO() {
            return dtPublicacaoEditalDO;
        }

        public void setDtPublicacaoEditalDO(Date dtPublicacaoEditalDO) {
            this.dtPublicacaoEditalDO = dtPublicacaoEditalDO;
        }

        public Date getDtPublicacaoEditalVeiculo1() {
            return dtPublicacaoEditalVeiculo1;
        }

        public void setDtPublicacaoEditalVeiculo1(Date dtPublicacaoEditalVeiculo1) {
            this.dtPublicacaoEditalVeiculo1 = dtPublicacaoEditalVeiculo1;
        }

        public String getVeiculo1Publicacao() {
            return veiculo1Publicacao;
        }

        public void setVeiculo1Publicacao(String veiculo1Publicacao) {
            this.veiculo1Publicacao = veiculo1Publicacao;
        }

        public Date getDtPublicacaoEditalVeiculo2() {
            return dtPublicacaoEditalVeiculo2;
        }

        public void setDtPublicacaoEditalVeiculo2(Date dtPublicacaoEditalVeiculo2) {
            this.dtPublicacaoEditalVeiculo2 = dtPublicacaoEditalVeiculo2;
        }

        public String getVeiculo2Publicacao() {
            return veiculo2Publicacao;
        }

        public void setVeiculo2Publicacao(String veiculo2Publicacao) {
            this.veiculo2Publicacao = veiculo2Publicacao;
        }

        public Date getDtRecebimentoDoc() {
            return dtRecebimentoDoc;
        }

        public void setDtRecebimentoDoc(Date dtRecebimentoDoc) {
            this.dtRecebimentoDoc = dtRecebimentoDoc;
        }

        public int getTipoLicitacao() {
            return tipoLicitacao;
        }

        public void setTipoLicitacao(int tipoLicitacao) {
            this.tipoLicitacao = tipoLicitacao;
        }

        public int getNaturezaObjeto() {
            return naturezaObjeto;
        }

        public void setNaturezaObjeto(int naturezaObjeto) {
            this.naturezaObjeto = naturezaObjeto;
        }

        public String getObjeto() {
            return Objeto;
        }

        public void setObjeto(String objeto) {
            Objeto = objeto;
        }

        public int getRegimeExecucaoObras() {
            return regimeExecucaoObras;
        }

        public void setRegimeExecucaoObras(int regimeExecucaoObras) {
            this.regimeExecucaoObras = regimeExecucaoObras;
        }

        public int getNroConvidado() {
            return nroConvidado;
        }

        public void setNroConvidado(int nroConvidado) {
            this.nroConvidado = nroConvidado;
        }

        public String getClausulaProrrogacao() {
            return clausulaProrrogacao;
        }

        public void setClausulaProrrogacao(String clausulaProrrogacao) {
            this.clausulaProrrogacao = clausulaProrrogacao;
        }

        public int getUnidadeMedidaPrazoExecucao() {
            return unidadeMedidaPrazoExecucao;
        }

        public void setUnidadeMedidaPrazoExecucao(int unidadeMedidaPrazoExecucao) {
            this.unidadeMedidaPrazoExecucao = unidadeMedidaPrazoExecucao;
        }

        public String getFormaPagamento() {
            return formaPagamento;
        }

        public void setFormaPagamento(String formaPagamento) {
            this.formaPagamento = formaPagamento;
        }

        public String getCriterioAceitabilidade() {
            return criterioAceitabilidade;
        }

        public void setCriterioAceitabilidade(String criterioAceitabilidade) {
            this.criterioAceitabilidade = criterioAceitabilidade;
        }

        public int getCriterioAdjudicacao() {
            return criterioAdjudicacao;
        }

        public void setCriterioAdjudicacao(int criterioAdjudicacao) {
            this.criterioAdjudicacao = criterioAdjudicacao;
        }

        public int getProcessoPorLote() {
            return processoPorLote;
        }

        public void setProcessoPorLote(int processoPorLote) {
            this.processoPorLote = processoPorLote;
        }

        public int getCriterioDesempate() {
            return criterioDesempate;
        }

        public void setCriterioDesempate(int criterioDesempate) {
            this.criterioDesempate = criterioDesempate;
        }

        public int getDestinacaoExclusiva() {
            return destinacaoExclusiva;
        }

        public void setDestinacaoExclusiva(int destinacaoExclusiva) {
            this.destinacaoExclusiva = destinacaoExclusiva;
        }

        public int getSubcontratacao() {
            return subcontratacao;
        }

        public void setSubcontratacao(int subcontratacao) {
            this.subcontratacao = subcontratacao;
        }

        public int getLimiteContratacao() {
            return limiteContratacao;
        }

        public void setLimiteContratacao(int limiteContratacao) {
            this.limiteContratacao = limiteContratacao;
        }
    }