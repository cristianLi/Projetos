//Nome do Arquivo:Obelac
//10 – Obelac
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Obelac{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzido", length = 15, type = Type.INTEIRO, required = true)
    int codReduzido;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroLancamento", length = 22, type = Type.INTEIRO, required = true)
    int nroLancamento;
    @SicomColumn(description = "dtLancamento", length = 8, type = Type.DATA, required = true)
    date dtLancamento;
    @SicomColumn(description = "tipoLancamento", length = 1, type = Type.INTEIRO, required = true)
    int tipoLancamento;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "nroLiquidacao", length = 22, type = Type.INTEIRO, required false)
    int nroLiquidacao;
    @SicomColumn(description = "dtLiquidacao", length = 8, type = Type.DATA, required = false)
    date dtLiquidacao;
    @SicomColumn(description = "espLancamento", length = 500, type = Type.TEXTO, required = true)
    String espLancamento;
    @SicomColumn(description = "valorLancamento", length = 14, type = Type.DOUBLE, required = true)
    double valorLancamento;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzido() {
        return codReduzido;
    }

    public void setCodReduzido(int codReduzido) {
        this.codReduzido = codReduzido;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroLancamento() {
        return nroLancamento;
    }

    public void setNroLancamento(int nroLancamento) {
        this.nroLancamento = nroLancamento;
    }

    public date getDtLancamento() {
        return dtLancamento;
    }

    public void setDtLancamento(date dtLancamento) {
        this.dtLancamento = dtLancamento;
    }

    public int getTipoLancamento() {
        return tipoLancamento;
    }

    public void setTipoLancamento(int tipoLancamento) {
        this.tipoLancamento = tipoLancamento;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getNroLiquidacao() {
        return nroLiquidacao;
    }

    public void setNroLiquidacao(int nroLiquidacao) {
        this.nroLiquidacao = nroLiquidacao;
    }

    public date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public String getEspLancamento() {
        return espLancamento;
    }

    public void setEspLancamento(String espLancamento) {
        this.espLancamento = espLancamento;
    }

    public double getValorLancamento() {
        return valorLancamento;
    }

    public void setValorLancamento(double valorLancamento) {
        this.valorLancamento = valorLancamento;
    }
}