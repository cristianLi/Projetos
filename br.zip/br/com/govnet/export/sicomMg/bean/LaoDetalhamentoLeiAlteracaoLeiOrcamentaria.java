//Nome do Arquivo: LaoDetalhamentoLeiAlteracaoLeiOrcamentaria
//21 – Lao - DetalhamentoLeiAlteracaoLeiOrcamentaria

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class LaoDetalhamentoLeiAlteracaoLeiOrcamentaria{


    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "NroLeiAlterOrcam", length = 2, type = Type.INTEIRO, required = true)
    int nroLeiAlterOrcam;
    @SicomColumn(description = "TipoAutorizacao", length = 2, type = Type.INTEIRO, required = true)
    int tipoAutorizacao;
    @SicomColumn(description = "ArtigoLeiAlterOrcamento", length = 2, type = Type.INTEIRO, required = true)
    int artigoLeiAlterOrcamento;
    @SicomColumn(description = "DescricaoArtigo", length = 2, type = Type.INTEIRO, required = true)
    int descricaoArtigo;
    @SicomColumn(description = "NovoPercentual", length = 2, type = Type.INTEIRO, required = true)
    int novoPercentual;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getNroLeiAlterOrcam() {
        return nroLeiAlterOrcam;
    }

    public void setNroLeiAlterOrcam(int nroLeiAlterOrcam) {
        this.nroLeiAlterOrcam = nroLeiAlterOrcam;
    }

    public int getTipoAutorizacao() {
        return tipoAutorizacao;
    }

    public void setTipoAutorizacao(int tipoAutorizacao) {
        this.tipoAutorizacao = tipoAutorizacao;
    }

    public int getArtigoLeiAlterOrcamento() {
        return artigoLeiAlterOrcamento;
    }

    public void setArtigoLeiAlterOrcamento(int artigoLeiAlterOrcamento) {
        this.artigoLeiAlterOrcamento = artigoLeiAlterOrcamento;
    }

    public int getDescricaoArtigo() {
        return descricaoArtigo;
    }

    public void setDescricaoArtigo(int descricaoArtigo) {
        this.descricaoArtigo = descricaoArtigo;
    }

    public int getNovoPercentual() {
        return novoPercentual;
    }

    public void setNovoPercentual(int novoPercentual) {
        this.novoPercentual = novoPercentual;
    }
}