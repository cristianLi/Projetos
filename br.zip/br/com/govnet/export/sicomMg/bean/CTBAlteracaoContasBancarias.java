//Nome do Arquivo:CTBAlteracaoContasBancarias
//40 – CTB - AlteracaoContasBancarias

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CTBAlteracaoContasBancarias{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodCTB", length = 20, type = Type.INTEIRO, required = true)
    int codCTB;
    @SicomColumn(description = "DescContaBancaria", length = 50, type = Type.TEXTO, required = true)
    String descContaBancaria;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;
    @SicomColumn(description = "DataAssinaturaConvenio", length = 8, type = Type.DATA, required = false)
    date dataAssinaturaConvenio;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodCTB() {
        return codCTB;
    }

    public void setCodCTB(int codCTB) {
        this.codCTB = codCTB;
    }

    public String getDescContaBancaria() {
        return descContaBancaria;
    }

    public void setDescContaBancaria(String descContaBancaria) {
        this.descContaBancaria = descContaBancaria;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public date getDataAssinaturaConvenio() {
        return dataAssinaturaConvenio;
    }

    public void setDataAssinaturaConvenio(date dataAssinaturaConvenio) {
        this.dataAssinaturaConvenio = dataAssinaturaConvenio;
    }
}