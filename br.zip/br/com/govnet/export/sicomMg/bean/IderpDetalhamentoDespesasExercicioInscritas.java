//Nome do Arquivo:IderpDetalhamentoDespesasExercicioInscritas
//11 – Iderp - DetalhamentoDespesasExercicioInscritas
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class IderpDetalhamentoDespesasExercicioInscritas{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codIDERP", length = 15, type = Type.INTEIRO, required = true)
    int codIDERP;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlInscricaoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlInscricaoFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodIDERP() {
        return codIDERP;
    }

    public void setCodIDERP(int codIDERP) {
        this.codIDERP = codIDERP;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlInscricaoFonte() {
        return vlInscricaoFonte;
    }

    public void setVlInscricaoFonte(double vlInscricaoFonte) {
        this.vlInscricaoFonte = vlInscricaoFonte;
    }
}


