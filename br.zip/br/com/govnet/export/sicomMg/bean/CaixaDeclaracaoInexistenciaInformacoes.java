//Nome do Arquivo:CaixaDeclaracaoInexistenciaInformacoes
//99 – Caixa - DeclaracaoInexistenciaInformacoes

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CaixaDeclaracaoInexistenciaInformacoes{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tiporegistro;

    public int getTiporegistro() {
        return tiporegistro;
    }

    public void setTiporegistro(int tiporegistro) {
        this.tiporegistro = tiporegistro;
    }
}