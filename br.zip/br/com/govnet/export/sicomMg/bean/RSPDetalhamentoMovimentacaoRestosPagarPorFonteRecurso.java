//Nome do Arquivo:RSPDetalhamentoMovimentacaoRestosPagarPorFonteRecurso
//21 – RSP - DetalhamentoMovimentacaoRestosPagarPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSPDetalhamentoMovimentacaoRestosPagarPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoMov", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoMov;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlMovimentacaoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlMovimentacaoFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoMov() {
        return codReduzidoMov;
    }

    public void setCodReduzidoMov(int codReduzidoMov) {
        this.codReduzidoMov = codReduzidoMov;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlMovimentacaoFonte() {
        return vlMovimentacaoFonte;
    }

    public void setVlMovimentacaoFonte(double vlMovimentacaoFonte) {
        this.vlMovimentacaoFonte = vlMovimentacaoFonte;
    }
}