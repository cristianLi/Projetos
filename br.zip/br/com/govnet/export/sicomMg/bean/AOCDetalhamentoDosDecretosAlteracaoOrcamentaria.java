//Nome do Arquivo:AOCDetalhamentoDosDecretosAlteracaoOrcamentaria
//10 –AOC - DetalhamentoDosDecretosAlteracaoOrcamentaria

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AOCDetalhamentoDosDecretosAlteracaoOrcamentaria{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodReduzidoDecreto", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoDecreto;
    @SicomColumn(description = "NroDecreto", length = 8, type = Type.INTEIRO, required = true)
    int nroDecreto;
    @SicomColumn(description = "TipoDecretoAlteracao", length = 2, type = Type.TEXTO, required = true)
    String tipoDecretoAlteracao;
    @SicomColumn(description = "ValorAberto", length = 14, type = Type.DOUBLE, required = true)
    double valorAberto;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoDecreto() {
        return codReduzidoDecreto;
    }

    public void setCodReduzidoDecreto(int codReduzidoDecreto) {
        this.codReduzidoDecreto = codReduzidoDecreto;
    }

    public int getNroDecreto() {
        return nroDecreto;
    }

    public void setNroDecreto(int nroDecreto) {
        this.nroDecreto = nroDecreto;
    }

    public String getTipoDecretoAlteracao() {
        return tipoDecretoAlteracao;
    }

    public void setTipoDecretoAlteracao(String tipoDecretoAlteracao) {
        this.tipoDecretoAlteracao = tipoDecretoAlteracao;
    }

    public double getValorAberto() {
        return valorAberto;
    }

    public void setValorAberto(double valorAberto) {
        this.valorAberto = valorAberto;
    }
}