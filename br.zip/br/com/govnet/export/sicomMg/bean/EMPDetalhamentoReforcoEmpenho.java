//Nome do Arquivo:EMPDetalhamentoReforcoEmpenho
//20 – EMP - DetalhamentoReforcoEmpenho

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EMPDetalhamentoReforcoEmpenho{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "nroReforco", length = 22, type = Type.INTEIRO, required = true)
    int nroReforco;
    @SicomColumn(description = "dtReforco", length = 8, type = Type.DATA, required = true)
    date dtReforco;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlReforco", length = 14, type = Type.DOUBLE, required = true)
    double vlReforco;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getNroReforco() {
        return nroReforco;
    }

    public void setNroReforco(int nroReforco) {
        this.nroReforco = nroReforco;
    }

    public date getDtReforco() {
        return dtReforco;
    }

    public void setDtReforco(date dtReforco) {
        this.dtReforco = dtReforco;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlReforco() {
        return vlReforco;
    }

    public void setVlReforco(double vlReforco) {
        this.vlReforco = vlReforco;
    }
}