//Nome do Arquivo: ArcDetalhamentoDasReceitasReduzidasMesPorFonteRecursos
//11 – Arc - DetalhamentoDasReceitasReduzidasMesPorFonteRecursos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RecDetalhamentoDasReceitasReduzidasMesPorFonteRecursos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodCorrecao", length = 15, type = Type.INTEIRO, required = true)
    int codCorrecao;
    @SicomColumn(description = "CodFonteReduzida", length = 3, type = Type.INTEIRO, required = true)
    int codFonteReduzida;
    @SicomColumn(description = "tipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = false)
    int nroDocumento;
    @SicomColumn(description = "nroConvenio", length = 30, type = Type.TEXTO, required = false)
    int nroConvenio;
    @SicomColumn(description = "dataAssinatura", length = 8, type = Type.DATA, required = false)
    Date dataAssinatura;
    @SicomColumn(description = "vlReduzidoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlReduzidoFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodCorrecao() {
        return codCorrecao;
    }

    public void setCodCorrecao(int codCorrecao) {
        this.codCorrecao = codCorrecao;
    }

    public int getCodFonteReduzida() {
        return codFonteReduzida;
    }

    public void setCodFonteReduzida(int codFonteReduzida) {
        this.codFonteReduzida = codFonteReduzida;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public int getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(int nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public int getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(int nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public double getVlReduzidoFonte() {
        return vlReduzidoFonte;
    }

    public void setVlReduzidoFonte(double vlReduzidoFonte) {
        this.vlReduzidoFonte = vlReduzidoFonte;
    }
}