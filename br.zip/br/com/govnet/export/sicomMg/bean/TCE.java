//Nome do Arquivo:TCE
//10 – TCE
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class TCE{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "numProcessoTCE", length = 12, type = Type.TEXTO, required = true)
    String numProcessoTCE;
    @SicomColumn(description = "dataInstauracaoTCE", length = 8, type = Type.DATA, required = true)
    date dataInstauracaoTCE;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroConvenioConge", length = 30, type = Type.TEXTO, required = true)
    String nroConvenioConge;
    @SicomColumn(description = "dataAssinatura", length = 8, type = Type.DATA, required = true)
    date dataAssinatura;
    @SicomColumn(description = "ConvOriginalConge", length = 50, type = Type.TEXTO, required = true)
    String ConvOriginalConge;
    @SicomColumn(description = "dscInstrumeLegalTCE", length = 11, type = Type.TEXTO, required = true)
    String dscInstrumeLegalTCE;
    @SicomColumn(description = "nroCPFAutoridadeInstauraTCE", length = 50, type = Type.TEXTO, required = true)
    String nroCPFAutoridadeInstauraTCE;
    @SicomColumn(description = "dscCargoRespTCE", length = 14, type = Type.DOUBLE, required = true)
    double dscCargoRespTCE;
    @SicomColumn(description = "vlOriginalDano", length = 14, type = Type.DOUBLE, required = true)
    double vlOriginalDano;
    @SicomColumn(description = "vlAtualizadoDano", length = 8, type = Type.DATA, required = true)
    date vlAtualizadoDano;
    @SicomColumn(description = "dataAtualizacao", length = 20, type = Type.TEXTO, required = true)
    String dataAtualizacao;
    @SicomColumn(description = "indiceocorreHipotese", length = 1, type = Type.INTEIRO, required = true)
    int indiceocorreHipotese;
    @SicomColumn(description = "identiResponsavel", length = 1, type = Type.INTEIRO, required = true)
    int identiResponsavel;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getNumProcessoTCE() {
        return numProcessoTCE;
    }

    public void setNumProcessoTCE(String numProcessoTCE) {
        this.numProcessoTCE = numProcessoTCE;
    }

    public date getDataInstauracaoTCE() {
        return dataInstauracaoTCE;
    }

    public void setDataInstauracaoTCE(date dataInstauracaoTCE) {
        this.dataInstauracaoTCE = dataInstauracaoTCE;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public String getNroConvenioConge() {
        return nroConvenioConge;
    }

    public void setNroConvenioConge(String nroConvenioConge) {
        this.nroConvenioConge = nroConvenioConge;
    }

    public date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public String getConvOriginalConge() {
        return ConvOriginalConge;
    }

    public void setConvOriginalConge(String convOriginalConge) {
        ConvOriginalConge = convOriginalConge;
    }

    public String getDscInstrumeLegalTCE() {
        return dscInstrumeLegalTCE;
    }

    public void setDscInstrumeLegalTCE(String dscInstrumeLegalTCE) {
        this.dscInstrumeLegalTCE = dscInstrumeLegalTCE;
    }

    public String getNroCPFAutoridadeInstauraTCE() {
        return nroCPFAutoridadeInstauraTCE;
    }

    public void setNroCPFAutoridadeInstauraTCE(String nroCPFAutoridadeInstauraTCE) {
        this.nroCPFAutoridadeInstauraTCE = nroCPFAutoridadeInstauraTCE;
    }

    public double getDscCargoRespTCE() {
        return dscCargoRespTCE;
    }

    public void setDscCargoRespTCE(double dscCargoRespTCE) {
        this.dscCargoRespTCE = dscCargoRespTCE;
    }

    public double getVlOriginalDano() {
        return vlOriginalDano;
    }

    public void setVlOriginalDano(double vlOriginalDano) {
        this.vlOriginalDano = vlOriginalDano;
    }

    public date getVlAtualizadoDano() {
        return vlAtualizadoDano;
    }

    public void setVlAtualizadoDano(date vlAtualizadoDano) {
        this.vlAtualizadoDano = vlAtualizadoDano;
    }

    public String getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(String dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }

    public int getIndiceocorreHipotese() {
        return indiceocorreHipotese;
    }

    public void setIndiceocorreHipotese(int indiceocorreHipotese) {
        this.indiceocorreHipotese = indiceocorreHipotese;
    }

    public int getIdentiResponsavel() {
        return identiResponsavel;
    }

    public void setIdentiResponsavel(int identiResponsavel) {
        this.identiResponsavel = identiResponsavel;
    }
}