//Nome do Arquivo:DCLRFPublicacaoPeriodicidadeRREODaLRF
//30 – DCLRFPublicacaoPeriodicidadeRREODaLRF
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class DCLRFPublicacaoPeriodicidadeRREODaLRF{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "publicLRF", length = 1, type = Type.INTEIRO, required = true)
    int publicLRF;
    @SicomColumn(description = "dtPublicacaoRelatorioLRF", length = 8, type = Type.DATA, required = false)
    date dtPublicacaoRelatorioLRF;
    @SicomColumn(description = "localPublicacao", length = 1000, type = Type.TEXTO, required = false)
    String localPublicacao;
    @SicomColumn(description = "tpBimestre", length = 1, type = Type.INTEIRO, required = false)
    int tpBimestre;
    @SicomColumn(description = "exercicioTpBimestre", length = 4, type = Type.INTEIRO, required = false)
    int exercicioTpBimestre;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getPublicLRF() {
        return publicLRF;
    }

    public void setPublicLRF(int publicLRF) {
        this.publicLRF = publicLRF;
    }

    public date getDtPublicacaoRelatorioLRF() {
        return dtPublicacaoRelatorioLRF;
    }

    public void setDtPublicacaoRelatorioLRF(date dtPublicacaoRelatorioLRF) {
        this.dtPublicacaoRelatorioLRF = dtPublicacaoRelatorioLRF;
    }

    public String getLocalPublicacao() {
        return localPublicacao;
    }

    public void setLocalPublicacao(String localPublicacao) {
        this.localPublicacao = localPublicacao;
    }

    public int getTpBimestre() {
        return tpBimestre;
    }

    public void setTpBimestre(int tpBimestre) {
        this.tpBimestre = tpBimestre;
    }

    public int getExercicioTpBimestre() {
        return exercicioTpBimestre;
    }

    public void setExercicioTpBimestre(int exercicioTpBimestre) {
        this.exercicioTpBimestre = exercicioTpBimestre;
    }
}

