//Nome do Arquivo: LAO
//10 – LAO - Cadastro da Lei de Alteração Orçamentária

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class LAO{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NroLeiAlteracao", length = 6, type = Type.INTEIRO, required = true)
    int nroLeiAlteracao;
    @SicomColumn(description = "DataLeiAlteracao", length = 8, type = Type.DATA, required = false)
    Date dataLeiAlteracao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getNroLeiAlteracao() {
        return nroLeiAlteracao;
    }

    public void setNroLeiAlteracao(int nroLeiAlteracao) {
        this.nroLeiAlteracao = nroLeiAlteracao;
    }

    public Date getDataLeiAlteracao() {
        return dataLeiAlteracao;
    }

    public void setDataLeiAlteracao(Date dataLeiAlteracao) {
        this.dataLeiAlteracao = dataLeiAlteracao;
    }
}