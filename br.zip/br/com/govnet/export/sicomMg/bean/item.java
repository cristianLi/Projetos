//Nome do Arquivo: Item
//10 – Item

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Item{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "DscItem", length = 1000, type = Type.TEXTO, required = true)
    String dscItem;
    @SicomColumn(description = "UnidadeMedida", length = 50, type = Type.TEXTO, required = true)
    String unidadeMedida;
    @SicomColumn(description = "TipoCadastro", length = 1, type = Type.INTEIRO, required = true)
    int tipoCadastro;
    @SicomColumn(description = "JustificativaAlteracao", length = 100, type = Type.TEXTO, required = false)
    String justificativaAlteracao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public String getDscItem() {
        return dscItem;
    }

    public void setDscItem(String dscItem) {
        this.dscItem = dscItem;
    }

    public String getUnidadeMedida() {
        return unidadeMedida;
    }

    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }

    public int getTipoCadastro() {
        return tipoCadastro;
    }

    public void setTipoCadastro(int tipoCadastro) {
        this.tipoCadastro = tipoCadastro;
    }

    public String getJustificativaAlteracao() {
        return justificativaAlteracao;
    }

    public void setJustificativaAlteracao(String justificativaAlteracao) {
        this.justificativaAlteracao = justificativaAlteracao;
    }
}