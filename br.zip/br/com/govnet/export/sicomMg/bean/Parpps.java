//Nome do Arquivo:Parpps
//10 – Parpps
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class Parpps{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "tipoPlano", length = 1, type = Type.INTEIRO, required = true)
    int tipoPlano;
    @SicomColumn(description = "exercicio", length = 4, type = Type.INTEIRO, required = true)
    int exercicio;
    @SicomColumn(description = "vlSaldoFinanceiroExercicioAnterior", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinanceiroExercicioAnterior;
    @SicomColumn(description = "vlReceitaPrevidenciariaAnterior", length = 14, type = Type.DOUBLE, required = true)
    double vlReceitaPrevidenciariaAnterior;
    @SicomColumn(description = "vlDespesaPrevidenciariaAnterior", length = 14, type = Type.DOUBLE, required = true)
    double vlDespesaPrevidenciariaAnterior;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getTipoPlano() {
        return tipoPlano;
    }

    public void setTipoPlano(int tipoPlano) {
        this.tipoPlano = tipoPlano;
    }

    public int getExercicio() {
        return exercicio;
    }

    public void setExercicio(int exercicio) {
        this.exercicio = exercicio;
    }

    public double getVlSaldoFinanceiroExercicioAnterior() {
        return vlSaldoFinanceiroExercicioAnterior;
    }

    public void setVlSaldoFinanceiroExercicioAnterior(double vlSaldoFinanceiroExercicioAnterior) {
        this.vlSaldoFinanceiroExercicioAnterior = vlSaldoFinanceiroExercicioAnterior;
    }

    public double getVlReceitaPrevidenciariaAnterior() {
        return vlReceitaPrevidenciariaAnterior;
    }

    public void setVlReceitaPrevidenciariaAnterior(double vlReceitaPrevidenciariaAnterior) {
        this.vlReceitaPrevidenciariaAnterior = vlReceitaPrevidenciariaAnterior;
    }

    public double getVlDespesaPrevidenciariaAnterior() {
        return vlDespesaPrevidenciariaAnterior;
    }

    public void setVlDespesaPrevidenciariaAnterior(double vlDespesaPrevidenciariaAnterior) {
        this.vlDespesaPrevidenciariaAnterior = vlDespesaPrevidenciariaAnterior;
    }
}
