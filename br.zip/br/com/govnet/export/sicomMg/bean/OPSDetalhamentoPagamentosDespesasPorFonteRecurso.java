//Nome do Arquivo:OPSDetalhamentoPagamentosDespesasPorFonteRecurso
//11 – OPS - DetalhamentoPagamentosDespesasPorFonteRecurso
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class OPSDetalhamentoPagamentosDespesasPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoOP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoOP;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroOP", length = 22, type = Type.INTEIRO, required = true)
    int nroOP;
    @SicomColumn(description = "dtPagamento", length = 8, type = Type.DATA, required = true)
    date dtPagamento;
    @SicomColumn(description = "tipoPagamento", length = 1, type = Type.INTEIRO, required = true)
    int tipoPagamento;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "dtEmpenho", length = 8, type = Type.DATA, required = true)
    date dtEmpenho;
    @SicomColumn(description = "nroLiquidacao", length = 22, type = Type.INTEIRO, required = false)
    int nroLiquidacao;
    @SicomColumn(description = "dtLiquidacao", length = 8, type = Type.DATA, required = false)
    date dtLiquidacao;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "valorFonte", length = 14, type = Type.DOUBLE, required = true)
    double valorFonte;
    @SicomColumn(description = "tipoDocumentoCredor", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumentoCredor;
    @SicomColumn(description = "nroDocumento", length = 14, type = Type.TEXTO, required = false)
    String nroDocumento;
    @SicomColumn(description = "codOrgaoEmpOP", length = 2, type = Type.TEXTO, required = false)
    String codOrgaoEmpOP;
    @SicomColumn(description = "codUnidadeEmpOP", length = 8, type = Type.TEXTO, required = false)
    String codUnidadeEmpOP;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoOP() {
        return codReduzidoOP;
    }

    public void setCodReduzidoOP(int codReduzidoOP) {
        this.codReduzidoOP = codReduzidoOP;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroOP() {
        return nroOP;
    }

    public void setNroOP(int nroOP) {
        this.nroOP = nroOP;
    }

    public date getDtPagamento() {
        return dtPagamento;
    }

    public void setDtPagamento(date dtPagamento) {
        this.dtPagamento = dtPagamento;
    }

    public int getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(int tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public date getDtEmpenho() {
        return dtEmpenho;
    }

    public void setDtEmpenho(date dtEmpenho) {
        this.dtEmpenho = dtEmpenho;
    }

    public int getNroLiquidacao() {
        return nroLiquidacao;
    }

    public void setNroLiquidacao(int nroLiquidacao) {
        this.nroLiquidacao = nroLiquidacao;
    }

    public date getDtLiquidacao() {
        return dtLiquidacao;
    }

    public void setDtLiquidacao(date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getValorFonte() {
        return valorFonte;
    }

    public void setValorFonte(double valorFonte) {
        this.valorFonte = valorFonte;
    }

    public int getTipoDocumentoCredor() {
        return tipoDocumentoCredor;
    }

    public void setTipoDocumentoCredor(int tipoDocumentoCredor) {
        this.tipoDocumentoCredor = tipoDocumentoCredor;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getCodOrgaoEmpOP() {
        return codOrgaoEmpOP;
    }

    public void setCodOrgaoEmpOP(String codOrgaoEmpOP) {
        this.codOrgaoEmpOP = codOrgaoEmpOP;
    }

    public String getCodUnidadeEmpOP() {
        return codUnidadeEmpOP;
    }

    public void setCodUnidadeEmpOP(String codUnidadeEmpOP) {
        this.codUnidadeEmpOP = codUnidadeEmpOP;
    }
}