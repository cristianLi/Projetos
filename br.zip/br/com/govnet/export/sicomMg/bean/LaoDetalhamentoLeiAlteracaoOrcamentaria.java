//Nome do Arquivo:LaoDetalhamentoLeiAlteracaoOrcamentaria
//10 – Lao - DetalhamentoLeiAlteracaoOrcamentaria

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class LaoDetalhamentoLeiAlteracaoOrcamentaria{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "NroLeiAlteracao", length = 6, type = Type.INTEIRO, required = true)
    int nroLeiAlteracao;
    @SicomColumn(description = "TipoLeiAlteracao", length = 1, type = Type.INTEIRO, required = true)
    String tipoLeiAlteracao;
    @SicomColumn(description = "ArtigoLeiAlteracao", length = 6, type = Type.TEXTO, required = true)
    String artigoLeiAlteracao;
    @SicomColumn(description = "DescricaoArtigo", length = 512, type = Type.TEXTO, required = true)
    String descricaoArtigo;
    @SicomColumn(description = "VlAutorizadoAlteracao", length = 14, type = Type.DOUBLE, required = true)
    double vlAutorizadoAlteracao;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getNroLeiAlteracao() {
        return nroLeiAlteracao;
    }

    public void setNroLeiAlteracao(int nroLeiAlteracao) {
        this.nroLeiAlteracao = nroLeiAlteracao;
    }

    public String getTipoLeiAlteracao() {
        return tipoLeiAlteracao;
    }

    public void setTipoLeiAlteracao(String tipoLeiAlteracao) {
        this.tipoLeiAlteracao = tipoLeiAlteracao;
    }

    public String getArtigoLeiAlteracao() {
        return artigoLeiAlteracao;
    }

    public void setArtigoLeiAlteracao(String artigoLeiAlteracao) {
        this.artigoLeiAlteracao = artigoLeiAlteracao;
    }

    public String getDescricaoArtigo() {
        return descricaoArtigo;
    }

    public void setDescricaoArtigo(String descricaoArtigo) {
        this.descricaoArtigo = descricaoArtigo;
    }

    public double getVlAutorizadoAlteracao() {
        return vlAutorizadoAlteracao;
    }

    public void setVlAutorizadoAlteracao(double vlAutorizadoAlteracao) {
        this.vlAutorizadoAlteracao = vlAutorizadoAlteracao;
    }
}