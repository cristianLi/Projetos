//Nome do Arquivo: ArcDetalhamentoDasReceitasAcrescidasMesPorFonteRecursos
//10 – Arc - DetalhamentoDasReceitasAcrescidasMesPorFonteRecursos

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;


public class ArcDetalhamentoDasReceitasAcrescidasMesPorFonteRecursos{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tiporegistro;
    @SicomColumn(description = "CodReceita", length = 15, type = Type.INTEIRO, required = true)
    int codReceita;
    @SicomColumn(description = "CodFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "TipoDocumento", length = 1, type = Type.INTEIRO, required = false)
    int tipoDocumento;
    @SicomColumn(description = "NroDocumento", length = 14, type = Type.TEXTO, required = false)
    String nroDocumento;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = false)
    String nroConvenio;
    @SicomColumn(description = "DataAssinatura", length = 8, type = Type.DATA, required = false)
    Date dataAssinatura;
    @SicomColumn(description = "VlArrecadadoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlAcrescidoFonte;

    public int getTiporegistro() {
        return tiporegistro;
    }

    public void setTiporegistro(int tiporegistro) {
        this.tiporegistro = tiporegistro;
    }

    public int getCodReceita() {
        return codReceita;
    }

    public void setCodReceita(int codReceita) {
        this.codReceita = codReceita;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public int getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(int tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinatura() {
        return dataAssinatura;
    }

    public void setDataAssinatura(Date dataAssinatura) {
        this.dataAssinatura = dataAssinatura;
    }

    public double getVlArrecadadoFonte() {
        return vlArrecadadoFonte;
    }

    public void setVlAcrescidoFonte(double vlAcrescidoFonte) {
        this.vlAcrescidoFonte = vlAcrescidoFonte;
    }
}
