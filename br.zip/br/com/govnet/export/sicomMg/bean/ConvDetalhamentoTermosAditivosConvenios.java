//Nome do Arquivo: ConvDetalhamentoTermosAditivosConvenios
//20 – Conv - DetalhamentoTermosAditivosConvenios

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ConvDetalhamentoTermosAditivosConvenios{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "NroConvenio", length = 30, type = Type.TEXTO, required = true)
    String nroConvenio;
    @SicomColumn(description = "DataAssinaturaConvOriginal", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaConvOriginal;
    @SicomColumn(description = "NroSeqTermoAditivo", length = 2, type = Type.INTEIRO, required = true)
    int nroSeqTermoAditivo;
    @SicomColumn(description = "DscAlteracao", length = 500, type = Type.TEXTO, required = true)
    String dscAlteracao;
    @SicomColumn(description = "DataAssinaturaTermoAditivo", length = 8, type = Type.DATA, required = true)
    Date dataAssinaturaTermoAditivo;
    @SicomColumn(description = "DataFinalVigencia", length = 8, type = Type.DATA, required = true)
    Date dataFinalVigencia;
    @SicomColumn(description = "ValorAtualizadoConvenio", length = 14, type = Type.DOUBLE, required = true)
    double valorAtualizadoConvenio;
    @SicomColumn(description = "ValorAtualizadoContrapartida", length = 14, type = Type.DOUBLE, required = true)
    double valorAtualizadoContrapartida;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getNroConvenio() {
        return nroConvenio;
    }

    public void setNroConvenio(String nroConvenio) {
        this.nroConvenio = nroConvenio;
    }

    public Date getDataAssinaturaConvOriginal() {
        return dataAssinaturaConvOriginal;
    }

    public void setDataAssinaturaConvOriginal(Date dataAssinaturaConvOriginal) {
        this.dataAssinaturaConvOriginal = dataAssinaturaConvOriginal;
    }

    public int getNroSeqTermoAditivo() {
        return nroSeqTermoAditivo;
    }

    public void setNroSeqTermoAditivo(int nroSeqTermoAditivo) {
        this.nroSeqTermoAditivo = nroSeqTermoAditivo;
    }

    public String getDscAlteracao() {
        return dscAlteracao;
    }

    public void setDscAlteracao(String dscAlteracao) {
        this.dscAlteracao = dscAlteracao;
    }

    public Date getDataAssinaturaTermoAditivo() {
        return dataAssinaturaTermoAditivo;
    }

    public void setDataAssinaturaTermoAditivo(Date dataAssinaturaTermoAditivo) {
        this.dataAssinaturaTermoAditivo = dataAssinaturaTermoAditivo;
    }

    public Date getDataFinalVigencia() {
        return dataFinalVigencia;
    }

    public void setDataFinalVigencia(Date dataFinalVigencia) {
        this.dataFinalVigencia = dataFinalVigencia;
    }

    public double getValorAtualizadoConvenio() {
        return valorAtualizadoConvenio;
    }

    public void setValorAtualizadoConvenio(double valorAtualizadoConvenio) {
        this.valorAtualizadoConvenio = valorAtualizadoConvenio;
    }

    public double getValorAtualizadoContrapartida() {
        return valorAtualizadoContrapartida;
    }

    public void setValorAtualizadoContrapartida(double valorAtualizadoContrapartida) {
        this.valorAtualizadoContrapartida = valorAtualizadoContrapartida;
    }
}