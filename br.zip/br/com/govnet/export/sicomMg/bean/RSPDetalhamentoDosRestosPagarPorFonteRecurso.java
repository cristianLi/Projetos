//Nome do Arquivo:RSPDetalhamentoDosRestosPagarPorFonteRecurso
//11 – RSP - DetalhamentoDosRestosPagarPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class RSPDetalhamentoDosRestosPagarPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codReduzidoRSP", length = 15, type = Type.INTEIRO, required = true)
    int codReduzidoRSP;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlOriginalFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlOriginalFonte;
    @SicomColumn(description = "vlSaldoAntProceFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAntProceFonte;
    @SicomColumn(description = "vlSaldoAntNao", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoAntNaoProcFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodReduzidoRSP() {
        return codReduzidoRSP;
    }

    public void setCodReduzidoRSP(int codReduzidoRSP) {
        this.codReduzidoRSP = codReduzidoRSP;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlOriginalFonte() {
        return vlOriginalFonte;
    }

    public void setVlOriginalFonte(double vlOriginalFonte) {
        this.vlOriginalFonte = vlOriginalFonte;
    }

    public double getVlSaldoAntProceFonte() {
        return vlSaldoAntProceFonte;
    }

    public void setVlSaldoAntProceFonte(double vlSaldoAntProceFonte) {
        this.vlSaldoAntProceFonte = vlSaldoAntProceFonte;
    }

    public double getVlSaldoAntNaoProcFonte() {
        return vlSaldoAntNaoProcFonte;
    }

    public void setVlSaldoAntNaoProcFonte(double vlSaldoAntNaoProcFonte) {
        this.vlSaldoAntNaoProcFonte = vlSaldoAntNaoProcFonte;
    }
}