//Nome do Arquivo:ANLDetalhamentoEmpenhosAnuladosPorFonteRecurso
//11 – ANL - DetalhamentoEmpenhosAnuladosPorFonteRecurso

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class ANLDetalhamentoEmpenhosAnuladosPorFonteRecurso{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "nroEmpenho", length = 22, type = Type.INTEIRO, required = true)
    int nroEmpenho;
    @SicomColumn(description = "nroAnulacao", length = 22, type = Type.INTEIRO, required = true)
    int nroAnulacao;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "vlAnulacaoFonte", length = 14, type = Type.DOUBLE, required = true)
    double vlAnulacaoFonte;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public int getNroEmpenho() {
        return nroEmpenho;
    }

    public void setNroEmpenho(int nroEmpenho) {
        this.nroEmpenho = nroEmpenho;
    }

    public int getNroAnulacao() {
        return nroAnulacao;
    }

    public void setNroAnulacao(int nroAnulacao) {
        this.nroAnulacao = nroAnulacao;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public double getVlAnulacaoFonte() {
        return vlAnulacaoFonte;
    }

    public void setVlAnulacaoFonte(double vlAnulacaoFonte) {
        this.vlAnulacaoFonte = vlAnulacaoFonte;
    }
}