//Nome do Arquivo:CTBDetalhamentoSaldosBancariosAgentesArrecadadores
//30 – CTB - DetalhamentoSaldosBancariosAgentesArrecadadores

package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class CTBDetalhamentoSaldosBancariosAgentesArrecadadores{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "CodOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "CodAgenteArrecadador", length = 15, type = Type.INTEIRO, required = true)
    int codAgenteArrecadador;
    @SicomColumn(description = "CnpjAgenteArrecadador", length = 14, type = Type.TEXTO, required = true)
    String cnpjAgenteArrecadador;
    @SicomColumn(description = "VlSaldoInicial", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoInicial;
    @SicomColumn(description = "VlSaldoFinal", length = 14, type = Type.DOUBLE, required = true)
    double vlSaldoFinal;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public int getCodAgenteArrecadador() {
        return codAgenteArrecadador;
    }

    public void setCodAgenteArrecadador(int codAgenteArrecadador) {
        this.codAgenteArrecadador = codAgenteArrecadador;
    }

    public String getCnpjAgenteArrecadador() {
        return cnpjAgenteArrecadador;
    }

    public void setCnpjAgenteArrecadador(String cnpjAgenteArrecadador) {
        this.cnpjAgenteArrecadador = cnpjAgenteArrecadador;
    }

    public double getVlSaldoInicial() {
        return vlSaldoInicial;
    }

    public void setVlSaldoInicial(double vlSaldoInicial) {
        this.vlSaldoInicial = vlSaldoInicial;
    }

    public double getVlSaldoFinal() {
        return vlSaldoFinal;
    }

    public void setVlSaldoFinal(double vlSaldoFinal) {
        this.vlSaldoFinal = vlSaldoFinal;
    }
}