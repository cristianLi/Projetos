//Nome do Arquivo:NTFDetalhamentoItensNotaFiscal
//11 – NTF - DetalhamentoItensNotaFiscal
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class NTFDetalhamentoItensNotaFiscal{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codNotaFiscal", length = 15, type = Type.INTEIRO, required = true)
    int codNotaFiscal;
    @SicomColumn(description = "codItem", length = 15, type = Type.INTEIRO, required = true)
    int codItem;
    @SicomColumn(description = "quantidadeItem", length = 14, type = Type.DOUBLE, required = true)
    double quantidadeItem;
    @SicomColumn(description = "valorUnitarioItem", length = 14, type = Type.DOUBLE, required = true)
    double valorUnitarioItem;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodNotaFiscal() {
        return codNotaFiscal;
    }

    public void setCodNotaFiscal(int codNotaFiscal) {
        this.codNotaFiscal = codNotaFiscal;
    }

    public int getCodItem() {
        return codItem;
    }

    public void setCodItem(int codItem) {
        this.codItem = codItem;
    }

    public double getQuantidadeItem() {
        return quantidadeItem;
    }

    public void setQuantidadeItem(double quantidadeItem) {
        this.quantidadeItem = quantidadeItem;
    }

    public double getValorUnitarioItem() {
        return valorUnitarioItem;
    }

    public void setValorUnitarioItem(double valorUnitarioItem) {
        this.valorUnitarioItem = valorUnitarioItem;
    }
}