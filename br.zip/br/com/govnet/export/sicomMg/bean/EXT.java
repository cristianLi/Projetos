//Nome do Arquivo:EXT
//10 – EXT
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class EXT{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codEXT", length = 15, type = Type.INTEIRO, required = true)
    int codEXT;
    @SicomColumn(description = "codOrgao", length = 2, type = Type.TEXTO, required = true)
    String codOrgao;
    @SicomColumn(description = "tipoLancamento", length = 2, type = Type.TEXTO, required = true)
    String tipoLancamento;
    @SicomColumn(description = "subTipo", length = 4, type = Type.INTEIRO, TEXTO = true)
    String subTipo;
    @SicomColumn(description = "desdobraSubTipo", length = 4, type = Type.TEXTO, required = false)
    String desdobraSubTipo;
    @SicomColumn(description = "descExtraOrc", length = 50, type = Type.TEXTO, required = true)
    String descExtraOrc;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodEXT() {
        return codEXT;
    }

    public void setCodEXT(int codEXT) {
        this.codEXT = codEXT;
    }

    public String getCodOrgao() {
        return codOrgao;
    }

    public void setCodOrgao(String codOrgao) {
        this.codOrgao = codOrgao;
    }

    public String getTipoLancamento() {
        return tipoLancamento;
    }

    public void setTipoLancamento(String tipoLancamento) {
        this.tipoLancamento = tipoLancamento;
    }

    public String getSubTipo() {
        return subTipo;
    }

    public void setSubTipo(String subTipo) {
        this.subTipo = subTipo;
    }

    public String getDesdobraSubTipo() {
        return desdobraSubTipo;
    }

    public void setDesdobraSubTipo(String desdobraSubTipo) {
        this.desdobraSubTipo = desdobraSubTipo;
    }

    public String getDescExtraOrc() {
        return descExtraOrc;
    }

    public void setDescExtraOrc(String descExtraOrc) {
        this.descExtraOrc = descExtraOrc;
    }
}