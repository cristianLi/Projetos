//Nome do Arquivo:AEX
//10 – AEX
package br.com.govnet.export.sicomMg.bean;

import java.sql.Date;

import br.com.govnet.export.sicomMg.SicomColumn;
import br.com.govnet.export.sicomMg.Type;

public class AEX{

    @SicomColumn(description = "Tipo do registro", length = 2, type = Type.INTEIRO, required = true)
    int tipoRegistro;
    @SicomColumn(description = "codEXT", length = 15, type = Type.INTEIRO, required = true)
    int codEXT;
    @SicomColumn(description = "codFontRecursos", length = 3, type = Type.INTEIRO, required = true)
    int codFontRecursos;
    @SicomColumn(description = "nroOP", length = 22, type = Type.INTEIRO, required = true)
    int nroOP;
    @SicomColumn(description = "codUnidadeSub", length = 8, type = Type.TEXTO, required = true)
    String codUnidadeSub;
    @SicomColumn(description = "dtPagamento", length = 8, type = Type.DATA required = true)
    date dtPagamento;
    @SicomColumn(description = "nroAnulacaoOP", length = 22, type = Type.INTEIRO, required = true)
    int nroAnulacaoOP;
    @SicomColumn(description = "dtAnulacaoOP", length = 8, type = Type.DATA, required = true)
    date dtAnulacaoOP;
    @SicomColumn(description = "vlAnulacaoOP", length = 14, type = Type.DOUBLE, required = true)
    double vlAnulacaoOP;

    public int getTipoRegistro() {
        return tipoRegistro;
    }

    public void setTipoRegistro(int tipoRegistro) {
        this.tipoRegistro = tipoRegistro;
    }

    public int getCodEXT() {
        return codEXT;
    }

    public void setCodEXT(int codEXT) {
        this.codEXT = codEXT;
    }

    public int getCodFontRecursos() {
        return codFontRecursos;
    }

    public void setCodFontRecursos(int codFontRecursos) {
        this.codFontRecursos = codFontRecursos;
    }

    public int getNroOP() {
        return nroOP;
    }

    public void setNroOP(int nroOP) {
        this.nroOP = nroOP;
    }

    public String getCodUnidadeSub() {
        return codUnidadeSub;
    }

    public void setCodUnidadeSub(String codUnidadeSub) {
        this.codUnidadeSub = codUnidadeSub;
    }

    public date getDtPagamento() {
        return dtPagamento;
    }

    public void setDtPagamento(date dtPagamento) {
        this.dtPagamento = dtPagamento;
    }

    public int getNroAnulacaoOP() {
        return nroAnulacaoOP;
    }

    public void setNroAnulacaoOP(int nroAnulacaoOP) {
        this.nroAnulacaoOP = nroAnulacaoOP;
    }

    public date getDtAnulacaoOP() {
        return dtAnulacaoOP;
    }

    public void setDtAnulacaoOP(date dtAnulacaoOP) {
        this.dtAnulacaoOP = dtAnulacaoOP;
    }

    public double getVlAnulacaoOP() {
        return vlAnulacaoOP;
    }

    public void setVlAnulacaoOP(double vlAnulacaoOP) {
        this.vlAnulacaoOP = vlAnulacaoOP;
    }
}